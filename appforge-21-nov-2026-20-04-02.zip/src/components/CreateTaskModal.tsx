import { useState } from 'react';
import { X } from 'lucide-react';
import {
  Task,
  TaskCategory,
  TaskPriority,
  TaskStatus,
  TeamMember,
} from '../types/project';
import { CATEGORIES, PRIORITY_CONFIG, STATUS_CONFIG } from '../data/seedData';
import { addDaysIso, TODAY_ISO } from '../utils/formatters';

interface CreateTaskModalProps {
  projectId: string;
  projectKey: string;
  existingCount: number;
  initialStatus: TaskStatus;
  members: TeamMember[];
  onClose: () => void;
  onCreate: (task: Task) => void;
}

export function CreateTaskModal({
  projectId,
  projectKey,
  existingCount,
  initialStatus,
  members,
  onClose,
  onCreate,
}: CreateTaskModalProps) {
  const [titre, setTitre] = useState('');
  const [description, setDescription] = useState('');
  const [statut, setStatut] = useState<TaskStatus>(initialStatus);
  const [priorite, setPriorite] = useState<TaskPriority>('normale');
  const [categorie, setCategorie] = useState<TaskCategory>('Frontend');
  const [assigneeId, setAssigneeId] = useState<string>(members[0]?.id ?? '');
  const [dateDebut, setDateDebut] = useState(TODAY_ISO);
  const [echeance, setEcheance] = useState(addDaysIso(TODAY_ISO, 5));
  const [heuresEstimees, setHeuresEstimees] = useState(8);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!titre.trim()) return;

    const number = 101 + existingCount;
    const newTask: Task = {
      id: `t-${Date.now()}`,
      code: `${projectKey}-${number}`,
      projectId,
      titre: titre.trim(),
      description: description.trim(),
      statut,
      priorite,
      categorie,
      assigneeId,
      dateDebut,
      echeance: echeance < dateDebut ? dateDebut : echeance,
      heuresEstimees: Math.max(1, heuresEstimees),
      heuresPassees: 0,
      sousTaches: [],
    };
    onCreate(newTask);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      <div className="fixed inset-0 bg-slate-950/50" onClick={onClose} aria-hidden="true" />
      <div
        role="dialog"
        aria-modal="true"
        aria-labelledby="create-task-title"
        className="relative z-10 w-full max-w-lg rounded-xl border border-slate-200 bg-white p-6 dark:border-slate-800 dark:bg-slate-900"
      >
        <div className="flex items-center justify-between">
          <h2
            id="create-task-title"
            className="font-display text-lg font-semibold text-slate-950 dark:text-white"
          >
            Nouvelle tâche
          </h2>
          <button
            type="button"
            onClick={onClose}
            aria-label="Fermer"
            className="rounded-md p-1.5 text-slate-500 hover:bg-slate-100 hover:text-slate-900 dark:text-slate-400 dark:hover:bg-slate-800 dark:hover:text-white"
          >
            <X className="h-4 w-4" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="mt-5 space-y-4">
          <div>
            <label
              htmlFor="new-task-title"
              className="block text-xs font-medium text-slate-600 dark:text-slate-300"
            >
              Intitulé de la tâche
            </label>
            <input
              id="new-task-title"
              type="text"
              required
              autoFocus
              value={titre}
              onChange={(e) => setTitre(e.target.value)}
              placeholder="Ex. Implémenter l’export comptable CSV"
              className="mt-1 w-full rounded-lg border border-slate-200 bg-white px-3 py-2 text-sm text-slate-900 focus:border-indigo-600 focus:outline-none dark:border-slate-700 dark:bg-slate-950 dark:text-slate-100"
            />
          </div>

          <div>
            <label
              htmlFor="new-task-desc"
              className="block text-xs font-medium text-slate-600 dark:text-slate-300"
            >
              Description
            </label>
            <textarea
              id="new-task-desc"
              rows={2}
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Contexte, livrables attendus..."
              className="mt-1 w-full rounded-lg border border-slate-200 bg-white px-3 py-2 text-sm text-slate-900 focus:border-indigo-600 focus:outline-none dark:border-slate-700 dark:bg-slate-950 dark:text-slate-100"
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label
                htmlFor="new-task-status"
                className="block text-xs font-medium text-slate-600 dark:text-slate-300"
              >
                Statut initial
              </label>
              <select
                id="new-task-status"
                value={statut}
                onChange={(e) => setStatut(e.target.value as TaskStatus)}
                className="mt-1 w-full rounded-lg border border-slate-200 bg-white px-3 py-2 text-sm text-slate-900 focus:border-indigo-600 focus:outline-none dark:border-slate-700 dark:bg-slate-950 dark:text-slate-100"
              >
                {(Object.keys(STATUS_CONFIG) as TaskStatus[]).map((key) => (
                  <option key={key} value={key}>
                    {STATUS_CONFIG[key].label}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label
                htmlFor="new-task-priority"
                className="block text-xs font-medium text-slate-600 dark:text-slate-300"
              >
                Priorité
              </label>
              <select
                id="new-task-priority"
                value={priorite}
                onChange={(e) => setPriorite(e.target.value as TaskPriority)}
                className="mt-1 w-full rounded-lg border border-slate-200 bg-white px-3 py-2 text-sm text-slate-900 focus:border-indigo-600 focus:outline-none dark:border-slate-700 dark:bg-slate-950 dark:text-slate-100"
              >
                {(Object.keys(PRIORITY_CONFIG) as TaskPriority[]).map((key) => (
                  <option key={key} value={key}>
                    {PRIORITY_CONFIG[key].label}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label
                htmlFor="new-task-cat"
                className="block text-xs font-medium text-slate-600 dark:text-slate-300"
              >
                Domaine
              </label>
              <select
                id="new-task-cat"
                value={categorie}
                onChange={(e) => setCategorie(e.target.value as TaskCategory)}
                className="mt-1 w-full rounded-lg border border-slate-200 bg-white px-3 py-2 text-sm text-slate-900 focus:border-indigo-600 focus:outline-none dark:border-slate-700 dark:bg-slate-950 dark:text-slate-100"
              >
                {CATEGORIES.map((cat) => (
                  <option key={cat} value={cat}>
                    {cat}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label
                htmlFor="new-task-assignee"
                className="block text-xs font-medium text-slate-600 dark:text-slate-300"
              >
                Responsable
              </label>
              <select
                id="new-task-assignee"
                value={assigneeId}
                onChange={(e) => setAssigneeId(e.target.value)}
                className="mt-1 w-full rounded-lg border border-slate-200 bg-white px-3 py-2 text-sm text-slate-900 focus:border-indigo-600 focus:outline-none dark:border-slate-700 dark:bg-slate-950 dark:text-slate-100"
              >
                {members.map((m) => (
                  <option key={m.id} value={m.id}>
                    {m.nom}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label
                htmlFor="new-task-start"
                className="block text-xs font-medium text-slate-600 dark:text-slate-300"
              >
                Date de début
              </label>
              <input
                id="new-task-start"
                type="date"
                value={dateDebut}
                onChange={(e) => setDateDebut(e.target.value)}
                className="mt-1 w-full rounded-lg border border-slate-200 bg-white px-3 py-2 font-mono text-sm text-slate-900 focus:border-indigo-600 focus:outline-none dark:border-slate-700 dark:bg-slate-950 dark:text-slate-100"
              />
            </div>

            <div>
              <label
                htmlFor="new-task-due"
                className="block text-xs font-medium text-slate-600 dark:text-slate-300"
              >
                Échéance
              </label>
              <input
                id="new-task-due"
                type="date"
                value={echeance}
                onChange={(e) => setEcheance(e.target.value)}
                className="mt-1 w-full rounded-lg border border-slate-200 bg-white px-3 py-2 font-mono text-sm text-slate-900 focus:border-indigo-600 focus:outline-none dark:border-slate-700 dark:bg-slate-950 dark:text-slate-100"
              />
            </div>
          </div>

          <div>
            <label
              htmlFor="new-task-hours"
              className="block text-xs font-medium text-slate-600 dark:text-slate-300"
            >
              Charge estimée (heures)
            </label>
            <input
              id="new-task-hours"
              type="number"
              min={1}
              max={200}
              value={heuresEstimees}
              onChange={(e) => setHeuresEstimees(Number(e.target.value))}
              className="mt-1 w-32 rounded-lg border border-slate-200 bg-white px-3 py-2 font-mono text-sm tabular-nums text-slate-900 focus:border-indigo-600 focus:outline-none dark:border-slate-700 dark:bg-slate-950 dark:text-slate-100"
            />
          </div>

          <div className="flex items-center justify-end gap-2 border-t border-slate-200 pt-4 dark:border-slate-800">
            <button
              type="button"
              onClick={onClose}
              className="rounded-lg px-4 py-2 text-sm font-medium text-slate-600 hover:bg-slate-100 whitespace-nowrap shrink-0 dark:text-slate-300 dark:hover:bg-slate-800"
            >
              Annuler
            </button>
            <button
              type="submit"
              className="rounded-lg bg-slate-900 px-4 py-2 text-sm font-medium text-white hover:bg-slate-800 whitespace-nowrap shrink-0 dark:bg-slate-100 dark:text-slate-950 dark:hover:bg-white"
            >
              Créer la tâche
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
