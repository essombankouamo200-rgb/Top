import { Download, Printer, RotateCcw } from 'lucide-react';
import { useState } from 'react';
import { MaterialRow } from '../types/planelec';
import { DEFAULT_UNIT_PRICES } from '../data/catalog';
import { frNum, SimulationOutput } from '../utils/electricalEngine';

interface BudgetReportViewProps {
  sim: SimulationOutput;
  materials: MaterialRow[];
  unitPrices: Record<string, number>;
  onChangeUnitPrice: (priceKey: string, value: number) => void;
  onResetPrices: () => void;
  onExportCsv: () => void;
  onExportJson: () => void;
  onExportPlanSvg: () => void;
}

const MAT_TO_PRICE_KEY: Record<string, string> = {
  'mat-coffret': 'coffret',
  'mat-diff-a': 'diffA',
  'mat-diff-ac': 'diffAC',
  'mat-para': 'parafoudre',
  'mat-jn': 'contacteur',
  'mat-tel': 'telerupteur',
  'mat-stairctrl': 'stairCtrl',
  'mat-brk-16': 'brk16',
  'mat-brk-20': 'brk20',
  'mat-brk-32': 'brk32',
  'mat-brk-40': 'brk32',
  'mat-cable-1.5': 'cable15',
  'mat-cable-2.5': 'cable25',
  'mat-cable-6': 'cable6',
  'mat-cable-10': 'cable6',
  'mat-sock': 'socket',
  'mat-sock2': 'socket2',
  'mat-usbsock': 'usb_socket',
  'mat-spec': 'spec',
  'mat-irve': 'irve',
  'mat-rj45': 'rj45',
  'mat-sw': 'switch',
  'mat-pb': 'pushbutton',
  'mat-dim': 'dimmer',
  'mat-mot': 'motion',
  'mat-light': 'light',
  'mat-sconce': 'sconce',
  'mat-spots': 'spot',
  'mat-neon': 'neon',
  'mat-stair-led': 'stair_led',
  'mat-heat': 'heater',
  'mat-ac-split': 'ac_split',
  'mat-ac-out': 'ac_outdoor',
  'mat-thermostat': 'thermostat',
  'mat-cook': 'cooktop',
  'mat-smoke': 'smoke',
  'mat-cam': 'camera',
  'mat-nvr': 'nvr_screen',
  'mat-alarm': 'alarm_panel',
  'mat-siren': 'siren',
  'mat-intercom': 'intercom',
};

export function BudgetReportView({
  sim,
  materials,
  unitPrices,
  onChangeUnitPrice,
  onResetPrices,
  onExportCsv,
  onExportJson,
  onExportPlanSvg,
}: BudgetReportViewProps) {
  const [vatRate, setVatRate] = useState<10 | 20>(10);
  const [includeLabor, setIncludeLabor] = useState(false);

  const materialsTotalHt = materials.reduce((sum, m) => sum + m.totalEur, 0);
  const laborEstimateHt = includeLabor ? sim.circuits.length * 145 : 0;
  const totalHt = materialsTotalHt + laborEstimateHt;
  const totalTtc = totalHt * (1 + vatRate / 100);

  return (
    <div className="space-y-6">
      {/* Top KPI Summary */}
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <div className="rounded-xl border border-slate-200 bg-white p-4 dark:border-slate-800 dark:bg-slate-900">
          <div className="text-xs text-slate-500 dark:text-slate-400">Fournitures (HT)</div>
          <div className="mt-1 font-mono text-2xl font-semibold tabular-nums text-slate-950 dark:text-white">
            {frNum(materialsTotalHt, 2)} €
          </div>
          <div className="mt-1 font-mono text-xs tabular-nums text-slate-500 dark:text-slate-400">
            {materials.length} lignes de nomenclature
          </div>
        </div>

        <div className="rounded-xl border border-slate-200 bg-white p-4 dark:border-slate-800 dark:bg-slate-900">
          <div className="text-xs text-slate-500 dark:text-slate-400">
            Estimation globale TTC
          </div>
          <div className="mt-1 font-mono text-2xl font-semibold tabular-nums text-slate-950 dark:text-white">
            {frNum(totalTtc, 2)} €
          </div>
          <div className="mt-1 font-mono text-xs tabular-nums text-slate-500 dark:text-slate-400">
            TVA {vatRate} % {includeLabor ? '· Pose incluse' : '· Matériel seul'}
          </div>
        </div>

        <div className="rounded-xl border border-slate-200 bg-white p-4 dark:border-slate-800 dark:bg-slate-900">
          <div className="text-xs text-slate-500 dark:text-slate-400">
            Coffret recommandé
          </div>
          <div className="mt-1 font-mono text-2xl font-semibold tabular-nums text-slate-950 dark:text-white">
            {sim.panel.recommendedRows} rangée{sim.panel.recommendedRows > 1 ? 's' : ''}
          </div>
          <div className="mt-1 font-mono text-xs tabular-nums text-slate-500 dark:text-slate-400">
            {sim.panel.totalModules} / {sim.panel.recommendedRows * 13} modules DIN
          </div>
        </div>

        <div className="rounded-xl border border-slate-200 bg-white p-4 dark:border-slate-800 dark:bg-slate-900">
          <div className="text-xs text-slate-500 dark:text-slate-400">
            Longueur totale câblage
          </div>
          <div className="mt-1 font-mono text-2xl font-semibold tabular-nums text-slate-950 dark:text-white">
            {frNum(
              sim.circuits.reduce((s, c) => s + (c.lengthM ?? 0), 0) * 1.1,
              0
            )}{' '}
            m
          </div>
          <div className="mt-1 text-xs text-slate-500 dark:text-slate-400">
            Marge de coupe 10 % comprise
          </div>
        </div>
      </div>

      {/* Controls & Exports Bar */}
      <div className="no-print flex flex-wrap items-center justify-between gap-3 rounded-xl border border-slate-200 bg-white px-4 py-3 dark:border-slate-800 dark:bg-slate-900">
        <div className="flex flex-wrap items-center gap-4 text-xs font-medium text-slate-700 dark:text-slate-300">
          <label className="inline-flex cursor-pointer items-center gap-2">
            <input
              type="checkbox"
              checked={includeLabor}
              onChange={(e) => setIncludeLabor(e.target.checked)}
              className="rounded border-slate-300"
            />
            <span>Inclure main-d’œuvre estimative (145 € HT / circuit)</span>
          </label>

          <label className="inline-flex items-center gap-2">
            <span>TVA</span>
            <select
              value={vatRate}
              onChange={(e) => setVatRate(Number(e.target.value) as 10 | 20)}
              className="rounded-md border border-slate-200 bg-slate-50 px-2 py-1 font-mono text-xs text-slate-900 dark:border-slate-700 dark:bg-slate-950 dark:text-white"
            >
              <option value={10}>10 % (Rénovation)</option>
              <option value={20}>20 % (Neuf)</option>
            </select>
          </label>

          <button
            type="button"
            onClick={onResetPrices}
            className="inline-flex items-center gap-1 text-slate-500 hover:text-slate-900 dark:text-slate-400 dark:hover:text-white"
          >
            <RotateCcw className="h-3.5 w-3.5" />
            <span>Tarifs par défaut</span>
          </button>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <button
            type="button"
            onClick={onExportCsv}
            className="inline-flex items-center gap-1.5 rounded-lg border border-slate-200 bg-white px-3 py-1.5 text-xs font-medium text-slate-700 hover:bg-slate-50 whitespace-nowrap dark:border-slate-700 dark:bg-slate-800 dark:text-slate-200 dark:hover:bg-slate-700"
          >
            <Download className="h-3.5 w-3.5" />
            <span>Matériel (.csv)</span>
          </button>
          <button
            type="button"
            onClick={onExportPlanSvg}
            className="inline-flex items-center gap-1.5 rounded-lg border border-slate-200 bg-white px-3 py-1.5 text-xs font-medium text-slate-700 hover:bg-slate-50 whitespace-nowrap dark:border-slate-700 dark:bg-slate-800 dark:text-slate-200 dark:hover:bg-slate-700"
          >
            <Download className="h-3.5 w-3.5" />
            <span>Plan 2D (.svg)</span>
          </button>
          <button
            type="button"
            onClick={onExportJson}
            className="inline-flex items-center gap-1.5 rounded-lg border border-slate-200 bg-white px-3 py-1.5 text-xs font-medium text-slate-700 hover:bg-slate-50 whitespace-nowrap dark:border-slate-700 dark:bg-slate-800 dark:text-slate-200 dark:hover:bg-slate-700"
          >
            <Download className="h-3.5 w-3.5" />
            <span>Projet (.json)</span>
          </button>
          <button
            type="button"
            onClick={() => window.print()}
            className="inline-flex items-center gap-1.5 rounded-lg bg-slate-900 px-3 py-1.5 text-xs font-medium text-white hover:bg-slate-800 whitespace-nowrap dark:bg-slate-100 dark:text-slate-950 dark:hover:bg-white"
          >
            <Printer className="h-3.5 w-3.5" />
            <span>Imprimer / PDF</span>
          </button>
        </div>
      </div>

      {/* Bill of Materials Table */}
      <section className="overflow-hidden rounded-xl border border-slate-200 bg-white dark:border-slate-800 dark:bg-slate-900">
        <div className="border-b border-slate-200 px-5 py-3.5 dark:border-slate-800">
          <h2 className="font-display text-base font-semibold text-slate-950 dark:text-white">
            Nomenclature détaillée & Chiffrage estimatif
          </h2>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full min-w-[680px] border-collapse text-left text-sm">
            <thead>
              <tr className="border-b border-slate-200 bg-slate-50 text-xs font-medium text-slate-500 dark:border-slate-800 dark:bg-slate-950/50 dark:text-slate-400">
                <th className="px-5 py-2.5">Lot</th>
                <th className="px-4 py-2.5">Désignation</th>
                <th className="px-4 py-2.5 text-right">Quantité</th>
                <th className="px-4 py-2.5 text-right">Prix unitaire (€ HT)</th>
                <th className="px-5 py-2.5 text-right">Total (€ HT)</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
              {materials.map((row) => {
                const priceKey = MAT_TO_PRICE_KEY[row.id];
                const currentPrice =
                  priceKey && unitPrices[priceKey] !== undefined
                    ? unitPrices[priceKey]
                    : row.unitPriceEur ?? DEFAULT_UNIT_PRICES[priceKey || ''] ?? 0;

                return (
                  <tr
                    key={row.id}
                    className="hover:bg-slate-50/70 dark:hover:bg-slate-800/40"
                  >
                    <td className="px-5 py-2.5 text-xs text-slate-500 dark:text-slate-400">
                      {row.category}
                    </td>
                    <td className="px-4 py-2.5 font-medium text-slate-900 dark:text-slate-100">
                      {row.label}
                    </td>
                    <td className="px-4 py-2.5 text-right font-mono text-xs tabular-nums text-slate-700 dark:text-slate-300">
                      {frNum(row.quantity)} {row.unit}
                    </td>
                    <td className="px-4 py-2.5 text-right">
                      {priceKey ? (
                        <input
                          type="number"
                          min={0}
                          step={0.5}
                          aria-label={`Prix unitaire ${row.label}`}
                          value={currentPrice}
                          onChange={(e) =>
                            onChangeUnitPrice(priceKey, Math.max(0, Number(e.target.value) || 0))
                          }
                          className="w-24 rounded border border-slate-200 bg-slate-50 px-2 py-1 text-right font-mono text-xs tabular-nums text-slate-900 dark:border-slate-700 dark:bg-slate-950 dark:text-white"
                        />
                      ) : (
                        <span className="font-mono text-xs tabular-nums text-slate-600 dark:text-slate-400">
                          {frNum(row.unitPriceEur, 2)}
                        </span>
                      )}
                    </td>
                    <td className="px-5 py-2.5 text-right font-mono text-xs font-semibold tabular-nums text-slate-950 dark:text-white">
                      {frNum(row.totalEur, 2)} €
                    </td>
                  </tr>
                );
              })}

              {includeLabor && (
                <tr className="bg-slate-50/50 dark:bg-slate-800/30">
                  <td className="px-5 py-2.5 text-xs text-slate-500 dark:text-slate-400">
                    Pose
                  </td>
                  <td className="px-4 py-2.5 font-medium text-slate-900 dark:text-slate-100">
                    Main-d’œuvre estimative (tirage, appareillage, raccordement tableau)
                  </td>
                  <td className="px-4 py-2.5 text-right font-mono text-xs tabular-nums text-slate-700 dark:text-slate-300">
                    {sim.circuits.length} circuits
                  </td>
                  <td className="px-4 py-2.5 text-right font-mono text-xs tabular-nums text-slate-600 dark:text-slate-400">
                    145,00
                  </td>
                  <td className="px-5 py-2.5 text-right font-mono text-xs font-semibold tabular-nums text-slate-950 dark:text-white">
                    {frNum(laborEstimateHt, 2)} €
                  </td>
                </tr>
              )}
            </tbody>
            <tfoot>
              <tr className="border-t border-slate-200 bg-slate-50/80 dark:border-slate-800 dark:bg-slate-950/60">
                <td colSpan={4} className="px-5 py-3 text-right text-xs font-medium text-slate-600 dark:text-slate-300">
                  Total HT / Total TTC ({vatRate} %)
                </td>
                <td className="px-5 py-3 text-right font-mono text-sm font-bold tabular-nums text-slate-950 dark:text-white">
                  {frNum(totalHt, 2)} € HT · {frNum(totalTtc, 2)} € TTC
                </td>
              </tr>
            </tfoot>
          </table>
        </div>
      </section>

      {/* Circuit Technical Schedule */}
      <section className="overflow-hidden rounded-xl border border-slate-200 bg-white dark:border-slate-800 dark:bg-slate-900">
        <div className="border-b border-slate-200 px-5 py-3.5 dark:border-slate-800">
          <h2 className="font-display text-base font-semibold text-slate-950 dark:text-white">
            Carnet de câblage & Protections par circuit
          </h2>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full min-w-[700px] border-collapse text-left text-sm">
            <thead>
              <tr className="border-b border-slate-200 bg-slate-50 text-xs font-medium text-slate-500 dark:border-slate-800 dark:bg-slate-950/50 dark:text-slate-400">
                <th className="px-5 py-2.5">Circuit</th>
                <th className="px-4 py-2.5">Différentiel</th>
                <th className="px-4 py-2.5">Disjoncteur</th>
                <th className="px-4 py-2.5">Section</th>
                <th className="px-4 py-2.5 text-right">Puissance</th>
                <th className="px-4 py-2.5 text-right">Longueur</th>
                <th className="px-5 py-2.5 text-right">Chute U</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
              {sim.circuits.map((c) => (
                <tr key={c.id} className="hover:bg-slate-50/70 dark:hover:bg-slate-800/40">
                  <td className="px-5 py-2.5 font-medium text-slate-900 dark:text-slate-100">
                    <span className="inline-flex items-center gap-2">
                      <span
                        className="h-2.5 w-2.5 rounded-sm"
                        style={{ backgroundColor: c.color }}
                      />
                      <span>{c.name}</span>
                    </span>
                  </td>
                  <td className="px-4 py-2.5 font-mono text-xs text-slate-600 dark:text-slate-300">
                    30 mA Type {c.diffType}
                  </td>
                  <td className="px-4 py-2.5 font-mono text-xs tabular-nums text-slate-700 dark:text-slate-300">
                    {c.breakerA} A
                  </td>
                  <td className="px-4 py-2.5 font-mono text-xs tabular-nums text-slate-700 dark:text-slate-300">
                    3G {frNum(c.sectionMm2, 1)} mm²
                  </td>
                  <td className="px-4 py-2.5 text-right font-mono text-xs tabular-nums text-slate-700 dark:text-slate-300">
                    {frNum(c.watts)} W ({frNum(c.currentA, 1)} A)
                  </td>
                  <td className="px-4 py-2.5 text-right font-mono text-xs tabular-nums text-slate-700 dark:text-slate-300">
                    {c.lengthM !== null ? `${frNum(c.lengthM)} m` : '—'}
                  </td>
                  <td
                    className={`px-5 py-2.5 text-right font-mono text-xs tabular-nums ${
                      c.dropPct !== null && c.dropPct > c.dropMaxPct
                        ? 'font-semibold text-red-700 dark:text-red-400'
                        : 'text-slate-600 dark:text-slate-300'
                    }`}
                  >
                    {c.dropPct !== null ? `${frNum(c.dropPct, 1)} %` : '—'}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </section>
    </div>
  );
}
