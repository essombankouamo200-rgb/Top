import { FinishStyle } from '../types/planelec';
import { FINISH_STYLES } from '../data/catalog';

interface LibraryPreviewIconProps {
  typeId: string;
  finishStyle?: FinishStyle;
}

/**
 * Renders a clear, realistic SVG miniature preview for every component
 * in ELECTRICAL_LIBRARY so users visually recognize each device.
 */
export function LibraryPreviewIcon({
  typeId,
  finishStyle = 'blanc_mat',
}: LibraryPreviewIconProps) {
  const styleCfg = FINISH_STYLES[finishStyle];

  switch (typeId) {
    case 'compteur_linky':
      return (
        <svg viewBox="0 0 64 64" className="h-12 w-12 shrink-0" aria-hidden="true">
          <rect x="10" y="6" width="44" height="52" rx="5" fill="#1e293b" stroke="#0f172a" strokeWidth="2" />
          <rect x="14" y="10" width="36" height="44" rx="3" fill="#a3e635" />
          <rect x="18" y="15" width="28" height="16" rx="2" fill="#ecfccb" stroke="#3f6212" strokeWidth="1" />
          <text x="32" y="26" textAnchor="middle" fontSize="7.5" fontFamily="JetBrains Mono, monospace" fontWeight="700" fill="#1a2e05">
            kWh
          </text>
          <circle cx="32" cy="40" r="3.5" fill="#1e293b" />
          <path d="M22 48 H28 M36 48 H42" stroke="#1e293b" strokeWidth="2" strokeLinecap="round" />
        </svg>
      );

    case 'compteur_horaire':
      return (
        <svg viewBox="0 0 64 64" className="h-12 w-12 shrink-0" aria-hidden="true">
          <rect x="12" y="6" width="40" height="52" rx="4" fill="#f8fafc" stroke="#334155" strokeWidth="2" />
          <rect x="16" y="12" width="32" height="14" rx="2" fill="#d1fae5" stroke="#047857" strokeWidth="1" />
          <text x="32" y="21.5" textAnchor="middle" fontSize="7" fontFamily="JetBrains Mono, monospace" fontWeight="700" fill="#065f46">
            HP / HC
          </text>
          <circle cx="32" cy="40" r="10" fill="#ffffff" stroke="#0f172a" strokeWidth="1.6" />
          <path d="M32 34 V40 L36 43" stroke="#0284c7" strokeWidth="1.8" strokeLinecap="round" fill="none" />
        </svg>
      );

    case 'agcp':
      return (
        <svg viewBox="0 0 64 64" className="h-12 w-12 shrink-0" aria-hidden="true">
          <rect x="10" y="6" width="44" height="52" rx="4" fill="#f1f5f9" stroke="#334155" strokeWidth="2" />
          <rect x="14" y="10" width="36" height="11" rx="2" fill="#cbd5e1" />
          <text x="32" y="18" textAnchor="middle" fontSize="7" fontWeight="700" fill="#0f172a">
            500 mA
          </text>
          <rect x="20" y="27" width="24" height="14" rx="2" fill="#0f172a" />
          <text x="32" y="36.5" textAnchor="middle" fontSize="7.5" fontWeight="700" fill="#ffffff">
            I / ON
          </text>
          <circle cx="22" cy="49" r="3" fill="#2563eb" />
          <circle cx="42" cy="49" r="3" fill="#dc2626" />
        </svg>
      );

    case 'bornier_l':
    case 'bornier_n': {
      const isPhase = typeId === 'bornier_l';
      return (
        <svg viewBox="0 0 64 64" className="h-12 w-12 shrink-0" aria-hidden="true">
          <rect
            x="6"
            y="20"
            width="52"
            height="24"
            rx="4"
            fill={isPhase ? '#dc2626' : '#2563eb'}
            stroke="#0f172a"
            strokeWidth="1.6"
          />
          {[14, 23, 32, 41, 50].map((cx) => (
            <circle key={cx} cx={cx} cy="32" r="3.2" fill="#e2e8f0" stroke="#0f172a" strokeWidth="1" />
          ))}
        </svg>
      );
    }

    case 'terre_piquet':
      return (
        <svg viewBox="0 0 64 64" className="h-12 w-12 shrink-0" aria-hidden="true">
          <rect x="8" y="10" width="48" height="14" rx="3" fill="#16a34a" stroke="#14532d" strokeWidth="1.5" />
          <path d="M32 24 V42 M18 42 H46 M23 48 H41 M27 54 H37" stroke="#16a34a" strokeWidth="3" strokeLinecap="round" fill="none" />
        </svg>
      );

    case 'diff_a':
    case 'diff_ac': {
      const isA = typeId === 'diff_a';
      return (
        <svg viewBox="0 0 64 64" className="h-12 w-12 shrink-0" aria-hidden="true">
          <rect
            x="10"
            y="6"
            width="44"
            height="52"
            rx="4"
            fill={isA ? '#fff7ed' : '#f8fafc'}
            stroke={isA ? '#c2410c' : '#334155'}
            strokeWidth="2"
          />
          <rect x="14" y="10" width="36" height="10" rx="2" fill={isA ? '#fed7aa' : '#e2e8f0'} />
          <text x="32" y="17.5" textAnchor="middle" fontSize="6.8" fontWeight="700" fill="#0f172a">
            {isA ? 'ID Type A' : 'ID Type AC'}
          </text>
          <rect x="16" y="25" width="12" height="10" rx="2" fill="#0284c7" />
          <text x="22" y="32" textAnchor="middle" fontSize="6.5" fontWeight="700" fill="#ffffff">
            T
          </text>
          <rect x="34" y="25" width="14" height="14" rx="2" fill="#16a34a" />
          <text x="41" y="34.5" textAnchor="middle" fontSize="6.5" fontWeight="700" fill="#ffffff">
            ON
          </text>
          <text x="32" y="51" textAnchor="middle" fontSize="7" fontFamily="JetBrains Mono, monospace" fill="#475569">
            30 mA
          </text>
        </svg>
      );
    }

    case 'disj_2a':
    case 'disj_16a':
    case 'disj_20a':
    case 'disj_32a': {
      const amp = typeId.replace('disj_', '').toUpperCase();
      return (
        <svg viewBox="0 0 64 64" className="h-12 w-12 shrink-0" aria-hidden="true">
          <rect x="16" y="6" width="32" height="52" rx="4" fill="#ffffff" stroke="#334155" strokeWidth="2" />
          <rect x="19" y="9" width="26" height="8" rx="1.5" fill="#e2e8f0" />
          <text x="32" y="15.5" textAnchor="middle" fontSize="7.5" fontWeight="700" fill="#0f172a">
            C{amp.replace('A', '')}
          </text>
          <rect x="22" y="26" width="20" height="12" rx="2" fill="#16a34a" />
          <text x="32" y="34.5" textAnchor="middle" fontSize="6.5" fontWeight="700" fill="#ffffff">
            I · ON
          </text>
          <circle cx="24" cy="51" r="2.5" fill="#2563eb" />
          <circle cx="40" cy="51" r="2.5" fill="#dc2626" />
        </svg>
      );
    }

    case 'parafoudre':
      return (
        <svg viewBox="0 0 64 64" className="h-12 w-12 shrink-0" aria-hidden="true">
          <rect x="12" y="6" width="40" height="52" rx="4" fill="#fef3c7" stroke="#d97706" strokeWidth="2" />
          <path d="M35 14 L24 32 H33 L29 48 L41 28 H32 Z" fill="#d97706" />
        </svg>
      );

    case 'telerupteur':
      return (
        <svg viewBox="0 0 64 64" className="h-12 w-12 shrink-0" aria-hidden="true">
          <rect x="14" y="6" width="36" height="52" rx="4" fill="#f3e8ff" stroke="#7c3aed" strokeWidth="2" />
          <text x="32" y="18" textAnchor="middle" fontSize="6.8" fontWeight="700" fill="#5b21b6">
            A1 / A2
          </text>
          <rect x="22" y="24" width="20" height="16" rx="2" fill="#ffffff" stroke="#7c3aed" strokeWidth="1.4" />
          <path d="M26 36 L36 27" stroke="#7c3aed" strokeWidth="2.2" strokeLinecap="round" />
          <text x="32" y="51" textAnchor="middle" fontSize="7" fontWeight="700" fill="#5b21b6">
            16 A
          </text>
        </svg>
      );

    case 'minuterie':
      return (
        <svg viewBox="0 0 64 64" className="h-12 w-12 shrink-0" aria-hidden="true">
          <rect x="14" y="6" width="36" height="52" rx="4" fill="#f8fafc" stroke="#475569" strokeWidth="2" />
          <circle cx="32" cy="30" r="12" fill="#fef3c7" stroke="#d97706" strokeWidth="1.8" />
          <path d="M32 23 V30 L37 33" stroke="#b45309" strokeWidth="2" strokeLinecap="round" fill="none" />
          <text x="32" y="52" textAnchor="middle" fontSize="6.5" fontWeight="700" fill="#334155">
            TEMPO
          </text>
        </svg>
      );

    case 'contacteur_jn':
      return (
        <svg viewBox="0 0 64 64" className="h-12 w-12 shrink-0" aria-hidden="true">
          <rect x="14" y="6" width="36" height="52" rx="4" fill="#eff6ff" stroke="#2563eb" strokeWidth="2" />
          <text x="32" y="18" textAnchor="middle" fontSize="7" fontWeight="700" fill="#1e40af">
            J / N
          </text>
          <rect x="20" y="23" width="24" height="22" rx="2" fill="#ffffff" stroke="#2563eb" strokeWidth="1.2" />
          <text x="32" y="32" textAnchor="middle" fontSize="6.5" fontWeight="700" fill="#16a34a">
            AUTO
          </text>
          <text x="32" y="41" textAnchor="middle" fontSize="6.5" fill="#64748b">
            I · 0
          </text>
        </svg>
      );

    case 'horloge_prog':
      return (
        <svg viewBox="0 0 64 64" className="h-12 w-12 shrink-0" aria-hidden="true">
          <rect x="10" y="6" width="44" height="52" rx="4" fill="#f8fafc" stroke="#334155" strokeWidth="2" />
          <rect x="15" y="12" width="34" height="16" rx="2" fill="#dbeafe" stroke="#1d4ed8" strokeWidth="1" />
          <text x="32" y="22.5" textAnchor="middle" fontSize="7" fontFamily="JetBrains Mono, monospace" fontWeight="700" fill="#1e3a8a">
            06:30
          </text>
          <circle cx="23" cy="40" r="3" fill="#475569" />
          <circle cx="32" cy="40" r="3" fill="#475569" />
          <circle cx="41" cy="40" r="3" fill="#475569" />
        </svg>
      );

    case 'ctrl_escalier':
      return (
        <svg viewBox="0 0 64 64" className="h-12 w-12 shrink-0" aria-hidden="true">
          <rect x="8" y="10" width="48" height="44" rx="5" fill="#1e293b" stroke="#ca8a04" strokeWidth="2" />
          {[0, 1, 2, 3, 4].map((i) => (
            <rect
              key={i}
              x={14 + i * 7}
              y={42 - i * 5}
              width="6"
              height="4"
              rx="1"
              fill={i >= 1 && i <= 3 ? '#fde047' : '#64748b'}
            />
          ))}
          <text x="32" y="50" textAnchor="middle" fontSize="6.5" fontWeight="700" fill="#fde047">
            24V LED
          </text>
        </svg>
      );

    case 'delesteur':
      return (
        <svg viewBox="0 0 64 64" className="h-12 w-12 shrink-0" aria-hidden="true">
          <rect x="12" y="8" width="40" height="48" rx="4" fill="#f8fafc" stroke="#334155" strokeWidth="2" />
          <path d="M18 36 L26 24 L32 32 L42 18" stroke="#dc2626" strokeWidth="2.5" fill="none" strokeLinecap="round" strokeLinejoin="round" />
          <text x="32" y="49" textAnchor="middle" fontSize="6.5" fontWeight="700" fill="#334155">
            45 A MAX
          </text>
        </svg>
      );

    case 'centrale_alarme':
      return (
        <svg viewBox="0 0 64 64" className="h-12 w-12 shrink-0" aria-hidden="true">
          <rect x="8" y="12" width="48" height="40" rx="5" fill="#0f766e" stroke="#134e4a" strokeWidth="2" />
          <rect x="14" y="17" width="36" height="11" rx="2" fill="#ccfbf1" />
          <circle cx="20" cy="36" r="2.2" fill="#ffffff" />
          <circle cx="28" cy="36" r="2.2" fill="#ffffff" />
          <circle cx="36" cy="36" r="2.2" fill="#ffffff" />
          <circle cx="44" cy="36" r="2.2" fill="#ffffff" />
          <circle cx="20" cy="44" r="2.2" fill="#ffffff" />
          <circle cx="28" cy="44" r="2.2" fill="#ffffff" />
          <circle cx="36" cy="44" r="2.2" fill="#ffffff" />
          <circle cx="44" cy="44" r="2.2" fill="#fde047" />
        </svg>
      );

    case 'camera_ip':
      return (
        <svg viewBox="0 0 64 64" className="h-12 w-12 shrink-0" aria-hidden="true">
          <path d="M36 28 L58 14 V50 Z" fill="#0d9488" fillOpacity="0.2" stroke="#0d9488" strokeWidth="1.2" strokeDasharray="3 2" />
          <rect x="10" y="22" width="24" height="16" rx="4" fill="#f8fafc" stroke="#0f172a" strokeWidth="2" />
          <rect x="34" y="25" width="6" height="10" rx="1.5" fill="#0d9488" />
          <path d="M10 38 V48 H18" stroke="#475569" strokeWidth="2.5" fill="none" strokeLinecap="round" />
          <circle cx="20" cy="30" r="3" fill="#0d9488" />
        </svg>
      );

    case 'detecteur_mvt':
      return (
        <svg viewBox="0 0 64 64" className="h-12 w-12 shrink-0" aria-hidden="true">
          <rect x="18" y="10" width="28" height="32" rx="6" fill="#f8fafc" stroke="#334155" strokeWidth="2" />
          <ellipse cx="32" cy="28" rx="9" ry="7" fill="#cbd5e1" stroke="#64748b" strokeWidth="1.2" />
          <path d="M18 48 A18 18 0 0 0 46 48" stroke="#0891b2" strokeWidth="2" fill="none" strokeDasharray="3 3" />
        </svg>
      );

    case 'sirene':
      return (
        <svg viewBox="0 0 64 64" className="h-12 w-12 shrink-0" aria-hidden="true">
          <path d="M18 16 H46 L40 40 H24 Z" fill="#fee2e2" stroke="#dc2626" strokeWidth="2" />
          <circle cx="32" cy="28" r="5" fill="#dc2626" />
          <path d="M14 46 A22 22 0 0 0 50 46" stroke="#dc2626" strokeWidth="2.2" fill="none" strokeLinecap="round" />
        </svg>
      );

    case 'daaf':
      return (
        <svg viewBox="0 0 64 64" className="h-12 w-12 shrink-0" aria-hidden="true">
          <circle cx="32" cy="32" r="22" fill="#ffffff" stroke="#334155" strokeWidth="2" />
          <circle cx="32" cy="32" r="14" fill="none" stroke="#94a3b8" strokeWidth="1.5" strokeDasharray="3 3" />
          <circle cx="32" cy="32" r="4" fill="#ef4444" />
        </svg>
      );

    case 'onduleur':
      return (
        <svg viewBox="0 0 64 64" className="h-12 w-12 shrink-0" aria-hidden="true">
          <rect x="14" y="10" width="36" height="44" rx="4" fill="#1e293b" stroke="#0f172a" strokeWidth="2" />
          <rect x="20" y="16" width="24" height="10" rx="2" fill="#0ea5e9" />
          <path d="M34 30 L27 39 H33 L30 48 L39 37 H33 Z" fill="#22c55e" />
        </svg>
      );

    case 'bouton_poussoir':
      return (
        <svg viewBox="0 0 64 64" className="h-12 w-12 shrink-0" aria-hidden="true">
          <rect x="10" y="10" width="44" height="44" rx="6" fill={styleCfg.frameHex} stroke="#475569" strokeWidth="2" />
          <rect x="19" y="19" width="26" height="26" rx="3" fill={styleCfg.plateHex} stroke="#64748b" strokeWidth="1.4" />
          <circle cx="32" cy="32" r="4" fill="#ea580c" />
        </svg>
      );

    case 'inter_va_et_vient':
      return (
        <svg viewBox="0 0 64 64" className="h-12 w-12 shrink-0" aria-hidden="true">
          <rect x="10" y="10" width="44" height="44" rx="6" fill={styleCfg.frameHex} stroke="#475569" strokeWidth="2" />
          <rect x="19" y="19" width="26" height="26" rx="3" fill={styleCfg.plateHex} stroke="#64748b" strokeWidth="1.4" />
          <line x1="25" y1="32" x2="39" y2="32" stroke={styleCfg.accentHex} strokeWidth="2" />
        </svg>
      );

    case 'prise_16a':
      return (
        <svg viewBox="0 0 64 64" className="h-12 w-12 shrink-0" aria-hidden="true">
          <rect x="10" y="10" width="44" height="44" rx="6" fill={styleCfg.frameHex} stroke="#475569" strokeWidth="2" />
          <circle cx="32" cy="32" r="14" fill={styleCfg.plateHex} stroke="#64748b" strokeWidth="1.4" />
          <circle cx="26" cy="32" r="2.4" fill="#0f172a" />
          <circle cx="38" cy="32" r="2.4" fill="#0f172a" />
          <circle cx="32" cy="24" r="2" fill="#16a34a" />
        </svg>
      );

    case 'prise_usb':
      return (
        <svg viewBox="0 0 64 64" className="h-12 w-12 shrink-0" aria-hidden="true">
          <rect x="8" y="10" width="48" height="44" rx="6" fill={styleCfg.frameHex} stroke="#475569" strokeWidth="2" />
          <circle cx="25" cy="32" r="11" fill={styleCfg.plateHex} stroke="#64748b" strokeWidth="1.4" />
          <circle cx="21" cy="32" r="2" fill="#0f172a" />
          <circle cx="29" cy="32" r="2" fill="#0f172a" />
          <rect x="40" y="23" width="9" height="18" rx="2" fill="#2563eb" />
        </svg>
      );

    case 'borne_ve':
      return (
        <svg viewBox="0 0 64 64" className="h-12 w-12 shrink-0" aria-hidden="true">
          <rect x="14" y="8" width="36" height="48" rx="6" fill="#0f172a" stroke="#0284c7" strokeWidth="2" />
          <path d="M34 18 L25 32 H32 L29 44 L40 29 H33 Z" fill="#38bdf8" />
        </svg>
      );

    case 'lampe_dcl':
      return (
        <svg viewBox="0 0 64 64" className="h-12 w-12 shrink-0" aria-hidden="true">
          <circle cx="32" cy="32" r="20" fill="#fef08a" fillOpacity="0.45" />
          <circle cx="32" cy="32" r="14" fill="#fef9c3" stroke="#ca8a04" strokeWidth="2.2" />
          <path d="M23 23 L41 41 M41 23 L23 41" stroke="#a16207" strokeWidth="2.2" strokeLinecap="round" />
        </svg>
      );

    case 'escalier_led':
      return (
        <svg viewBox="0 0 64 64" className="h-12 w-12 shrink-0" aria-hidden="true">
          {[0, 1, 2, 3, 4].map((i) => (
            <g key={i}>
              <rect
                x={10 + i * 8}
                y={46 - i * 8}
                width="18"
                height="6"
                rx="1.5"
                fill="#e2e8f0"
                stroke="#64748b"
                strokeWidth="1"
              />
              <line
                x1={11 + i * 8}
                y1={51 - i * 8}
                x2={27 + i * 8}
                y2={51 - i * 8}
                stroke={i >= 1 && i <= 3 ? '#facc15' : '#94a3b8'}
                strokeWidth="2.5"
                strokeLinecap="round"
              />
            </g>
          ))}
        </svg>
      );

    case 'chauffe_eau':
      return (
        <svg viewBox="0 0 64 64" className="h-12 w-12 shrink-0" aria-hidden="true">
          <rect x="18" y="8" width="28" height="44" rx="12" fill="#f8fafc" stroke="#334155" strokeWidth="2" />
          <path d="M26 24 C29 20, 35 28, 38 24" stroke="#ef4444" strokeWidth="2.5" fill="none" strokeLinecap="round" />
          <path d="M26 32 C29 28, 35 36, 38 32" stroke="#ef4444" strokeWidth="2.5" fill="none" strokeLinecap="round" />
          <line x1="25" y1="52" x2="25" y2="58" stroke="#2563eb" strokeWidth="2.5" />
          <line x1="39" y1="52" x2="39" y2="58" stroke="#dc2626" strokeWidth="2.5" />
        </svg>
      );

    case 'radiateur_elec':
      return (
        <svg viewBox="0 0 64 64" className="h-12 w-12 shrink-0" aria-hidden="true">
          <rect x="8" y="16" width="48" height="32" rx="4" fill="#f8fafc" stroke="#334155" strokeWidth="2" />
          {[16, 24, 32, 40, 48].map((x) => (
            <line key={x} x1={x} y1="20" x2={x} y2="44" stroke="#94a3b8" strokeWidth="2.5" strokeLinecap="round" />
          ))}
          <circle cx="50" cy="22" r="2.2" fill="#ef4444" />
        </svg>
      );

    case 'disj_courbe_d':
      return (
        <svg viewBox="0 0 64 64" className="h-12 w-12 shrink-0" aria-hidden="true">
          <rect x="16" y="6" width="32" height="52" rx="4" fill="#ecfeff" stroke="#0891b2" strokeWidth="2" />
          <rect x="19" y="9" width="26" height="8" rx="1.5" fill="#cffafe" />
          <text x="32" y="15.5" textAnchor="middle" fontSize="7" fontWeight="700" fill="#164e63">
            D20
          </text>
          <rect x="22" y="26" width="20" height="12" rx="2" fill="#0891b2" />
          <text x="32" y="34.5" textAnchor="middle" fontSize="6.5" fontWeight="700" fill="#ffffff">
            CLIM
          </text>
          <circle cx="24" cy="51" r="2.5" fill="#2563eb" />
          <circle cx="40" cy="51" r="2.5" fill="#dc2626" />
        </svg>
      );

    case 'sectionneur_clim':
      return (
        <svg viewBox="0 0 64 64" className="h-12 w-12 shrink-0" aria-hidden="true">
          <rect x="12" y="10" width="40" height="44" rx="5" fill="#f1f5f9" stroke="#334155" strokeWidth="2" />
          <circle cx="32" cy="30" r="11" fill="#fde047" stroke="#ca8a04" strokeWidth="1.8" />
          <rect x="29" y="21" width="6" height="18" rx="2" fill="#dc2626" transform="rotate(35 32 30)" />
          <text x="32" y="50" textAnchor="middle" fontSize="6.5" fontWeight="700" fill="#334155">
            IP65
          </text>
        </svg>
      );

    case 'thermostat_clim':
      return (
        <svg viewBox="0 0 64 64" className="h-12 w-12 shrink-0" aria-hidden="true">
          <rect x="12" y="14" width="40" height="36" rx="5" fill="#f8fafc" stroke="#334155" strokeWidth="2" />
          <rect x="17" y="19" width="30" height="16" rx="2" fill="#e0f2fe" stroke="#0284c7" strokeWidth="1.2" />
          <text x="32" y="30" textAnchor="middle" fontSize="8" fontFamily="JetBrains Mono, monospace" fontWeight="700" fill="#0369a1">
            21°C
          </text>
          <circle cx="24" cy="42" r="2.5" fill="#0284c7" />
          <circle cx="40" cy="42" r="2.5" fill="#ef4444" />
        </svg>
      );

    case 'clim_split':
      return (
        <svg viewBox="0 0 64 64" className="h-12 w-12 shrink-0" aria-hidden="true">
          <rect x="6" y="18" width="52" height="22" rx="5" fill="#ffffff" stroke="#0284c7" strokeWidth="2" />
          <line x1="12" y1="33" x2="52" y2="33" stroke="#94a3b8" strokeWidth="2" strokeLinecap="round" />
          <path d="M18 44 Q16 50 20 54 M32 44 Q30 50 34 54 M46 44 Q44 50 48 54" stroke="#38bdf8" strokeWidth="2" fill="none" strokeLinecap="round" />
          <circle cx="49" cy="24" r="2.2" fill="#22c55e" />
        </svg>
      );

    case 'clim_groupe_ext':
      return (
        <svg viewBox="0 0 64 64" className="h-12 w-12 shrink-0" aria-hidden="true">
          <rect x="8" y="12" width="48" height="40" rx="4" fill="#e2e8f0" stroke="#334155" strokeWidth="2" />
          <circle cx="27" cy="32" r="13" fill="#1e293b" stroke="#475569" strokeWidth="1.5" />
          <path d="M27 21 L30 32 L27 43 L24 32 Z M16 32 L27 29 L38 32 L27 35 Z" fill="#94a3b8" />
          <line x1="45" y1="20" x2="51" y2="20" stroke="#475569" strokeWidth="2" />
          <line x1="45" y1="26" x2="51" y2="26" stroke="#475569" strokeWidth="2" />
          <line x1="45" y1="32" x2="51" y2="32" stroke="#475569" strokeWidth="2" />
        </svg>
      );

    case 'ecran_nvr':
      return (
        <svg viewBox="0 0 64 64" className="h-12 w-12 shrink-0" aria-hidden="true">
          <rect x="8" y="12" width="48" height="34" rx="3" fill="#0f172a" stroke="#334155" strokeWidth="2" />
          <rect x="12" y="16" width="19" height="12" fill="#0d9488" fillOpacity="0.45" stroke="#14b8a6" strokeWidth="0.8" />
          <rect x="33" y="16" width="19" height="12" fill="#0284c7" fillOpacity="0.45" stroke="#38bdf8" strokeWidth="0.8" />
          <rect x="12" y="30" width="19" height="12" fill="#0284c7" fillOpacity="0.35" stroke="#38bdf8" strokeWidth="0.8" />
          <rect x="33" y="30" width="19" height="12" fill="#0d9488" fillOpacity="0.35" stroke="#14b8a6" strokeWidth="0.8" />
          <path d="M26 46 H38 L41 53 H23 Z" fill="#475569" />
        </svg>
      );

    default:
      return (
        <svg viewBox="0 0 64 64" className="h-12 w-12 shrink-0" aria-hidden="true">
          <rect x="12" y="12" width="40" height="40" rx="6" fill="#f1f5f9" stroke="#475569" strokeWidth="2" />
        </svg>
      );
  }
}
