import { Project, Task, TaskCategory, TaskStatus, TeamMember } from '../types/project';
import { CATEGORIES, STATUS_CONFIG } from '../data/seedData';
import { isOverdue } from '../utils/formatters';
import { Avatar } from './Avatar';

interface AnalyticsViewProps {
  project: Project;
  tasks: Task[];
  members: TeamMember[];
}

export function AnalyticsView({ project, tasks, members }: AnalyticsViewProps) {
  const totalTasks = tasks.length;
  const doneTasks = tasks.filter((t) => t.statut === 'termine').length;
  const completionRate = totalTasks > 0 ? Math.round((doneTasks / totalTasks) * 100) : 0;

  const totalEstimated = tasks.reduce((sum, t) => sum + t.heuresEstimees, 0);
  const totalLogged = tasks.reduce((sum, t) => sum + t.heuresPassees, 0);
  const urgentOrOverdue = tasks.filter(
    (t) =>
      t.statut !== 'termine' &&
      (t.priorite === 'urgente' || isOverdue(t.echeance, false))
  ).length;

  const statusBreakdown = (Object.keys(STATUS_CONFIG) as TaskStatus[]).map((status) => {
    const count = tasks.filter((t) => t.statut === status).length;
    const hours = tasks
      .filter((t) => t.statut === status)
      .reduce((sum, t) => sum + t.heuresEstimees, 0);
    return {
      status,
      label: STATUS_CONFIG[status].label,
      count,
      hours,
      pct: totalTasks > 0 ? Math.round((count / totalTasks) * 100) : 0,
    };
  });

  const memberWorkload = members.map((member) => {
    const assigned = tasks.filter((t) => t.assigneeId === member.id);
    const activeHours = assigned
      .filter((t) => t.statut !== 'termine')
      .reduce((sum, t) => sum + Math.max(0, t.heuresEstimees - t.heuresPassees), 0);
    const completedCount = assigned.filter((t) => t.statut === 'termine').length;
    const utilization = Math.min(
      140,
      Math.round((activeHours / member.capaciteHebdo) * 100)
    );
    return {
      member,
      totalAssigned: assigned.length,
      completedCount,
      activeHours,
      utilization,
    };
  });

  const categoryBreakdown = CATEGORIES.map((cat: TaskCategory) => {
    const catTasks = tasks.filter((t) => t.categorie === cat);
    return {
      category: cat,
      count: catTasks.length,
      hours: catTasks.reduce((sum, t) => sum + t.heuresEstimees, 0),
    };
  }).filter((item) => item.count > 0);

  return (
    <div className="space-y-6">
      <div className="rounded-xl border border-slate-200 bg-white p-5 dark:border-slate-800 dark:bg-slate-900">
        <div className="text-xs font-medium text-slate-500 dark:text-slate-400">
          Objectif du cycle — {project.nom}
        </div>
        <p className="mt-1.5 text-sm font-medium text-slate-900 dark:text-slate-100">
          {project.objectifSprint}
        </p>
      </div>

      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-4">
        <div className="rounded-xl border border-slate-200 bg-white p-5 dark:border-slate-800 dark:bg-slate-900">
          <div className="text-xs font-medium text-slate-500 dark:text-slate-400">
            Avancement du projet
          </div>
          <div className="mt-2 font-mono text-2xl font-semibold tabular-nums text-slate-950 dark:text-white">
            {completionRate} %
          </div>
          <div className="mt-1 font-mono text-xs tabular-nums text-slate-500 dark:text-slate-400">
            {doneTasks} sur {totalTasks} tâches terminées
          </div>
        </div>

        <div className="rounded-xl border border-slate-200 bg-white p-5 dark:border-slate-800 dark:bg-slate-900">
          <div className="text-xs font-medium text-slate-500 dark:text-slate-400">
            Heures réalisées / estimées
          </div>
          <div className="mt-2 font-mono text-2xl font-semibold tabular-nums text-slate-950 dark:text-white">
            {totalLogged}h <span className="text-base font-normal text-slate-400">/ {totalEstimated}h</span>
          </div>
          <div className="mt-1 font-mono text-xs tabular-nums text-slate-500 dark:text-slate-400">
            {Math.max(0, totalEstimated - totalLogged)}h restantes estimées
          </div>
        </div>

        <div className="rounded-xl border border-slate-200 bg-white p-5 dark:border-slate-800 dark:bg-slate-900">
          <div className="text-xs font-medium text-slate-500 dark:text-slate-400">
            Points d’attention
          </div>
          <div className="mt-2 font-mono text-2xl font-semibold tabular-nums text-slate-950 dark:text-white">
            {urgentOrOverdue}
          </div>
          <div className="mt-1 text-xs text-slate-500 dark:text-slate-400">
            Tâches urgentes ou hors délai
          </div>
        </div>

        <div className="rounded-xl border border-slate-200 bg-white p-5 dark:border-slate-800 dark:bg-slate-900">
          <div className="text-xs font-medium text-slate-500 dark:text-slate-400">
            Sous-tâches validées
          </div>
          <div className="mt-2 font-mono text-2xl font-semibold tabular-nums text-slate-950 dark:text-white">
            {tasks.reduce((sum, t) => sum + t.sousTaches.filter((s) => s.terminee).length, 0)}
            <span className="text-base font-normal text-slate-400">
              {' / '}
              {tasks.reduce((sum, t) => sum + t.sousTaches.length, 0)}
            </span>
          </div>
          <div className="mt-1 text-xs text-slate-500 dark:text-slate-400">
            Livrables intermédiaires cochés
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 gap-6 lg:grid-cols-2">
        <section className="rounded-xl border border-slate-200 bg-white p-5 dark:border-slate-800 dark:bg-slate-900">
          <h2 className="font-display text-base font-semibold text-slate-900 dark:text-slate-100">
            Répartition par statut
          </h2>

          <div className="mt-4 flex h-3 w-full overflow-hidden rounded-full bg-slate-100 dark:bg-slate-800">
            {statusBreakdown.map((item) => {
              if (item.pct === 0) return null;
              const color =
                item.status === 'termine'
                  ? 'bg-emerald-600 dark:bg-emerald-500'
                  : item.status === 'revue'
                  ? 'bg-amber-500'
                  : item.status === 'en_cours'
                  ? 'bg-indigo-600 dark:bg-indigo-500'
                  : 'bg-slate-400 dark:bg-slate-600';
              return (
                <div
                  key={item.status}
                  style={{ width: `${item.pct}%` }}
                  className={color}
                  title={`${item.label}: ${item.count}`}
                />
              );
            })}
          </div>

          <div className="mt-5 divide-y divide-slate-100 dark:divide-slate-800">
            {statusBreakdown.map((item) => (
              <div key={item.status} className="flex items-center justify-between py-2.5 text-sm">
                <span className="font-medium text-slate-700 dark:text-slate-200">
                  {item.label}
                </span>
                <span className="font-mono text-xs tabular-nums text-slate-500 dark:text-slate-400">
                  {item.count} tâche(s) · {item.hours}h · {item.pct} %
                </span>
              </div>
            ))}
          </div>
        </section>

        <section className="rounded-xl border border-slate-200 bg-white p-5 dark:border-slate-800 dark:bg-slate-900">
          <h2 className="font-display text-base font-semibold text-slate-900 dark:text-slate-100">
            Charge restante par membre
          </h2>

          <div className="mt-4 space-y-4">
            {memberWorkload.map(({ member, totalAssigned, completedCount, activeHours, utilization }) => (
              <div key={member.id} className="space-y-1.5">
                <div className="flex items-center justify-between gap-3">
                  <div className="flex items-center gap-2.5">
                    <Avatar member={member} size="md" />
                    <div>
                      <div className="text-sm font-medium text-slate-900 dark:text-slate-100">
                        {member.nom}
                      </div>
                      <div className="text-xs text-slate-500 dark:text-slate-400">
                        {member.role} · {completedCount}/{totalAssigned} terminées
                      </div>
                    </div>
                  </div>
                  <div className="text-right font-mono text-xs tabular-nums text-slate-700 dark:text-slate-300">
                    {activeHours}h / {member.capaciteHebdo}h
                  </div>
                </div>
                <div className="h-2 w-full overflow-hidden rounded-full bg-slate-100 dark:bg-slate-800">
                  <div
                    className={`h-full transition-all ${
                      utilization > 100
                        ? 'bg-red-600 dark:bg-red-500'
                        : utilization > 75
                        ? 'bg-amber-500'
                        : 'bg-slate-800 dark:bg-slate-200'
                    }`}
                    style={{ width: `${Math.min(100, utilization)}%` }}
                  />
                </div>
              </div>
            ))}
          </div>
        </section>
      </div>

      {categoryBreakdown.length > 0 && (
        <section className="rounded-xl border border-slate-200 bg-white p-5 dark:border-slate-800 dark:bg-slate-900">
          <h2 className="font-display text-base font-semibold text-slate-900 dark:text-slate-100">
            Volume par domaine technique
          </h2>
          <div className="mt-4 grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-5">
            {categoryBreakdown.map((item) => (
              <div
                key={item.category}
                className="border-t border-slate-200 pt-3 dark:border-slate-800"
              >
                <div className="text-xs font-medium text-slate-500 dark:text-slate-400">
                  {item.category}
                </div>
                <div className="mt-1 font-mono text-lg font-semibold tabular-nums text-slate-900 dark:text-slate-100">
                  {item.hours}h
                </div>
                <div className="font-mono text-xs tabular-nums text-slate-500 dark:text-slate-400">
                  {item.count} tâche(s)
                </div>
              </div>
            ))}
          </div>
        </section>
      )}
    </div>
  );
}
