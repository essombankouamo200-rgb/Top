import { FinishStyle, ItemType, PlanItem } from '../types/planelec';
import { FINISH_STYLES, TYPES } from '../data/catalog';
import { spotLen } from '../utils/electricalEngine';

export function getItemBounds(it: PlanItem): {
  kind: 'circle' | 'rect';
  c?: [number, number, number];
  r?: [number, number, number, number];
} {
  const T = TYPES[it.type];
  if (it.type === 'spots') {
    const L = spotLen(it);
    return { kind: 'rect', r: [-L / 2 - 16, -16, L + 32, 32] };
  }
  if (it.type === 'neon') {
    const len = it.len ?? 200;
    return { kind: 'rect', r: [-len / 2 - 10, -12, len + 20, 24] };
  }
  if (it.type === 'staircase' || T.furn) {
    const w = it.w ?? T.w ?? 100;
    const h = it.h ?? T.h ?? 220;
    const hh = Math.max(h, 24);
    return { kind: 'rect', r: [-w / 2 - 4, -hh / 2 - 4, w + 8, hh + 8] };
  }
  if (T.struct) {
    const len = it.len ?? T.len ?? 90;
    return { kind: 'circle', c: [0, 0, len / 2 + 10] };
  }
  const map: Partial<Record<ItemType, [number, number, number]>> = {
    light: [0, 0, 24],
    smoke: [0, 0, 24],
    sconce: [0, 12, 24],
    switch: [0, 12, 24],
    pushbutton: [0, 12, 24],
    dimmer: [0, 12, 24],
    motion: [0, 12, 24],
    socket: [0, 10, 24],
    socket2: [0, 10, 30],
    usb_socket: [0, 10, 26],
    spec: [0, 10, 24],
    irve: [0, 14, 32],
    rj45: [0, 10, 24],
    heater: [0, 8, 44],
    ac_split: [0, 10, 44],
    ac_outdoor: [0, 14, 46],
    thermostat: [0, 10, 24],
    cooktop: [0, 32, 46],
    camera: [0, 12, 24],
    nvr_screen: [0, 10, 30],
    alarm_panel: [0, 10, 28],
    siren: [0, 10, 24],
    intercom: [0, 10, 24],
    panel: [0, 9, 30],
  };
  return { kind: 'circle', c: map[it.type] ?? [0, 0, 24] };
}

export const TOOLBAR_ICON_TRANSFORMS: Partial<Record<ItemType, string>> = {
  sconce: 'translate(0 -9)',
  spots: 'scale(.72)',
  switch: 'translate(0 -10)',
  pushbutton: 'translate(0 -10)',
  dimmer: 'translate(0 -10)',
  motion: 'translate(0 -10)',
  socket: 'translate(0 -8)',
  socket2: 'translate(0 -8) scale(.85)',
  usb_socket: 'translate(0 -8) scale(.9)',
  spec: 'translate(0 -8)',
  irve: 'translate(0 -12) scale(.85)',
  rj45: 'translate(0 -7)',
  heater: 'translate(0 -8) scale(.85)',
  ac_split: 'translate(0 -8) scale(.82)',
  ac_outdoor: 'translate(0 -10) scale(.75)',
  thermostat: 'translate(0 -9)',
  cooktop: 'translate(0 -18) scale(.56)',
  camera: 'translate(0 -10)',
  nvr_screen: 'translate(0 -9) scale(.85)',
  alarm_panel: 'translate(0 -9) scale(.85)',
  siren: 'translate(0 -10)',
  intercom: 'translate(0 -10)',
  panel: 'translate(0 -9)',
  door: 'translate(0 -18) scale(.38)',
  window: 'translate(0 0) scale(.46)',
  staircase: 'scale(.16)',
};

export function SvgSymbol({
  item,
  color,
  isLit = false,
  finishStyle = 'blanc_mat',
  activeStairStep = null,
  showCameraFov = true,
}: {
  item: Pick<
    PlanItem,
    | 'type'
    | 'len'
    | 'count'
    | 'spacing'
    | 'w'
    | 'h'
    | 'stepCount'
    | 'ledColor'
    | 'camPlacement'
    | 'camAngle'
    | 'camFov'
    | 'camRange'
  >;
  color?: string;
  isLit?: boolean;
  finishStyle?: FinishStyle;
  activeStairStep?: number | null;
  showCameraFov?: boolean;
}) {
  const c = color || 'var(--pe-ink)';
  const styleCfg = FINISH_STYLES[finishStyle];
  const sw = 3;

  switch (item.type) {
    case 'staircase': {
      const w = item.w ?? 110;
      const h = item.h ?? 220;
      const steps = item.stepCount ?? 14;
      const stepH = h / steps;
      const x0 = -w / 2;
      const y0 = -h / 2;
      const ledHex =
        item.ledColor === 'amber'
          ? '#fb923c'
          : item.ledColor === 'neutral'
          ? '#f8fafc'
          : '#fde047';

      return (
        <g>
          {/* Staircase frame */}
          <rect
            x={x0}
            y={y0}
            width={w}
            height={h}
            rx="4"
            fill="var(--pe-panel)"
            stroke={c}
            strokeWidth={2.5}
          />
          {/* Individual treads + sequential LED lighting */}
          {Array.from({ length: steps }, (_, idx) => {
            const sy = y0 + idx * stepH;
            const stepNum = idx + 1;
            const dist =
              activeStairStep !== null ? Math.abs(stepNum - activeStairStep) : Infinity;
            const stepLit = isLit || dist <= 2;
            const intensity = isLit ? 0.6 : dist === 0 ? 0.95 : dist === 1 ? 0.65 : dist === 2 ? 0.35 : 0;

            return (
              <g key={idx}>
                <rect
                  x={x0 + 3}
                  y={sy + 1}
                  width={w - 6}
                  height={Math.max(2, stepH - 2)}
                  fill={stepLit ? ledHex : 'transparent'}
                  fillOpacity={intensity * 0.55}
                />
                <line
                  x1={x0}
                  y1={sy}
                  x2={x0 + w}
                  y2={sy}
                  stroke="var(--pe-muted)"
                  strokeWidth={1.2}
                />
                {/* LED strip edge */}
                <line
                  x1={x0 + 6}
                  y1={sy + stepH - 2}
                  x2={x0 + w - 6}
                  y2={sy + stepH - 2}
                  stroke={stepLit ? ledHex : '#94a3b8'}
                  strokeWidth={stepLit ? 3 : 1.2}
                  opacity={stepLit ? Math.max(0.45, intensity) : 0.35}
                />
              </g>
            );
          })}
          {/* Progression arrow */}
          <path
            d={`M0 ${y0 + h - 16} V${y0 + 18} M-10 ${y0 + 28} L0 ${y0 + 16} L10 ${y0 + 28}`}
            fill="none"
            stroke={c}
            strokeWidth={2.2}
            strokeLinecap="round"
            strokeLinejoin="round"
          />
          {activeStairStep !== null && activeStairStep >= 1 && activeStairStep <= steps && (
            <circle
              cx={0}
              cy={y0 + (activeStairStep - 0.5) * stepH}
              r={7}
              fill="#2563eb"
              stroke="#ffffff"
              strokeWidth={2}
            />
          )}
        </g>
      );
    }
    case 'light':
      return (
        <g stroke={c} strokeWidth={sw} strokeLinecap="round" strokeLinejoin="round" fill={isLit ? '#fef08a' : 'var(--pe-panel)'}>
          {isLit && <circle r="26" fill="#fde047" fillOpacity="0.34" stroke="none" />}
          <circle r="14" />
          <path d="M-9 -9L9 9M9 -9L-9 9" fill="none" />
        </g>
      );
    case 'sconce':
      return (
        <g stroke={c} strokeWidth={sw} strokeLinecap="round" strokeLinejoin="round" fill={isLit ? '#fef08a' : 'var(--pe-panel)'}>
          {isLit && <circle cy="10" r="22" fill="#fde047" fillOpacity="0.34" stroke="none" />}
          <path d="M-14 0H14" fill="none" />
          <path d="M-10 0A10 10 0 0 0 10 0Z" />
          <path d="M-17 13L-12 9M0 19V14M17 13L12 9" fill="none" strokeWidth={2.5} />
        </g>
      );
    case 'spots': {
      const n = item.count ?? 4;
      const sp = item.spacing ?? 80;
      const L = (n - 1) * sp;
      return (
        <g stroke={c} strokeWidth={sw} strokeLinecap="round" strokeLinejoin="round" fill={isLit ? '#fef08a' : 'var(--pe-panel)'}>
          {n > 1 && (
            <path d={`M${-L / 2} 0H${L / 2}`} strokeWidth={1.5} strokeDasharray="4 4" fill="none" />
          )}
          {Array.from({ length: n }, (_, idx) => {
            const x = -L / 2 + idx * sp;
            return (
              <g key={idx}>
                {isLit && <circle cx={x} r="16" fill="#fde047" fillOpacity="0.34" stroke="none" />}
                <circle cx={x} r="8" />
                <circle cx={x} r="2.5" fill={c} stroke="none" />
              </g>
            );
          })}
        </g>
      );
    }
    case 'neon': {
      const h = (item.len ?? 200) / 2;
      return (
        <g strokeLinecap="round" fill="none">
          <path
            d={`M${-h} 0H${h}`}
            stroke={isLit ? '#fde047' : c}
            strokeWidth={isLit ? 16 : 11}
            opacity={isLit ? 0.6 : 0.25}
          />
          <path d={`M${-h} 0H${h}`} stroke={c} strokeWidth={4} />
        </g>
      );
    }
    case 'switch':
      return (
        <g stroke={c} strokeWidth={sw} strokeLinecap="round" strokeLinejoin="round" fill={styleCfg.plateHex}>
          <path d="M0 0V6" fill="none" />
          <circle cy="13" r="7" />
          <path d="M4 8L12 0" fill="none" />
        </g>
      );
    case 'pushbutton':
      return (
        <g stroke={c} strokeWidth={2.8} strokeLinecap="round" strokeLinejoin="round" fill={styleCfg.plateHex}>
          <path d="M0 0V5" fill="none" />
          <rect x="-8" y="5" width="16" height="16" rx="3" />
          <circle cx="0" cy="13" r="3.5" fill={c} />
        </g>
      );
    case 'dimmer':
      return (
        <g stroke={c} strokeWidth={sw} strokeLinecap="round" strokeLinejoin="round" fill={styleCfg.plateHex}>
          <path d="M0 0V5" fill="none" />
          <circle cy="13" r="8" />
          <path d="M-4 17L5 9" fill="none" strokeWidth={2.2} />
          <circle cx="0" cy="13" r="2" fill={c} stroke="none" />
        </g>
      );
    case 'motion':
      return (
        <g stroke={c} strokeWidth={2.6} strokeLinecap="round" strokeLinejoin="round" fill={styleCfg.plateHex}>
          <path d="M-10 0H10L7 12H-7Z" />
          <path d="M-11 16A14 14 0 0 0 11 16" fill="none" strokeDasharray="3 3" />
        </g>
      );
    case 'socket':
      return (
        <g stroke={c} strokeWidth={sw} strokeLinecap="round" strokeLinejoin="round" fill={styleCfg.plateHex}>
          <path d="M-14 0H14" fill="none" />
          <path d="M-11 0A11 11 0 0 0 11 0Z" />
          <path d="M0 11V16" fill="none" />
        </g>
      );
    case 'socket2':
      return (
        <g stroke={c} strokeWidth={2.6} strokeLinecap="round" strokeLinejoin="round" fill={styleCfg.plateHex}>
          <path d="M-20 0H20" fill="none" />
          <path d="M-17 0A9 9 0 0 0 -1 0Z" />
          <path d="M1 0A9 9 0 0 0 17 0Z" />
          <path d="M-9 9V14M9 9V14" fill="none" />
        </g>
      );
    case 'usb_socket':
      return (
        <g stroke={c} strokeWidth={2.6} strokeLinecap="round" strokeLinejoin="round" fill={styleCfg.plateHex}>
          <path d="M-16 0H16" fill="none" />
          <path d="M-13 0A11 11 0 0 0 7 0Z" />
          <rect x="8" y="2" width="7" height="10" rx="1.5" fill={c} />
        </g>
      );
    case 'spec':
      return (
        <g stroke={c} strokeWidth={sw} strokeLinecap="round" strokeLinejoin="round" fill={c}>
          <path d="M-14 0H14" fill="none" />
          <path d="M-11 0A11 11 0 0 0 11 0Z" />
          <path d="M0 11V16" fill="none" />
        </g>
      );
    case 'irve':
      return (
        <g stroke={c} strokeWidth={2.8} strokeLinecap="round" strokeLinejoin="round" fill="var(--pe-panel)">
          <rect x="-15" y="2" width="30" height="20" rx="4" />
          <path d="M2 7L-3 13H2L-2 19" fill="none" strokeWidth={2.4} />
        </g>
      );
    case 'rj45':
      return (
        <g stroke={c} strokeWidth={sw} strokeLinecap="round" strokeLinejoin="round" fill={styleCfg.plateHex}>
          <rect x="-9" y="1" width="18" height="12" rx="2" />
          <path d="M-4 5H4M-4 9H4" fill="none" strokeWidth={2} />
        </g>
      );
    case 'heater':
      return (
        <g stroke={c} strokeWidth={sw} strokeLinecap="round" strokeLinejoin="round" fill="var(--pe-panel)">
          <rect x="-35" y="2" width="70" height="12" rx="2" />
          <path d="M-25 2V14M-15 2V14M-5 2V14M5 2V14M15 2V14M25 2V14" strokeWidth={2} fill="none" />
        </g>
      );
    case 'ac_split':
      return (
        <g stroke={c} strokeWidth={2.6} strokeLinecap="round" strokeLinejoin="round" fill="#e0f2fe">
          <rect x="-36" y="2" width="72" height="14" rx="4" />
          <line x1="-26" y1="11" x2="26" y2="11" stroke="#0284c7" strokeWidth={1.8} />
          <path d="M-16 19 L-19 24 M0 19 L-2 24 M16 19 L14 24" stroke="#0284c7" strokeWidth={1.6} fill="none" />
        </g>
      );
    case 'ac_outdoor':
      return (
        <g stroke={c} strokeWidth={2.6} strokeLinecap="round" strokeLinejoin="round" fill="#e2e8f0">
          <rect x="-34" y="2" width="68" height="22" rx="3" />
          <circle cx="-12" cy="13" r="8" fill="#1e293b" stroke="#475569" strokeWidth={1.5} />
          <path d="M-12 6 V20 M-19 13 H-5" stroke="#94a3b8" strokeWidth={1.8} />
          <path d="M8 8 H26 M8 13 H26 M8 18 H26" stroke="#475569" strokeWidth={1.8} />
        </g>
      );
    case 'thermostat':
      return (
        <g stroke={c} strokeWidth={2.5} strokeLinecap="round" strokeLinejoin="round" fill="var(--pe-panel)">
          <rect x="-11" y="2" width="22" height="15" rx="3" />
          <rect x="-7" y="5" width="14" height="6" rx="1" fill="#0284c7" fillOpacity="0.25" stroke="none" />
          <circle cx="0" cy="13.5" r="1.5" fill={c} stroke="none" />
        </g>
      );
    case 'cooktop':
      return (
        <g stroke={c} strokeWidth={sw} strokeLinecap="round" strokeLinejoin="round" fill="var(--pe-panel)">
          <rect x="-30" y="2" width="60" height="60" rx="4" />
          <circle cx="-15" cy="18" r="8" />
          <circle cx="15" cy="18" r="8" />
          <circle cx="-15" cy="46" r="8" />
          <circle cx="15" cy="46" r="8" />
        </g>
      );
    case 'smoke':
      return (
        <g stroke={c} strokeWidth={sw} strokeLinecap="round" strokeLinejoin="round" fill="var(--pe-panel)">
          <circle r="13" />
          <circle r="4" />
          <path d="M-13 0H-19M13 0H19" fill="none" />
        </g>
      );
    case 'camera': {
      const isExt = item.camPlacement === 'exterior';
      const baseRot = (isExt ? 180 : 0) + (item.camAngle ?? 0);
      const fovDeg = item.camFov ?? 90;
      const range = item.camRange ?? 450;
      const halfRad = ((fovDeg / 2) * Math.PI) / 180;
      const x1 = -Math.sin(halfRad) * range;
      const y1 = Math.cos(halfRad) * range;
      const x2 = Math.sin(halfRad) * range;
      const y2 = Math.cos(halfRad) * range;
      const largeArc = fovDeg > 180 ? 1 : 0;
      const fovColor = isExt ? '#0284c7' : '#0d9488';

      return (
        <g>
          {showCameraFov && (
            <g transform={`translate(0 8) rotate(${baseRot})`} pointerEvents="none">
              <path
                d={`M0 0 L${x1} ${y1} A${range} ${range} 0 ${largeArc} 0 ${x2} ${y2} Z`}
                fill={fovColor}
                fillOpacity="0.14"
                stroke={fovColor}
                strokeWidth="1.6"
                strokeDasharray="6 4"
              />
              <line
                x1="0"
                y1="0"
                x2="0"
                y2={range * 0.92}
                stroke={fovColor}
                strokeWidth="1.2"
                strokeDasharray="3 4"
                opacity="0.7"
              />
            </g>
          )}
          <g
            transform={`translate(0 8) rotate(${baseRot})`}
            stroke={c}
            strokeWidth={2.6}
            strokeLinecap="round"
            strokeLinejoin="round"
            fill="var(--pe-panel)"
          >
            <rect x="-10" y="-6" width="20" height="14" rx="3" />
            <path d="M-6 8 L-9 13 H9 L6 8 Z" fill={fovColor} fillOpacity="0.3" />
            <circle cx="0" cy="1" r="3" fill={fovColor} stroke="none" />
          </g>
        </g>
      );
    }
    case 'nvr_screen':
      return (
        <g stroke={c} strokeWidth={2.5} strokeLinecap="round" strokeLinejoin="round" fill="#0f172a">
          <rect x="-20" y="2" width="40" height="16" rx="2" />
          <path d="M-14 6 H-2 V14 H-14 Z M2 6 H14 V14 H2 Z" fill="#0d9488" fillOpacity="0.45" stroke="#38bdf8" strokeWidth={1.2} />
        </g>
      );
    case 'alarm_panel':
      return (
        <g stroke={c} strokeWidth={2.6} strokeLinecap="round" strokeLinejoin="round" fill="var(--pe-panel)">
          <rect x="-18" y="2" width="36" height="16" rx="3" />
          <path d="M-10 8H10 M-10 12H2" fill="none" strokeWidth={2} />
        </g>
      );
    case 'siren':
      return (
        <g stroke={c} strokeWidth={2.6} strokeLinecap="round" strokeLinejoin="round" fill="var(--pe-panel)">
          <path d="M-11 2H11L7 14H-7Z" />
          <path d="M-13 18A15 15 0 0 0 13 18" fill="none" strokeWidth={2} />
        </g>
      );
    case 'intercom':
      return (
        <g stroke={c} strokeWidth={2.6} strokeLinecap="round" strokeLinejoin="round" fill="var(--pe-panel)">
          <rect x="-9" y="2" width="18" height="22" rx="3" />
          <rect x="-5" y="5" width="10" height="7" rx="1" fill={c} fillOpacity="0.25" />
          <circle cx="0" cy="18" r="2.2" fill={c} stroke="none" />
        </g>
      );
    case 'panel':
      return (
        <g stroke={c} strokeWidth={sw} strokeLinecap="round" strokeLinejoin="round" fill={c}>
          <rect x="-20" y="2" width="40" height="14" rx="2" />
          <path d="M-8 5V13M0 5V13M8 5V13" stroke="var(--pe-floor)" strokeWidth={2.5} fill="none" />
        </g>
      );
    case 'door': {
      const l = item.len ?? 90;
      const h = l / 2;
      return (
        <g stroke={c} strokeWidth={3} strokeLinecap="round" fill="none">
          <rect x={-h} y="-9" width={l} height="18" fill="var(--pe-floor)" stroke="none" />
          <path d={`M${-h} -8V8M${h} -8V8M${-h} 0V${l}`} />
          <path d={`M${h} 0A${l} ${l} 0 0 1 ${-h} ${l}`} strokeWidth={1.5} strokeDasharray="5 4" />
        </g>
      );
    }
    case 'window': {
      const l = item.len ?? 120;
      const h = l / 2;
      return (
        <g stroke={c} strokeWidth={3} strokeLinecap="round" fill="none">
          <rect x={-h} y="-9" width={l} height="18" fill="var(--pe-floor)" stroke="none" />
          <path d={`M${-h} -8V8M${h} -8V8`} />
          <path d={`M${-h} -8H${h}M${-h} 0H${h}M${-h} 8H${h}`} strokeWidth={1.5} />
        </g>
      );
    }
    default:
      return null;
  }
}

export function SvgFurniture({
  item,
  strokeWidth = 2,
}: {
  item: Pick<PlanItem, 'type' | 'w' | 'h'>;
  strokeWidth?: number;
}) {
  const T = TYPES[item.type];
  const w = item.w ?? T.w ?? 80;
  const h = item.h ?? T.h ?? 80;
  const x = -w / 2;
  const y = -h / 2;

  const renderDetails = () => {
    switch (item.type) {
      case 'bed1':
      case 'bed2': {
        const n = item.type === 'bed2' ? 2 : 1;
        const pw = (w - (n + 1) * 8) / n;
        return (
          <>
            {Array.from({ length: n }, (_, i) => (
              <rect
                key={i}
                x={x + 8 + i * (pw + 8)}
                y={y + 8}
                width={pw}
                height={30}
                rx="6"
              />
            ))}
            <path d={`M${x} ${y + 62}H${x + w}`} />
          </>
        );
      }
      case 'sofa':
        return (
          <path
            d={`M${x} ${y + 26}H${x + w}M${x + 22} ${y + 26}V${y + h}M${x + w - 22} ${y + 26}V${y + h}`}
          />
        );
      case 'table':
        return <rect x={x + 10} y={y + 10} width={w - 20} height={h - 20} rx="4" />;
      case 'desk':
        return <rect x="-25" y={y + 8} width="50" height="14" rx="2" />;
      case 'wardrobe':
        return <path d={`M${x} ${y}L${x + w} ${y + h}M${x + w} ${y}L${x} ${y + h}`} />;
      case 'fridge':
        return <path d={`M${x} ${y + h * 0.35}H${x + w}`} />;
      case 'counter':
        return <path d={`M${x} ${y + 14}H${x + w}`} />;
      case 'bath':
        return (
          <rect
            x={x + 8}
            y={y + 8}
            width={w - 16}
            height={h - 16}
            rx={Math.min(h, 40) / 2}
          />
        );
      case 'shower':
        return (
          <>
            <path d={`M${x} ${y}L${x + w} ${y + h}`} />
            <circle r="6" />
          </>
        );
      case 'sink':
        return <circle r={Math.min(w, h) * 0.3} />;
      case 'wc':
        return (
          <>
            <path d={`M${x} ${y + 18}H${x + w}`} />
            <ellipse
              cy={y + 18 + (h - 18) / 2}
              rx={w / 2 - 6}
              ry={(h - 18) / 2 - 4}
            />
          </>
        );
      default:
        return null;
    }
  };

  return (
    <g
      stroke="var(--pe-muted)"
      strokeWidth={strokeWidth}
      fill="var(--pe-panel)"
      fillOpacity="0.65"
      strokeLinejoin="round"
    >
      <rect x={x} y={y} width={w} height={h} rx="6" />
      <g fill="none">{renderDetails()}</g>
    </g>
  );
}
