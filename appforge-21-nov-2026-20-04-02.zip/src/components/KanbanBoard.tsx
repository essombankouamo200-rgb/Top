import { useState } from 'react';
import { ChevronLeft, ChevronRight, CheckSquare, Plus } from 'lucide-react';
import { Task, TaskStatus, TeamMember } from '../types/project';
import { STATUS_CONFIG } from '../data/seedData';
import { formatShortDateFr, isOverdue } from '../utils/formatters';
import { Avatar } from './Avatar';
import { PriorityIndicator } from './PriorityIndicator';

interface KanbanBoardProps {
  tasks: Task[];
  members: TeamMember[];
  onSelectTask: (taskId: string) => void;
  onMoveTask: (taskId: string, nextStatus: TaskStatus) => void;
  onCreateTaskInStatus: (status: TaskStatus) => void;
}

const COLUMNS: TaskStatus[] = ['a_faire', 'en_cours', 'revue', 'termine'];

export function KanbanBoard({
  tasks,
  members,
  onSelectTask,
  onMoveTask,
  onCreateTaskInStatus,
}: KanbanBoardProps) {
  const [draggedTaskId, setDraggedTaskId] = useState<string | null>(null);
  const [dropTarget, setDropTarget] = useState<TaskStatus | null>(null);

  const memberById = new Map(members.map((m) => [m.id, m]));

  return (
    <div className="grid grid-cols-1 gap-5 md:grid-cols-2 xl:grid-cols-4">
      {COLUMNS.map((status, colIndex) => {
        const colTasks = tasks.filter((t) => t.statut === status);
        const totalHours = colTasks.reduce((sum, t) => sum + t.heuresEstimees, 0);
        const isOver = dropTarget === status;

        return (
          <section
            key={status}
            aria-label={STATUS_CONFIG[status].label}
            onDragOver={(e) => {
              e.preventDefault();
              if (dropTarget !== status) setDropTarget(status);
            }}
            onDragLeave={() => {
              if (dropTarget === status) setDropTarget(null);
            }}
            onDrop={(e) => {
              e.preventDefault();
              const id = e.dataTransfer.getData('text/plain') || draggedTaskId;
              if (id) onMoveTask(id, status);
              setDraggedTaskId(null);
              setDropTarget(null);
            }}
            className={`flex min-h-[420px] flex-col rounded-xl border p-3.5 transition-colors ${
              isOver
                ? 'border-indigo-500 bg-indigo-50/40 dark:border-indigo-400 dark:bg-indigo-950/20'
                : 'border-slate-200 bg-slate-100/70 dark:border-slate-800 dark:bg-slate-900/50'
            }`}
          >
            <div className="mb-3 flex items-center justify-between px-1">
              <div className="flex items-center gap-2 text-sm font-semibold text-slate-900 dark:text-slate-100">
                <span>{STATUS_CONFIG[status].label}</span>
                <span className="font-mono text-xs font-normal tabular-nums text-slate-500 dark:text-slate-400">
                  {colTasks.length}
                </span>
              </div>
              <div className="flex items-center gap-2">
                <span className="font-mono text-xs tabular-nums text-slate-500 dark:text-slate-400">
                  {totalHours}h
                </span>
                <button
                  type="button"
                  onClick={() => onCreateTaskInStatus(status)}
                  title={`Ajouter une tâche dans ${STATUS_CONFIG[status].label}`}
                  aria-label={`Ajouter une tâche dans ${STATUS_CONFIG[status].label}`}
                  className="rounded p-1 text-slate-500 hover:bg-slate-200 hover:text-slate-900 dark:text-slate-400 dark:hover:bg-slate-800 dark:hover:text-white"
                >
                  <Plus className="h-4 w-4" />
                </button>
              </div>
            </div>

            <div className="flex flex-1 flex-col gap-3">
              {colTasks.length === 0 ? (
                <div className="flex flex-1 flex-col items-center justify-center rounded-lg border border-dashed border-slate-300 p-6 text-center dark:border-slate-700">
                  <p className="text-xs text-slate-500 dark:text-slate-400">
                    Aucune tâche dans cette colonne.
                  </p>
                  <button
                    type="button"
                    onClick={() => onCreateTaskInStatus(status)}
                    className="mt-3 rounded-md px-3 py-1.5 text-xs font-medium text-slate-700 hover:bg-slate-200 whitespace-nowrap shrink-0 dark:text-slate-200 dark:hover:bg-slate-800"
                  >
                    Ajouter une tâche
                  </button>
                </div>
              ) : (
                colTasks.map((task) => {
                  const member = memberById.get(task.assigneeId);
                  const doneSubs = task.sousTaches.filter((s) => s.terminee).length;
                  const totalSubs = task.sousTaches.length;
                  const overdue = isOverdue(task.echeance, task.statut === 'termine');
                  const prevStatus = colIndex > 0 ? COLUMNS[colIndex - 1] : null;
                  const nextStatus = colIndex < COLUMNS.length - 1 ? COLUMNS[colIndex + 1] : null;

                  return (
                    <article
                      key={task.id}
                      draggable
                      onDragStart={(e) => {
                        setDraggedTaskId(task.id);
                        e.dataTransfer.setData('text/plain', task.id);
                      }}
                      onDragEnd={() => {
                        setDraggedTaskId(null);
                        setDropTarget(null);
                      }}
                      className={`group rounded-lg border border-slate-200 bg-white p-3.5 transition-colors hover:border-slate-300 dark:border-slate-800 dark:bg-slate-900 dark:hover:border-slate-700 ${
                        draggedTaskId === task.id ? 'opacity-50' : ''
                      }`}
                    >
                      <div className="flex items-center justify-between gap-2 text-xs text-slate-500 dark:text-slate-400">
                        <span className="truncate font-mono tabular-nums">
                          {task.code} · {task.categorie}
                        </span>
                        <PriorityIndicator priority={task.priorite} />
                      </div>

                      <button
                        type="button"
                        onClick={() => onSelectTask(task.id)}
                        className="mt-2 block w-full text-left text-sm font-medium leading-snug text-slate-900 hover:text-indigo-700 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-indigo-600 dark:text-slate-100 dark:hover:text-indigo-400"
                      >
                        {task.titre}
                      </button>

                      {totalSubs > 0 && (
                        <div className="mt-3 flex items-center gap-2 text-xs text-slate-500 dark:text-slate-400">
                          <CheckSquare className="h-3.5 w-3.5 shrink-0" aria-hidden="true" />
                          <span className="font-mono tabular-nums">
                            {doneSubs}/{totalSubs}
                          </span>
                          <div className="h-1.5 flex-1 overflow-hidden rounded-full bg-slate-100 dark:bg-slate-800">
                            <div
                              className="h-full bg-slate-700 transition-all dark:bg-slate-300"
                              style={{ width: `${Math.round((doneSubs / totalSubs) * 100)}%` }}
                            />
                          </div>
                        </div>
                      )}

                      <div className="mt-3.5 flex items-center justify-between gap-2 border-t border-slate-100 pt-2.5 dark:border-slate-800">
                        <div className="flex min-w-0 items-center gap-2">
                          {member && <Avatar member={member} size="sm" />}
                          <span
                            className={`font-mono text-xs tabular-nums ${
                              overdue
                                ? 'font-medium text-red-700 dark:text-red-400'
                                : 'text-slate-500 dark:text-slate-400'
                            }`}
                          >
                            {formatShortDateFr(task.echeance)} · {task.heuresEstimees}h
                          </span>
                        </div>

                        <div className="flex items-center gap-0.5 shrink-0">
                          <button
                            type="button"
                            disabled={!prevStatus}
                            onClick={() => prevStatus && onMoveTask(task.id, prevStatus)}
                            aria-label="Déplacer vers l’étape précédente"
                            title="Étape précédente"
                            className="rounded p-1 text-slate-400 hover:bg-slate-100 hover:text-slate-800 disabled:opacity-25 disabled:pointer-events-none dark:hover:bg-slate-800 dark:hover:text-slate-100"
                          >
                            <ChevronLeft className="h-3.5 w-3.5" />
                          </button>
                          <button
                            type="button"
                            disabled={!nextStatus}
                            onClick={() => nextStatus && onMoveTask(task.id, nextStatus)}
                            aria-label="Déplacer vers l’étape suivante"
                            title="Étape suivante"
                            className="rounded p-1 text-slate-400 hover:bg-slate-100 hover:text-slate-800 disabled:opacity-25 disabled:pointer-events-none dark:hover:bg-slate-800 dark:hover:text-slate-100"
                          >
                            <ChevronRight className="h-3.5 w-3.5" />
                          </button>
                        </div>
                      </div>
                    </article>
                  );
                })
              )}
            </div>
          </section>
        );
      })}
    </div>
  );
}
