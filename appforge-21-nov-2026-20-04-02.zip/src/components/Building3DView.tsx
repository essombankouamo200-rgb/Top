import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import * as THREE from 'three';
import { OrbitControls } from 'three/addons/controls/OrbitControls.js';
import { RoomEnvironment } from 'three/addons/environments/RoomEnvironment.js';
import {
  Anchor,
  ArrowDown,
  ArrowLeft,
  ArrowRight,
  ArrowUp,
  Cable,
  Camera,
  Check,
  ChevronDown,
  ChevronUp,
  DoorOpen,
  Eye,
  Footprints,
  Layers,
  Lightbulb,
  Lock,
  LogOut,
  Monitor,
  Moon,
  Move,
  Paintbrush,
  Plus,
  Power,
  RefreshCw,
  RotateCw,
  Sun,
  Trash2,
  Unlock,
  X,
  Zap,
} from 'lucide-react';
import {
  FloorFinishId,
  ItemType,
  PlanItem,
  PlanProjectData,
  Room,
  WallFinishId,
  WallSide,
} from '../types/planelec';
import {
  FINISH_STYLES,
  FLOOR_FINISHES,
  TYPES,
  WALL_FINISHES,
} from '../data/catalog';
import {
  clamp,
  fitItemInRoom,
  frNum,
  halfOf,
  SimulationOutput,
  wallPos,
  wattsOf,
} from '../utils/electricalEngine';
import {
  computeMagneticDragSnap,
  defaultWallElevationCm,
  generateRoomSnapAnchors,
  MagneticSnapResult,
  resolveItemElevationCm,
  SCALE_3D,
  SnapAnchor,
  SUPPORT_HOST_HEIGHT_CM,
  TABLETOP_COMPATIBLE_TYPES,
  WALL_BASE_YAW,
  WALL_HEIGHT_M,
  WALL_ROT_DEG,
  WALL_THICK_M,
} from '../utils/snap3d';

interface Building3DViewProps {
  project: PlanProjectData;
  sim: SimulationOutput;
  trippedCircuitIds: Set<string>;
  activeStairStep: number | null;
  stairWalkMode: 'up' | 'down' | null;
  onSetStairWalkMode: (mode: 'up' | 'down' | null) => void;
  onCommitProject: (next: PlanProjectData, recordHistory?: boolean) => void;
  onToggleCircuitTrip: (circuitId: string) => void;
}

const SCALE = SCALE_3D;
const POV_W = 320;
const POV_H = 200;

const QUICK_ADD_ITEMS: { type: ItemType; label: string; group: 'furn' | 'elec' }[] = [
  { type: 'sofa', label: 'Canapé', group: 'furn' },
  { type: 'bed2', label: 'Lit double', group: 'furn' },
  { type: 'bed1', label: 'Lit 1 place', group: 'furn' },
  { type: 'table', label: 'Table', group: 'furn' },
  { type: 'desk', label: 'Bureau', group: 'furn' },
  { type: 'counter', label: 'Plan de travail', group: 'furn' },
  { type: 'wardrobe', label: 'Armoire', group: 'furn' },
  { type: 'tv', label: 'TV', group: 'furn' },
  { type: 'pc', label: 'Poste PC', group: 'furn' },
  { type: 'fridge', label: 'Frigo', group: 'furn' },
  { type: 'shower', label: 'Douche', group: 'furn' },
  { type: 'sink', label: 'Lavabo', group: 'furn' },
  { type: 'wc', label: 'WC', group: 'furn' },
  { type: 'light', label: 'Plafonnier / Lampe', group: 'elec' },
  { type: 'spots', label: 'Spots', group: 'elec' },
  { type: 'sconce', label: 'Applique', group: 'elec' },
  { type: 'switch', label: 'Interrupteur', group: 'elec' },
  { type: 'pushbutton', label: 'Bouton poussoir', group: 'elec' },
  { type: 'socket', label: 'Prise 16 A', group: 'elec' },
  { type: 'socket2', label: 'Double prise', group: 'elec' },
  { type: 'usb_socket', label: 'Prise USB-C', group: 'elec' },
  { type: 'rj45', label: 'Prise RJ45', group: 'elec' },
  { type: 'heater', label: 'Radiateur', group: 'elec' },
  { type: 'ac_split', label: 'Clim Split', group: 'elec' },
  { type: 'ac_outdoor', label: 'Groupe Clim Ext.', group: 'elec' },
  { type: 'thermostat', label: 'Thermostat', group: 'elec' },
  { type: 'camera', label: 'Caméra IP', group: 'elec' },
  { type: 'nvr_screen', label: 'Écran NVR', group: 'elec' },
];

// Fast linear -> sRGB gamma lookup table for offscreen WebGLRenderTarget pixel copies
const SRGB_LUT = new Uint8Array(256);
for (let i = 0; i < 256; i++) {
  SRGB_LUT[i] = Math.min(255, Math.round(Math.pow(i / 255, 1 / 2.2) * 255));
}

function detectSoftwareGl(): boolean {
  try {
    const gl = document.createElement('canvas').getContext('webgl2');
    if (!gl) return true;
    const ext = gl.getExtension('WEBGL_debug_renderer_info');
    const param = ext ? ext.UNMASKED_RENDERER_WEBGL : gl.RENDERER;
    const gpu = String(gl.getParameter(param));
    gl.getExtension('WEBGL_lose_context')?.loseContext();
    return /SwiftShader|llvmpipe|softpipe|Software|Basic Render/i.test(gpu);
  } catch {
    return true;
  }
}

function createWallFinishTexture(
  finishId: WallFinishId,
  nightMode: boolean,
  maxAniso: number
): THREE.CanvasTexture {
  const def = WALL_FINISHES.find((w) => w.id === finishId) ?? WALL_FINISHES[0];
  const canvas = document.createElement('canvas');
  canvas.width = 256;
  canvas.height = 256;
  const ctx = canvas.getContext('2d')!;

  ctx.fillStyle = def.hex;
  ctx.fillRect(0, 0, 256, 256);

  if (finishId === 'carrelage_blanc' || finishId === 'carrelage_ardoise') {
    const tileW = 64;
    const tileH = 32;
    for (let row = 0; row < 256 / tileH; row++) {
      const offset = (row % 2) * (tileW / 2);
      for (let col = -1; col <= 256 / tileW; col++) {
        const shade = ((row + col) % 2 === 0 ? 0.03 : 0) * 255;
        ctx.fillStyle = def.hex;
        ctx.fillRect(col * tileW + offset + 2, row * tileH + 2, tileW - 3, tileH - 3);
        if (shade > 0) {
          ctx.fillStyle = 'rgba(255,255,255,0.06)';
          ctx.fillRect(col * tileW + offset + 2, row * tileH + 2, tileW - 3, tileH - 3);
        }
      }
    }
    ctx.strokeStyle = def.groutHex ?? '#cbd5e1';
    ctx.lineWidth = 2;
    for (let row = 0; row <= 256 / tileH; row++) {
      const y = row * tileH;
      ctx.beginPath();
      ctx.moveTo(0, y);
      ctx.lineTo(256, y);
      ctx.stroke();
      const offset = (row % 2) * (tileW / 2);
      for (let col = 0; col <= 256 / tileW; col++) {
        const x = (col * tileW + offset) % 256;
        ctx.beginPath();
        ctx.moveTo(x, y);
        ctx.lineTo(x, y + tileH);
        ctx.stroke();
      }
    }
  } else if (finishId === 'carrelage_marbre') {
    ctx.strokeStyle = 'rgba(148, 163, 184, 0.32)';
    ctx.lineWidth = 2;
    for (let i = 0; i < 6; i++) {
      ctx.beginPath();
      ctx.moveTo(0, i * 44 + 10);
      ctx.bezierCurveTo(85, i * 44 - 12, 170, i * 44 + 34, 256, i * 44 + 8);
      ctx.stroke();
    }
    ctx.strokeStyle = def.groutHex ?? '#94a3b8';
    ctx.lineWidth = 2;
    for (let i = 0; i <= 256; i += 128) {
      ctx.beginPath();
      ctx.moveTo(i, 0);
      ctx.lineTo(i, 256);
      ctx.stroke();
      ctx.beginPath();
      ctx.moveTo(0, i);
      ctx.lineTo(256, i);
      ctx.stroke();
    }
  } else if (finishId === 'brique') {
    const bh = 32;
    const bw = 64;
    ctx.fillStyle = def.groutHex ?? '#d6cfc7';
    ctx.fillRect(0, 0, 256, 256);
    for (let r = 0; r < 256 / bh; r++) {
      const off = (r % 2) * (bw / 2);
      for (let c = -1; c <= 256 / bw; c++) {
        ctx.fillStyle = (r + c) % 3 === 0 ? '#a95e47' : (r + c) % 2 === 0 ? '#bd7158' : '#b4674f';
        ctx.fillRect(c * bw + off + 3, r * bh + 3, bw - 6, bh - 6);
      }
    }
  } else {
    ctx.fillStyle = nightMode ? 'rgba(15, 23, 42, 0.25)' : 'rgba(255, 255, 255, 0.08)';
    for (let y = 0; y < 256; y += 16) {
      for (let x = 0; x < 256; x += 16) {
        if ((x + y) % 32 === 0) ctx.fillRect(x, y, 8, 8);
      }
    }
  }

  const tex = new THREE.CanvasTexture(canvas);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.wrapS = THREE.RepeatWrapping;
  tex.wrapT = THREE.RepeatWrapping;
  tex.repeat.set(2, 1.5);
  tex.anisotropy = Math.min(4, maxAniso);
  return tex;
}

function createFloorFinishTexture(
  finishId: Exclude<FloorFinishId, 'auto'>,
  maxAniso: number
): THREE.CanvasTexture {
  const canvas = document.createElement('canvas');
  canvas.width = 256;
  canvas.height = 256;
  const ctx = canvas.getContext('2d')!;

  if (finishId === 'parquet_chene' || finishId === 'parquet_noyer') {
    const dark = finishId === 'parquet_noyer';
    ctx.fillStyle = dark ? '#7c583a' : '#d9c3a3';
    ctx.fillRect(0, 0, 256, 256);
    const plankH = 32;
    for (let y = 0; y < 256; y += plankH) {
      ctx.fillStyle =
        (y / plankH) % 2 === 0
          ? dark
            ? '#745134'
            : '#d6be9b'
          : dark
          ? '#876142'
          : '#dfcab0';
      ctx.fillRect(0, y, 256, plankH - 1);
      ctx.fillStyle = dark ? '#5a3d26' : '#bfa37e';
      ctx.fillRect(0, y + plankH - 1, 256, 1);
      const offset = ((y / plankH) % 2) * 128;
      ctx.fillRect((offset + 120) % 256, y, 1, plankH);
    }
  } else if (finishId === 'beton_cire') {
    ctx.fillStyle = '#94a3b8';
    ctx.fillRect(0, 0, 256, 256);
    ctx.fillStyle = 'rgba(255,255,255,0.08)';
    for (let i = 0; i < 40; i++) {
      ctx.fillRect((i * 37) % 240, (i * 53) % 240, 24, 16);
    }
  } else {
    const isTrav = finishId === 'carrelage_travertin';
    ctx.fillStyle = isTrav ? '#e6dcc8' : '#e2e8f0';
    ctx.fillRect(0, 0, 256, 256);
    ctx.strokeStyle = isTrav ? '#cbbfa8' : '#cbd5e1';
    ctx.lineWidth = 2;
    for (let i = 0; i <= 256; i += 64) {
      ctx.beginPath();
      ctx.moveTo(i, 0);
      ctx.lineTo(i, 256);
      ctx.stroke();
      ctx.beginPath();
      ctx.moveTo(0, i);
      ctx.lineTo(256, i);
      ctx.stroke();
    }
  }

  const tex = new THREE.CanvasTexture(canvas);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.wrapS = THREE.RepeatWrapping;
  tex.wrapT = THREE.RepeatWrapping;
  tex.repeat.set(3, 3);
  tex.anisotropy = Math.min(4, maxAniso);
  return tex;
}

function createCameraFovGeometry(fovDeg: number, rangeM: number): THREE.BufferGeometry {
  const halfH = ((clamp(fovDeg, 30, 150) / 2) * Math.PI) / 180;
  const topY = 0.05;
  const botY = -1.65;
  const x = Math.sin(halfH) * rangeM;
  const z = Math.cos(halfH) * rangeM;

  const vertices = new Float32Array([
    0, 0, 0,
    -x, topY, z,
    x, topY, z,
    x, botY, z,
    -x, botY, z,
  ]);
  const indices = [
    0, 1, 2,
    0, 2, 3,
    0, 3, 4,
    0, 4, 1,
    1, 4, 3,
    1, 3, 2,
  ];
  const geo = new THREE.BufferGeometry();
  geo.setAttribute('position', new THREE.BufferAttribute(vertices, 3));
  geo.setIndex(indices);
  geo.computeVertexNormals();
  return geo;
}

interface CameraRigRecord {
  item: PlanItem;
  worldPos: THREE.Vector3;
  yaw: number;
  group: THREE.Group;
  isTripped: boolean;
}

export function Building3DView({
  project,
  sim,
  trippedCircuitIds,
  activeStairStep,
  stairWalkMode,
  onSetStairWalkMode,
  onCommitProject,
  onToggleCircuitTrip,
}: Building3DViewProps) {
  const mountRef = useRef<HTMLDivElement>(null);
  const [nightMode, setNightMode] = useState(false);
  const [lightsOn, setLightsOn] = useState(true);
  const [disabledRoomLights, setDisabledRoomLights] = useState<Set<number>>(() => new Set());
  const [showCables3D, setShowCables3D] = useState(true);
  const [showCameraFov3D, setShowCameraFov3D] = useState(true);
  const [xrayWalls, setXrayWalls] = useState(false);
  const [floorViewMode, setFloorViewMode] = useState<'all' | 'active' | 'exploded'>('all');
  const [dockCollapsed, setDockCollapsed] = useState(false);
  const [inspectedLabel, setInspectedLabel] = useState<string | null>(null);

  // Room & Studio state
  const [selectedRoomId, setSelectedRoomId] = useState<number | null>(null);
  const [enteredRoomId, setEnteredRoomId] = useState<number | null>(null);
  const [roomStudioOpen, setRoomStudioOpen] = useState(false);
  const [studioTab, setStudioTab] = useState<'habillage' | 'circuits' | 'furn' | 'elec'>('habillage');

  // 3D Selection, Direct Drag & Snap Accrocheurs state
  const [selectedItemId, setSelectedItemId] = useState<number | null>(null);
  const [anchorsVisible, setAnchorsVisible] = useState(false);
  const [moveMode, setMoveMode] = useState(false);
  const [snapHint, setSnapHint] = useState<string | null>(null);

  const [selectedCameraId, setSelectedCameraId] = useState<number | null>(null);

  // Live NVR Camera Monitor feed state
  const [monitorOpen, setMonitorOpen] = useState(false);
  const [monitorCamId, setMonitorCamId] = useState<number | 'all'>('all');
  const [monitorTick, setMonitorTick] = useState(0);
  const monitorCanvasRefs = useRef<Map<number, HTMLCanvasElement>>(new Map());

  const floorSpacing = floorViewMode === 'exploded' ? 3.8 : 2.75;
  const sortedFloors = useMemo(
    () => [...project.floors].sort((a, b) => a.elevationIndex - b.elevationIndex),
    [project.floors]
  );
  const minElev = sortedFloors[0]?.elevationIndex ?? 0;

  const floorYOf = useCallback(
    (floorId: number) => {
      if (floorViewMode === 'active') return 0;
      const elev = project.floors.find((f) => f.id === floorId)?.elevationIndex ?? 0;
      return (elev - minElev) * floorSpacing;
    },
    [floorViewMode, project.floors, minElev, floorSpacing]
  );

  // Synced refs for WebGL pointer handlers
  const projectRef = useRef(project);
  const onCommitProjectRef = useRef(onCommitProject);
  const onSetStairWalkModeRef = useRef(onSetStairWalkMode);
  const stairWalkModeRef = useRef(stairWalkMode);
  const selectedItemIdRef = useRef(selectedItemId);
  const anchorsVisibleRef = useRef(anchorsVisible);
  const moveModeRef = useRef(moveMode);
  const floorYOfRef = useRef(floorYOf);

  useEffect(() => {
    projectRef.current = project;
    onCommitProjectRef.current = onCommitProject;
    onSetStairWalkModeRef.current = onSetStairWalkMode;
    stairWalkModeRef.current = stairWalkMode;
    selectedItemIdRef.current = selectedItemId;
    anchorsVisibleRef.current = anchorsVisible;
    moveModeRef.current = moveMode;
    floorYOfRef.current = floorYOf;
  }, [
    project,
    onCommitProject,
    onSetStairWalkMode,
    stairWalkMode,
    selectedItemId,
    anchorsVisible,
    moveMode,
    floorYOf,
  ]);

  const applyAnchorToSelectedRef = useRef<(anchor: SnapAnchor) => void>(() => {});

  const sceneRefs = useRef<{
    scene: THREE.Scene;
    camera: THREE.PerspectiveCamera;
    controls: OrbitControls;
    renderer: THREE.WebGLRenderer;
    worldGroup: THREE.Group;
    anchorsGroup: THREE.Group;
    selectionRing: THREE.Mesh;
    keyLight: THREE.DirectionalLight;
    hemiLight: THREE.HemisphereLight;
    texCache: Map<string, THREE.CanvasTexture>;
    maxAniso: number;
    povTarget: THREE.WebGLRenderTarget;
    povCam: THREE.PerspectiveCamera;
    povPixels: Uint8Array;
    cameraRigs: CameraRigRecord[];
    nvrScreenTex: THREE.CanvasTexture;
    nvrScreenCanvas: HTMLCanvasElement;
    requestRender: () => void;
    cameraTargetGoal: THREE.Vector3 | null;
    cameraPosGoal: THREE.Vector3 | null;
    roomClickables: THREE.Object3D[];
    itemClickables: THREE.Object3D[];
    anchorClickables: THREE.Object3D[];
    itemObjectsMap: Map<number, THREE.Object3D>;
    isSoftwareGl: boolean;
  } | null>(null);

  const nudgeCamera = useCallback((forward: number, strafe: number, vertical = 0) => {
    const refs = sceneRefs.current;
    if (!refs) return;
    refs.cameraPosGoal = null;
    refs.cameraTargetGoal = null;

    const dir = new THREE.Vector3();
    refs.camera.getWorldDirection(dir);
    dir.y = 0;
    if (dir.lengthSq() < 0.0001) dir.set(0, 0, -1);
    dir.normalize();

    const right = new THREE.Vector3().crossVectors(dir, new THREE.Vector3(0, 1, 0)).normalize();
    const delta = new THREE.Vector3()
      .addScaledVector(dir, forward)
      .addScaledVector(right, strafe);
    delta.y += vertical;

    refs.camera.position.add(delta);
    refs.controls.target.add(delta);
    refs.controls.update();
    refs.requestRender();
  }, []);

  const enterRoomIn3D = useCallback(
    (room: Room) => {
      const refs = sceneRefs.current;
      if (!refs) return;

      if (floorViewMode === 'active' && room.floorId !== project.activeFloorId) {
        onCommitProject({ ...project, activeFloorId: room.floorId }, false);
      }

      const fy = floorViewMode === 'active' ? 0 : floorYOf(room.floorId);
      const rx = room.x * SCALE;
      const rz = room.y * SCALE;
      const rw = room.w * SCALE;
      const rd = room.h * SCALE;

      const cx = rx + rw / 2;
      const cz = rz + rd / 2;
      const camX = rx + Math.min(0.65, rw * 0.2);
      const camZ = rz + Math.min(0.65, rd * 0.2);

      refs.controls.minDistance = 0.45;
      refs.cameraTargetGoal = new THREE.Vector3(cx, fy + 1.05, cz);
      refs.cameraPosGoal = new THREE.Vector3(camX, fy + 1.85, camZ);
      refs.requestRender();

      setSelectedRoomId(room.id);
      setEnteredRoomId(room.id);
      setRoomStudioOpen(false);
      setSelectedCameraId(null);
      setInspectedLabel(`${room.name} · Cliquez sur un meuble/équipement pour le déplacer ou l’accrocher`);
    },
    [floorViewMode, floorYOf, onCommitProject, project]
  );

  const setCameraPreset = useCallback(
    (preset: 'iso' | 'top') => {
      const refs = sceneRefs.current;
      if (!refs) return;

      setEnteredRoomId(null);
      refs.controls.minDistance = 2.5;

      const xs = project.rooms.flatMap((r) => [r.x * SCALE, (r.x + r.w) * SCALE]);
      const zs = project.rooms.flatMap((r) => [r.y * SCALE, (r.y + r.h) * SCALE]);
      const cx = xs.length ? (Math.min(...xs) + Math.max(...xs)) / 2 : 3;
      const cz = zs.length ? (Math.min(...zs) + Math.max(...zs)) / 2 : 3;
      const span = xs.length
        ? Math.max(Math.max(...xs) - Math.min(...xs), Math.max(...zs) - Math.min(...zs))
        : 8;
      const floorsH =
        floorViewMode === 'active' ? 1 : Math.max(1, project.floors.length) * 1.4;

      refs.cameraTargetGoal = new THREE.Vector3(cx, floorsH * 0.7, cz);
      refs.cameraPosGoal =
        preset === 'top'
          ? new THREE.Vector3(cx, span * 1.45 + floorsH * 2.5, cz + 0.01)
          : new THREE.Vector3(cx + span * 0.85, span * 0.72 + floorsH * 2.2, cz + span * 0.92);
      refs.requestRender();
    },
    [project.rooms, project.floors.length, floorViewMode]
  );

  // Snap selected item onto a clicked 3D Accrocheur
  const applyAnchorToSelected = useCallback((anchor: SnapAnchor) => {
    const curProj = projectRef.current;
    const itemId = selectedItemIdRef.current;
    if (itemId === null) return;
    const item = curProj.items.find((i) => i.id === itemId);
    if (!item) return;

    const dx = anchor.x - item.x;
    const dy = anchor.y - item.y;
    const isHost = SUPPORT_HOST_HEIGHT_CM[item.type] !== undefined;

    const nextItems = curProj.items.map((it) => {
      if (it.id === item.id) {
        return {
          ...it,
          roomId: anchor.roomId,
          floorId: anchor.floorId,
          x: anchor.x,
          y: anchor.y,
          side: anchor.side,
          rot: anchor.rot,
          elevationCm: anchor.elevationCm,
          mountSurface: anchor.mountSurface,
          mountHostId: anchor.mountHostId,
        };
      }
      if (isHost && it.mountHostId === item.id) {
        return {
          ...it,
          roomId: anchor.roomId,
          floorId: anchor.floorId,
          x: it.x + dx,
          y: it.y + dy,
        };
      }
      return it;
    });

    onCommitProjectRef.current({ ...curProj, items: nextItems }, true);
    setInspectedLabel(`${TYPES[item.type].label} · ${anchor.label}`);
    setSnapHint(null);
  }, []);

  useEffect(() => {
    applyAnchorToSelectedRef.current = applyAnchorToSelected;
  }, [applyAnchorToSelected]);

  // Render real-time POV feeds from every installed 3D surveillance camera
  const renderCameraFeeds = useCallback(() => {
    const refs = sceneRefs.current;
    if (!refs || refs.cameraRigs.length === 0) return;

    const {
      renderer,
      scene,
      povTarget,
      povCam,
      povPixels,
      cameraRigs,
      nvrScreenCanvas,
      nvrScreenTex,
      anchorsGroup,
      selectionRing,
    } = refs;
    const prevTarget = renderer.getRenderTarget();
    const prevAnchorsVis = anchorsGroup.visible;
    const prevRingVis = selectionRing.visible;
    anchorsGroup.visible = false;
    selectionRing.visible = false;

    let updatedPhysicalScreen = false;

    for (const rig of cameraRigs) {
      const canvasEl = monitorCanvasRefs.current.get(rig.item.id);
      const needsPhysical = !updatedPhysicalScreen;
      if (!canvasEl && !needsPhysical) continue;

      if (rig.isTripped) {
        const drawLost = (ctx: CanvasRenderingContext2D, w: number, h: number) => {
          ctx.fillStyle = '#0f172a';
          ctx.fillRect(0, 0, w, h);
          ctx.fillStyle = '#ef4444';
          ctx.font = 'bold 14px monospace';
          ctx.textAlign = 'center';
          ctx.fillText('SIGNAL PERDU (COUPÉ)', w / 2, h / 2);
        };
        if (canvasEl) {
          const ctx = canvasEl.getContext('2d');
          if (ctx) drawLost(ctx, POV_W, POV_H);
        }
        if (needsPhysical) {
          const ctx = nvrScreenCanvas.getContext('2d');
          if (ctx) drawLost(ctx, POV_W, POV_H);
          nvrScreenTex.needsUpdate = true;
          updatedPhysicalScreen = true;
        }
        continue;
      }

      const sinY = Math.sin(rig.yaw);
      const cosY = Math.cos(rig.yaw);
      const fov = clamp((rig.item.camFov ?? 90) * 0.74, 38, 105);

      povCam.fov = fov;
      povCam.aspect = POV_W / POV_H;
      povCam.far = clamp((rig.item.camRange ?? 450) * SCALE * 2.5, 8, 45);
      povCam.updateProjectionMatrix();

      povCam.position.set(
        rig.worldPos.x + sinY * 0.26,
        rig.worldPos.y - 0.02,
        rig.worldPos.z + cosY * 0.26
      );
      povCam.lookAt(
        rig.worldPos.x + sinY * 3.5,
        Math.max(0.25, rig.worldPos.y - 0.95),
        rig.worldPos.z + cosY * 3.5
      );

      rig.group.visible = false;
      renderer.setRenderTarget(povTarget);
      renderer.clear();
      renderer.render(scene, povCam);
      renderer.readRenderTargetPixels(povTarget, 0, 0, POV_W, POV_H, povPixels);
      rig.group.visible = true;

      const paintToCanvas = (targetCanvas: HTMLCanvasElement) => {
        const ctx = targetCanvas.getContext('2d');
        if (!ctx) return;
        const img = ctx.createImageData(POV_W, POV_H);
        const dst = img.data;
        for (let y = 0; y < POV_H; y++) {
          const srcRow = (POV_H - 1 - y) * POV_W * 4;
          const dstRow = y * POV_W * 4;
          for (let x = 0; x < POV_W * 4; x += 4) {
            dst[dstRow + x] = SRGB_LUT[povPixels[srcRow + x]];
            dst[dstRow + x + 1] = SRGB_LUT[povPixels[srcRow + x + 1]];
            dst[dstRow + x + 2] = SRGB_LUT[povPixels[srcRow + x + 2]];
            dst[dstRow + x + 3] = 255;
          }
        }
        ctx.putImageData(img, 0, 0);
      };

      if (canvasEl) paintToCanvas(canvasEl);
      if (needsPhysical) {
        paintToCanvas(nvrScreenCanvas);
        nvrScreenTex.needsUpdate = true;
        updatedPhysicalScreen = true;
      }
    }

    anchorsGroup.visible = prevAnchorsVis;
    selectionRing.visible = prevRingVis;
    renderer.setRenderTarget(prevTarget);
    refs.requestRender();
  }, []);

  useEffect(() => {
    const id = window.setTimeout(() => {
      renderCameraFeeds();
    }, 60);
    return () => window.clearTimeout(id);
  }, [
    monitorOpen,
    monitorCamId,
    monitorTick,
    project,
    nightMode,
    lightsOn,
    disabledRoomLights,
    trippedCircuitIds,
    activeStairStep,
    renderCameraFeeds,
  ]);

  // Keyboard WASD / Arrow movement inside 3D viewport
  useEffect(() => {
    const onKeyDown = (e: KeyboardEvent) => {
      const tag = (e.target as HTMLElement | null)?.tagName;
      if (tag === 'INPUT' || tag === 'SELECT' || tag === 'TEXTAREA') return;
      if (e.key === 'Escape') {
        setSelectedItemId(null);
        setAnchorsVisible(false);
        setMoveMode(false);
        setSnapHint(null);
        return;
      }
      const step = enteredRoomId !== null ? 0.35 : 0.7;
      switch (e.key.toLowerCase()) {
        case 'w':
        case 'z':
        case 'arrowup':
          e.preventDefault();
          nudgeCamera(step, 0);
          break;
        case 's':
        case 'arrowdown':
          e.preventDefault();
          nudgeCamera(-step, 0);
          break;
        case 'a':
        case 'q':
        case 'arrowleft':
          e.preventDefault();
          nudgeCamera(0, -step);
          break;
        case 'd':
        case 'arrowright':
          e.preventDefault();
          nudgeCamera(0, step);
          break;
      }
    };
    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, [enteredRoomId, nudgeCamera]);

  // Initialize Three.js once
  useEffect(() => {
    const container = mountRef.current;
    if (!container) return;

    const isSoftwareGl = detectSoftwareGl();
    const renderer = new THREE.WebGLRenderer({
      antialias: !isSoftwareGl,
      powerPreference: 'high-performance',
    });
    renderer.outputColorSpace = THREE.SRGBColorSpace;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.08;
    renderer.setPixelRatio(isSoftwareGl ? 1 : Math.min(window.devicePixelRatio, 2));
    renderer.shadowMap.enabled = !isSoftwareGl;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;

    const maxAniso = renderer.capabilities.getMaxAnisotropy();
    const texCache = new Map<string, THREE.CanvasTexture>();

    const povTarget = new THREE.WebGLRenderTarget(POV_W, POV_H, {
      type: THREE.UnsignedByteType,
      depthBuffer: true,
    });
    const povCam = new THREE.PerspectiveCamera(65, POV_W / POV_H, 0.08, 40);
    const povPixels = new Uint8Array(POV_W * POV_H * 4);

    const nvrScreenCanvas = document.createElement('canvas');
    nvrScreenCanvas.width = POV_W;
    nvrScreenCanvas.height = POV_H;
    const nctx = nvrScreenCanvas.getContext('2d')!;
    nctx.fillStyle = '#0f172a';
    nctx.fillRect(0, 0, POV_W, POV_H);
    nctx.fillStyle = '#38bdf8';
    nctx.font = 'bold 16px sans-serif';
    nctx.textAlign = 'center';
    nctx.fillText('NVR CAMÉRAS LIVE', POV_W / 2, POV_H / 2);
    const nvrScreenTex = new THREE.CanvasTexture(nvrScreenCanvas);
    nvrScreenTex.colorSpace = THREE.SRGBColorSpace;

    const width = container.clientWidth || 900;
    const height = container.clientHeight || 560;
    renderer.setSize(width, height);
    container.appendChild(renderer.domElement);

    const scene = new THREE.Scene();
    scene.background = new THREE.Color('#eef2f6');
    scene.fog = new THREE.Fog('#eef2f6', 24, 72);

    const pmrem = new THREE.PMREMGenerator(renderer);
    const envTex = pmrem.fromScene(new RoomEnvironment(), 0.04).texture;
    scene.environment = envTex;
    pmrem.dispose();

    const camera = new THREE.PerspectiveCamera(45, width / height, 0.08, 130);
    camera.position.set(12, 11.5, 14);

    const controls = new OrbitControls(camera, renderer.domElement);
    controls.enableDamping = !isSoftwareGl;
    controls.dampingFactor = 0.06;
    controls.maxPolarAngle = Math.PI / 2 - 0.02;
    controls.minDistance = 2.5;
    controls.maxDistance = 46;
    controls.target.set(3.5, 1.5, 3);
    controls.update();

    const hemiLight = new THREE.HemisphereLight(0xdbeafe, 0x94a3b8, 0.85);
    scene.add(hemiLight);

    const keyLight = new THREE.DirectionalLight(0xfffbeb, 1.55);
    keyLight.position.set(14, 20, 11);
    keyLight.castShadow = !isSoftwareGl;
    keyLight.shadow.mapSize.set(1024, 1024);
    keyLight.shadow.camera.left = -16;
    keyLight.shadow.camera.right = 16;
    keyLight.shadow.camera.top = 16;
    keyLight.shadow.camera.bottom = -16;
    keyLight.shadow.bias = -0.0005;
    keyLight.shadow.normalBias = 0.02;
    scene.add(keyLight);

    const groundGeo = new THREE.PlaneGeometry(90, 90);
    const groundMat = new THREE.MeshStandardMaterial({
      color: 0xe2e8f0,
      roughness: 0.92,
      metalness: 0.02,
    });
    const ground = new THREE.Mesh(groundGeo, groundMat);
    ground.rotation.x = -Math.PI / 2;
    ground.position.y = -0.02;
    ground.receiveShadow = true;
    scene.add(ground);

    const worldGroup = new THREE.Group();
    scene.add(worldGroup);

    const anchorsGroup = new THREE.Group();
    scene.add(anchorsGroup);

    const ringGeo = new THREE.RingGeometry(0.28, 0.36, 32);
    ringGeo.rotateX(-Math.PI / 2);
    const ringMat = new THREE.MeshBasicMaterial({
      color: 0x0ea5e9,
      side: THREE.DoubleSide,
      transparent: true,
      opacity: 0.85,
      depthTest: false,
    });
    const selectionRing = new THREE.Mesh(ringGeo, ringMat);
    selectionRing.visible = false;
    selectionRing.renderOrder = 10;
    scene.add(selectionRing);

    let frameId = 0;
    let renderBusy = false;
    let renderDirty = false;
    let disposed = false;

    const afterDraw = (cb: () => void) => {
      try {
        const gl = renderer.getContext() as WebGL2RenderingContext;
        const sync = gl.fenceSync(gl.SYNC_GPU_COMMANDS_COMPLETE, 0);
        gl.flush();
        const poll = () => {
          if (disposed) return;
          const state = sync && gl.getSyncParameter(sync, gl.SYNC_STATUS);
          if (state === gl.UNSIGNALED) {
            frameId = window.setTimeout(poll, 5);
          } else {
            if (sync) gl.deleteSync(sync);
            frameId = window.setTimeout(cb, 80);
          }
        };
        frameId = window.setTimeout(poll, 5);
      } catch {
        frameId = window.setTimeout(cb, 80);
      }
    };

    const clock = new THREE.Clock();

    const requestRender = () => {
      if (disposed) return;
      if (renderBusy) {
        renderDirty = true;
        return;
      }
      renderBusy = true;
      frameId = requestAnimationFrame(() => {
        if (disposed) return;
        renderDirty = false;
        const delta = Math.min(clock.getDelta(), 0.1);
        const refs = sceneRefs.current;
        let moving = false;

        if (refs && refs.cameraPosGoal && refs.cameraTargetGoal) {
          const factor = 1 - Math.exp(-6 * delta);
          camera.position.lerp(refs.cameraPosGoal, factor);
          controls.target.lerp(refs.cameraTargetGoal, factor);
          if (
            camera.position.distanceTo(refs.cameraPosGoal) < 0.04 &&
            controls.target.distanceTo(refs.cameraTargetGoal) < 0.04
          ) {
            camera.position.copy(refs.cameraPosGoal);
            controls.target.copy(refs.cameraTargetGoal);
            refs.cameraPosGoal = null;
            refs.cameraTargetGoal = null;
          } else {
            moving = true;
          }
        }

        const ctrlChanged = controls.update();
        renderer.render(scene, camera);

        const done = () => {
          renderBusy = false;
          if (renderDirty || moving || ctrlChanged) {
            requestRender();
          }
        };
        if (isSoftwareGl) afterDraw(done);
        else done();
      });
    };

    controls.addEventListener('change', requestRender);
    controls.addEventListener('start', () => {
      if (sceneRefs.current) {
        sceneRefs.current.cameraPosGoal = null;
        sceneRefs.current.cameraTargetGoal = null;
      }
    });

    const raycaster = new THREE.Raycaster();
    const pointer = new THREE.Vector2();
    let pointerDownPos = { x: 0, y: 0 };
    let pendingAnchor: SnapAnchor | null = null;
    let activeDrag: {
      item: PlanItem;
      room: Room;
      fy: number;
      roomItems: PlanItem[];
      childItems: PlanItem[];
      baseElevCm: number;
      moved: boolean;
      lastSnap: MagneticSnapResult | null;
      lastHint: string;
      clickedObj: THREE.Object3D;
    } | null = null;

    const updatePointerNdc = (e: PointerEvent) => {
      const rect = renderer.domElement.getBoundingClientRect();
      pointer.x = ((e.clientX - rect.left) / rect.width) * 2 - 1;
      pointer.y = -((e.clientY - rect.top) / rect.height) * 2 + 1;
    };

    const onPointerDown = (e: PointerEvent) => {
      if (e.button !== 0) return;
      const refs = sceneRefs.current;
      if (!refs) return;

      pointerDownPos = { x: e.clientX, y: e.clientY };
      updatePointerNdc(e);
      raycaster.setFromCamera(pointer, camera);

      // 1. Prioritize 3D Accrocheur anchors when visible
      if (anchorsVisibleRef.current && refs.anchorClickables.length > 0) {
        const anchorHits = raycaster.intersectObjects(refs.anchorClickables, true);
        if (anchorHits.length > 0) {
          let obj: THREE.Object3D | null = anchorHits[0].object;
          while (obj && !obj.userData?.anchorData) obj = obj.parent;
          if (obj?.userData?.anchorData) {
            pendingAnchor = obj.userData.anchorData as SnapAnchor;
            controls.enabled = false;
            return;
          }
        }
      }

      // 2. Check items for direct 3D drag or selection
      const itemHits = raycaster.intersectObjects(refs.itemClickables, true);
      if (itemHits.length > 0) {
        let obj: THREE.Object3D | null = itemHits[0].object;
        while (obj && obj.userData?.itemId === undefined) obj = obj.parent;
        if (typeof obj?.userData?.itemId === 'number') {
          const itemId = obj.userData.itemId as number;
          const curProj = projectRef.current;
          const item = curProj.items.find((i) => i.id === itemId);
          const room = item ? curProj.rooms.find((r) => r.id === item.roomId) : undefined;
          if (item && room) {
            const canInstantDrag =
              !item.locked &&
              (item.id === selectedItemIdRef.current ||
                moveModeRef.current ||
                Boolean(TYPES[item.type].furn));

            if (canInstantDrag) {
              controls.enabled = false;
            }
            const isHost = SUPPORT_HOST_HEIGHT_CM[item.type] !== undefined;
            activeDrag = {
              item,
              room,
              fy: floorYOfRef.current(item.floorId),
              roomItems: curProj.items.filter((i) => i.roomId === room.id),
              childItems: isHost
                ? curProj.items.filter((i) => i.mountHostId === item.id)
                : [],
              baseElevCm: resolveItemElevationCm(item, curProj.items),
              moved: false,
              lastSnap: null,
              lastHint: '',
              clickedObj: obj,
            };
            return;
          }
        }
      }
    };

    const onPointerMove = (e: PointerEvent) => {
      const refs = sceneRefs.current;
      if (!refs || !activeDrag) return;
      const dist = Math.hypot(e.clientX - pointerDownPos.x, e.clientY - pointerDownPos.y);
      if (!activeDrag.moved && dist < 5) return;

      if (activeDrag.item.locked) return;
      const canDrag =
        activeDrag.item.id === selectedItemIdRef.current ||
        moveModeRef.current ||
        Boolean(TYPES[activeDrag.item.type].furn);
      if (!canDrag) return;

      activeDrag.moved = true;
      controls.enabled = false;
      updatePointerNdc(e);
      raycaster.setFromCamera(pointer, camera);

      const snapRes = computeMagneticDragSnap(
        raycaster.ray,
        activeDrag.item,
        activeDrag.room,
        activeDrag.fy,
        activeDrag.roomItems,
        activeDrag.baseElevCm
      );
      if (!snapRes) return;

      activeDrag.lastSnap = snapRes;
      const obj3d = refs.itemObjectsMap.get(activeDrag.item.id);
      if (obj3d) {
        const fy = activeDrag.fy;
        const worldY =
          snapRes.mountSurface === 'wall'
            ? fy +
              (activeDrag.item.type === 'door'
                ? 1.02
                : activeDrag.item.type === 'window'
                ? 1.45
                : snapRes.elevationCm * SCALE)
            : snapRes.mountSurface === 'ceiling'
            ? fy + WALL_HEIGHT_M - 0.06
            : fy + 0.05 + snapRes.elevationCm * SCALE;

        obj3d.position.set(snapRes.x * SCALE, worldY, snapRes.y * SCALE);

        if (snapRes.mountSurface === 'wall' && snapRes.side) {
          if (activeDrag.item.type === 'camera') {
            obj3d.rotation.y =
              WALL_BASE_YAW[snapRes.side] +
              (activeDrag.item.camPlacement === 'exterior' ? Math.PI : 0) -
              ((activeDrag.item.camAngle ?? 0) * Math.PI) / 180;
          } else if (activeDrag.item.type === 'door' || activeDrag.item.type === 'window') {
            obj3d.rotation.y =
              snapRes.side === 'left' || snapRes.side === 'right' ? Math.PI / 2 : 0;
          } else {
            obj3d.rotation.y = WALL_BASE_YAW[snapRes.side];
          }
        } else {
          obj3d.rotation.y = -((snapRes.rot || 0) * Math.PI) / 180;
        }

        // Move snapped tabletop children along with host desk/table/counter
        if (activeDrag.childItems.length > 0) {
          const dx = snapRes.x - activeDrag.item.x;
          const dy = snapRes.y - activeDrag.item.y;
          for (const child of activeDrag.childItems) {
            const cObj = refs.itemObjectsMap.get(child.id);
            if (cObj) {
              cObj.position.x = (child.x + dx) * SCALE;
              cObj.position.z = (child.y + dy) * SCALE;
            }
          }
        }

        refs.selectionRing.visible = true;
        refs.selectionRing.position.set(snapRes.x * SCALE, worldY + 0.02, snapRes.y * SCALE);
      }

      if (snapRes.snapLabel !== activeDrag.lastHint) {
        activeDrag.lastHint = snapRes.snapLabel;
        setSnapHint(snapRes.snapLabel);
      }
      requestRender();
    };

    const onPointerUp = (e: PointerEvent) => {
      const refs = sceneRefs.current;
      controls.enabled = true;
      const dist = Math.hypot(e.clientX - pointerDownPos.x, e.clientY - pointerDownPos.y);

      if (pendingAnchor) {
        const anchor = pendingAnchor;
        pendingAnchor = null;
        if (dist <= 8) {
          applyAnchorToSelectedRef.current(anchor);
        }
        return;
      }

      if (activeDrag) {
        const drag = activeDrag;
        activeDrag = null;
        if (drag.moved && drag.lastSnap) {
          const s = drag.lastSnap;
          const curProj = projectRef.current;
          const dx = s.x - drag.item.x;
          const dy = s.y - drag.item.y;
          const isHost = SUPPORT_HOST_HEIGHT_CM[drag.item.type] !== undefined;

          const nextItems = curProj.items.map((it) => {
            if (it.id === drag.item.id) {
              return {
                ...it,
                x: s.x,
                y: s.y,
                side: s.side,
                rot: s.rot,
                elevationCm: s.elevationCm,
                mountSurface: s.mountSurface,
                mountHostId: s.mountHostId,
              };
            }
            if (isHost && it.mountHostId === drag.item.id) {
              return { ...it, x: it.x + dx, y: it.y + dy };
            }
            return it;
          });
          setSelectedItemId(drag.item.id);
          setSnapHint(null);
          setInspectedLabel(`${TYPES[drag.item.type].label} · ${s.snapLabel}`);
          onCommitProjectRef.current({ ...curProj, items: nextItems }, true);
          return;
        }
      }

      if (dist > 6 || !refs) return;

      updatePointerNdc(e);
      raycaster.setFromCamera(pointer, camera);

      // Click on an item
      const itemHits = raycaster.intersectObjects(refs.itemClickables, true);
      if (itemHits.length > 0) {
        let obj: THREE.Object3D | null = itemHits[0].object;
        while (
          obj &&
          obj.userData?.itemId === undefined &&
          !obj.userData?.label &&
          obj.userData?.cameraId === undefined &&
          obj.userData?.toggleRoomId === undefined &&
          !obj.userData?.openMonitor
        ) {
          obj = obj.parent;
        }
        if (obj?.userData?.label) {
          setInspectedLabel(String(obj.userData.label));
        }
        if (typeof obj?.userData?.itemId === 'number') {
          const itemId = obj.userData.itemId as number;
          setSelectedItemId(itemId);
          const it = projectRef.current.items.find((i) => i.id === itemId);
          if (it) setSelectedRoomId(it.roomId);
        }
        if (!moveModeRef.current) {
          if (obj?.userData?.openMonitor) {
            setMonitorOpen(true);
            setMonitorTick((t) => t + 1);
            return;
          }
          if (typeof obj?.userData?.cameraId === 'number') {
            setSelectedCameraId(obj.userData.cameraId);
            return;
          }
          if (typeof obj?.userData?.toggleRoomId === 'number') {
            const rId = obj.userData.toggleRoomId as number;
            setDisabledRoomLights((prev) => {
              const next = new Set(prev);
              if (next.has(rId)) next.delete(rId);
              else next.add(rId);
              return next;
            });
            return;
          }
          if (obj?.userData?.isStair) {
            onSetStairWalkModeRef.current(stairWalkModeRef.current === 'up' ? null : 'up');
            return;
          }
        }
        return;
      }

      // Otherwise click on room floor / cables
      const roomHits = raycaster.intersectObjects(refs.roomClickables, true);
      if (roomHits.length > 0) {
        let obj: THREE.Object3D | null = roomHits[0].object;
        while (obj && !obj.userData?.label && obj.userData?.roomId === undefined) {
          obj = obj.parent;
        }
        if (obj?.userData?.label) {
          setInspectedLabel(String(obj.userData.label));
        }
        if (typeof obj?.userData?.roomId === 'number') {
          setSelectedRoomId(obj.userData.roomId);
          setSelectedCameraId(null);
          setSelectedItemId(null);
          setAnchorsVisible(false);
          setMoveMode(false);
          setSnapHint(null);
        }
      } else {
        setInspectedLabel(null);
        setSelectedItemId(null);
        setAnchorsVisible(false);
        setMoveMode(false);
        setSnapHint(null);
      }
    };

    renderer.domElement.addEventListener('pointerdown', onPointerDown);
    window.addEventListener('pointermove', onPointerMove);
    window.addEventListener('pointerup', onPointerUp);

    const onResize = () => {
      if (!container) return;
      const w = container.clientWidth || 900;
      const h = container.clientHeight || 560;
      camera.aspect = w / h;
      camera.updateProjectionMatrix();
      renderer.setSize(w, h);
      requestRender();
    };
    const ro = new ResizeObserver(onResize);
    ro.observe(container);

    sceneRefs.current = {
      scene,
      camera,
      controls,
      renderer,
      worldGroup,
      anchorsGroup,
      selectionRing,
      keyLight,
      hemiLight,
      texCache,
      maxAniso,
      povTarget,
      povCam,
      povPixels,
      cameraRigs: [],
      nvrScreenTex,
      nvrScreenCanvas,
      requestRender,
      cameraPosGoal: null,
      cameraTargetGoal: null,
      roomClickables: [],
      itemClickables: [],
      anchorClickables: [],
      itemObjectsMap: new Map(),
      isSoftwareGl,
    };

    if (!isSoftwareGl) {
      renderer.compile(scene, camera);
    }
    requestRender();

    return () => {
      disposed = true;
      cancelAnimationFrame(frameId);
      clearTimeout(frameId);
      ro.disconnect();
      renderer.domElement.removeEventListener('pointerdown', onPointerDown);
      window.removeEventListener('pointermove', onPointerMove);
      window.removeEventListener('pointerup', onPointerUp);
      controls.dispose();
      groundGeo.dispose();
      groundMat.dispose();
      ringGeo.dispose();
      ringMat.dispose();
      texCache.forEach((tex) => tex.dispose());
      texCache.clear();
      povTarget.dispose();
      nvrScreenTex.dispose();
      envTex.dispose();
      renderer.dispose();
      if (renderer.domElement.parentNode === container) {
        container.removeChild(renderer.domElement);
      }
      sceneRefs.current = null;
    };
  }, []);

  // Rebuild 3D multi-story building whenever state changes
  useEffect(() => {
    const refs = sceneRefs.current;
    if (!refs) return;

    const { scene, worldGroup, keyLight, hemiLight, texCache, maxAniso, nvrScreenTex, requestRender } = refs;

    const getWallTex = (finishId: WallFinishId) => {
      const key = `wall:${finishId}:${nightMode ? 'n' : 'd'}`;
      let t = texCache.get(key);
      if (!t) {
        t = createWallFinishTexture(finishId, nightMode, maxAniso);
        texCache.set(key, t);
      }
      return t;
    };

    const getFloorTex = (finishId: Exclude<FloorFinishId, 'auto'>) => {
      const key = `floor:${finishId}`;
      let t = texCache.get(key);
      if (!t) {
        t = createFloorFinishTexture(finishId, maxAniso);
        texCache.set(key, t);
      }
      return t;
    };

    while (worldGroup.children.length > 0) {
      const child = worldGroup.children[0];
      worldGroup.remove(child);
      child.traverse((obj) => {
        if ((obj as THREE.Mesh).isMesh || (obj as THREE.LineSegments).isLineSegments) {
          const m = obj as THREE.Mesh | THREE.LineSegments;
          m.geometry?.dispose();
          const disposeMat = (mat: THREE.Material) => {
            mat.dispose();
          };
          if (Array.isArray(m.material)) m.material.forEach(disposeMat);
          else if (m.material) disposeMat(m.material);
        }
      });
    }
    refs.roomClickables = [];
    refs.itemClickables = [];
    refs.itemObjectsMap.clear();
    refs.cameraRigs = [];

    const bgHex = nightMode ? '#0b1120' : '#eef2f6';
    scene.background = new THREE.Color(bgHex);
    scene.fog = new THREE.Fog(bgHex, 24, 72);
    keyLight.intensity = nightMode ? 0.35 : 1.55;
    keyLight.color.set(nightMode ? '#93c5fd' : '#fffbeb');
    hemiLight.intensity = nightMode ? 0.38 : 0.85;

    const effectiveXray = xrayWalls || enteredRoomId !== null;
    const wallOpacity = xrayWalls ? 0.16 : enteredRoomId !== null ? 0.42 : project.floors.length > 1 ? 0.88 : 1;

    const edgeMat = new THREE.LineBasicMaterial({
      color: nightMode ? 0x64748b : 0x94a3b8,
      transparent: true,
      opacity: xrayWalls ? 0.55 : 0.32,
    });

    const wallHeight = WALL_HEIGHT_M;
    const wallThick = WALL_THICK_M;
    const floorMap = new Map(project.floors.map((f) => [f.id, f]));

    const styleCfg = FINISH_STYLES[project.finishStyle];
    const plateColor = new THREE.Color(styleCfg.frameHex);

    const visibleRooms =
      floorViewMode === 'active'
        ? project.rooms.filter((r) => r.floorId === project.activeFloorId)
        : project.rooms;

    const visibleItems =
      floorViewMode === 'active'
        ? project.items.filter((i) => i.floorId === project.activeFloorId)
        : project.items;

    // Rooms per floor (with per-room Wall & Floor finish palette)
    for (const r of visibleRooms) {
      const fy = floorYOf(r.floorId);
      const rx = r.x * SCALE;
      const rz = r.y * SCALE;
      const rw = r.w * SCALE;
      const rd = r.h * SCALE;
      const fName = floorMap.get(r.floorId)?.name ?? '';
      const isRoomSelected = selectedRoomId === r.id || enteredRoomId === r.id;

      const resolvedFloor: Exclude<FloorFinishId, 'auto'> =
        r.floorFinish && r.floorFinish !== 'auto'
          ? r.floorFinish
          : r.type === 'sdb' || r.type === 'cuisine' || r.type === 'wc'
          ? 'carrelage_gris'
          : r.type === 'garage'
          ? 'beton_cire'
          : 'parquet_chene';

      const floorTex = r.type === 'terrasse' ? null : getFloorTex(resolvedFloor);
      const isTileFloor = resolvedFloor.startsWith('carrelage');

      const floorMat = new THREE.MeshStandardMaterial({
        color:
          isRoomSelected && enteredRoomId !== r.id
            ? 0xe0f2fe
            : r.type === 'terrasse'
            ? 0xd6cbb5
            : 0xffffff,
        map: floorTex,
        roughness: isTileFloor ? 0.32 : 0.72,
        metalness: 0.04,
      });

      const floorMesh = new THREE.Mesh(new THREE.BoxGeometry(rw, 0.08, rd), floorMat);
      floorMesh.position.set(rx + rw / 2, fy + 0.02, rz + rd / 2);
      floorMesh.receiveShadow = true;
      floorMesh.userData.roomId = r.id;
      floorMesh.userData.label = `${fName ? `${fName} · ` : ''}${r.name} · ${frNum(
        (r.w * r.h) / 10000,
        1
      )} m²`;
      worldGroup.add(floorMesh);
      refs.roomClickables.push(floorMesh);

      if (r.type === 'terrasse') {
        const rail = new THREE.Mesh(
          new THREE.BoxGeometry(rw, 0.12, 0.08),
          new THREE.MeshStandardMaterial({ color: 0x64748b, roughness: 0.5, metalness: 0.4 })
        );
        rail.position.set(rx + rw / 2, fy + 0.9, rz + rd);
        worldGroup.add(rail);
        continue;
      }

      const wallFinish: WallFinishId = r.wallFinish ?? 'peinture_blanche';
      const wallTex = getWallTex(wallFinish);
      const isCeramicWall = wallFinish.startsWith('carrelage');
      const isEnteredWall = enteredRoomId === r.id && !xrayWalls;
      const roomWallMat = new THREE.MeshStandardMaterial({
        color: 0xffffff,
        map: wallTex,
        roughness: isCeramicWall ? 0.28 : 0.78,
        metalness: 0.03,
        transparent: !isEnteredWall && (effectiveXray || project.floors.length > 1),
        opacity: isEnteredWall ? 0.92 : wallOpacity,
        depthWrite: isEnteredWall || !effectiveXray,
      });

      const wallsSpec: [number, number, number, number][] = [
        [rx + rw / 2, rz, rw + wallThick, wallThick],
        [rx + rw / 2, rz + rd, rw + wallThick, wallThick],
        [rx, rz + rd / 2, wallThick, rd],
        [rx + rw, rz + rd / 2, wallThick, rd],
      ];
      for (const [wx, wz, ww, wd] of wallsSpec) {
        const wallGeo = new THREE.BoxGeometry(ww, wallHeight, wd);
        const wallMesh = new THREE.Mesh(wallGeo, roomWallMat.clone());
        wallMesh.position.set(wx, fy + wallHeight / 2, wz);
        wallMesh.castShadow = !effectiveXray;
        wallMesh.receiveShadow = true;
        worldGroup.add(wallMesh);

        if (effectiveXray) {
          const edges = new THREE.LineSegments(new THREE.EdgesGeometry(wallGeo), edgeMat.clone());
          edges.position.copy(wallMesh.position);
          worldGroup.add(edges);
        }
      }
      roomWallMat.dispose();
    }
    edgeMat.dispose();

    const registerItem = (itId: number, obj: THREE.Object3D) => {
      obj.userData.itemId = itId;
      refs.itemClickables.push(obj);
      refs.itemObjectsMap.set(itId, obj);
    };

    // Items
    for (const it of visibleItems) {
      const T = TYPES[it.type];
      const fy = floorYOf(it.floorId);
      const ix = it.x * SCALE;
      const iz = it.y * SCALE;
      const elevCm = resolveItemElevationCm(it, project.items);
      const elevM = elevCm * SCALE;
      const cColor = sim.itemCircuitColor[it.id] || '#334155';
      const cId = sim.itemCircuitId[it.id];
      const isTripped = cId ? trippedCircuitIds.has(cId) : false;
      const isRoomLit = lightsOn && !disabledRoomLights.has(it.roomId) && !isTripped;

      // === SEQUENTIAL LUMINOUS STAIRCASE ===
      if (it.type === 'staircase') {
        const elevIdx = floorMap.get(it.floorId)?.elevationIndex ?? 0;
        const maxElev = Math.max(...project.floors.map((f) => f.elevationIndex));
        if (
          floorViewMode !== 'active' &&
          project.floors.length > 1 &&
          elevIdx === maxElev &&
          /arrivée/i.test(it.name)
        ) {
          continue;
        }

        const stairW = (it.w ?? 110) * SCALE;
        const stairLen = (it.h ?? 220) * SCALE;
        const steps = it.stepCount ?? 14;
        const totalClimb = floorSpacing;
        const stepRise = totalClimb / steps;
        const stepRun = stairLen / steps;
        const ledHex =
          it.ledColor === 'amber'
            ? 0xfb923c
            : it.ledColor === 'neutral'
            ? 0xf8fafc
            : 0xfde047;

        const stairGroup = new THREE.Group();
        stairGroup.position.set(ix, fy + 0.05, iz);
        stairGroup.rotation.y = -((it.rot || 0) * Math.PI) / 180;
        stairGroup.userData.isStair = true;
        stairGroup.userData.label = `Escalier LED Séquentiel · ${steps} marches · ${frNum(
          wattsOf(it)
        )} W (Cliquer pour animer)`;

        const stringerLen = Math.hypot(stairLen, totalClimb);
        const pitch = Math.atan2(totalClimb, stairLen);
        const stringerGeo = new THREE.BoxGeometry(0.06, 0.16, stringerLen);
        const stringerMat = new THREE.MeshStandardMaterial({
          color: 0x334155,
          roughness: 0.4,
          metalness: 0.6,
        });
        for (const sx of [-stairW / 2 + 0.03, stairW / 2 - 0.03]) {
          const st = new THREE.Mesh(stringerGeo.clone(), stringerMat.clone());
          st.position.set(sx, totalClimb / 2, 0);
          st.rotation.x = pitch;
          stairGroup.add(st);
        }

        for (let s = 0; s < steps; s++) {
          const stepNum = s + 1;
          const tz = stairLen / 2 - (s + 0.5) * stepRun;
          const ty = (s + 0.5) * stepRise;

          const tread = new THREE.Mesh(
            new THREE.BoxGeometry(stairW - 0.08, 0.045, stepRun * 0.94),
            new THREE.MeshStandardMaterial({
              color: 0xb68d5c,
              roughness: 0.6,
            })
          );
          tread.position.set(0, ty, tz);
          tread.castShadow = true;
          tread.receiveShadow = true;
          stairGroup.add(tread);

          const dist =
            activeStairStep !== null ? Math.abs(stepNum - activeStairStep) : Infinity;
          const isStepLit = !isTripped && (dist <= 2 || (activeStairStep === null && isRoomLit));
          const intensity =
            activeStairStep === null
              ? isRoomLit
                ? 0.9
                : 0
              : dist === 0
              ? 2.8
              : dist === 1
              ? 1.4
              : dist === 2
              ? 0.55
              : 0;

          const ledStrip = new THREE.Mesh(
            new THREE.BoxGeometry(stairW - 0.14, 0.022, 0.028),
            new THREE.MeshStandardMaterial({
              color: isStepLit ? ledHex : 0x475569,
              emissive: isStepLit ? new THREE.Color(ledHex) : new THREE.Color(0x000000),
              emissiveIntensity: intensity,
              roughness: 0.25,
            })
          );
          ledStrip.position.set(0, ty - 0.022, tz + stepRun * 0.42);
          stairGroup.add(ledStrip);

          if (!isTripped && activeStairStep === stepNum) {
            const walkerDot = new THREE.Mesh(
              new THREE.SphereGeometry(0.11, 14, 14),
              new THREE.MeshStandardMaterial({
                color: 0x3b82f6,
                emissive: new THREE.Color(0x60a5fa),
                emissiveIntensity: 0.8,
              })
            );
            walkerDot.position.set(0, ty + 0.16, tz);
            stairGroup.add(walkerDot);

            const stepLight = new THREE.PointLight(ledHex, nightMode ? 4.5 : 2.0, 3.2, 1.6);
            stepLight.position.set(0, ty + 0.25, tz);
            stairGroup.add(stepLight);
          }
        }

        worldGroup.add(stairGroup);
        registerItem(it.id, stairGroup);
        continue;
      }

      // === FURNITURE & SANITARY ===
      if (T.furn) {
        const fw = (it.w ?? T.w ?? 80) * SCALE;
        const fd = (it.h ?? T.h ?? 80) * SCALE;
        const isWallTv = it.type === 'tv' && it.mountSurface === 'wall' && it.side !== null;
        const group = new THREE.Group();

        if (isWallTv && it.side) {
          group.position.set(ix, fy + (elevCm || 140) * SCALE, iz);
          group.rotation.y = WALL_BASE_YAW[it.side];
        } else {
          group.position.set(ix, fy + 0.05 + elevM, iz);
          group.rotation.y = -((it.rot || 0) * Math.PI) / 180;
        }
        group.userData.roomId = it.roomId;
        group.userData.label = `${T.label}${it.name ? ` (${it.name})` : ''}${
          T.appl ? ` · ${frNum(wattsOf(it))} W` : ''
        }`;

        if (it.type === 'bed1' || it.type === 'bed2') {
          const base = new THREE.Mesh(
            new THREE.BoxGeometry(fw, 0.25, fd),
            new THREE.MeshStandardMaterial({ color: 0x785a40, roughness: 0.75 })
          );
          base.position.y = 0.125;
          base.castShadow = true;
          const mattress = new THREE.Mesh(
            new THREE.BoxGeometry(fw * 0.94, 0.18, fd * 0.94),
            new THREE.MeshStandardMaterial({ color: 0xf8fafc, roughness: 0.9 })
          );
          mattress.position.y = 0.34;
          const pillow = new THREE.Mesh(
            new THREE.BoxGeometry(fw * 0.72, 0.1, 0.32),
            new THREE.MeshStandardMaterial({ color: 0xe2e8f0, roughness: 0.92 })
          );
          pillow.position.set(0, 0.45, -fd * 0.32);
          group.add(base, mattress, pillow);
        } else if (it.type === 'sofa') {
          const seat = new THREE.Mesh(
            new THREE.BoxGeometry(fw, 0.38, fd),
            new THREE.MeshStandardMaterial({ color: 0x475569, roughness: 0.85 })
          );
          seat.position.y = 0.19;
          seat.castShadow = true;
          const back = new THREE.Mesh(
            new THREE.BoxGeometry(fw, 0.42, 0.2),
            new THREE.MeshStandardMaterial({ color: 0x334155, roughness: 0.85 })
          );
          back.position.set(0, 0.55, -fd / 2 + 0.1);
          group.add(seat, back);
        } else if (it.type === 'fridge') {
          const body = new THREE.Mesh(
            new THREE.BoxGeometry(fw, 1.8, fd),
            new THREE.MeshStandardMaterial({ color: 0xcbd5e1, roughness: 0.28, metalness: 0.65 })
          );
          body.position.y = 0.9;
          body.castShadow = true;
          group.add(body);
        } else if (it.type === 'tv') {
          if (isWallTv) {
            const bracket = new THREE.Mesh(
              new THREE.BoxGeometry(fw * 0.35, 0.16, 0.04),
              new THREE.MeshStandardMaterial({ color: 0x334155, roughness: 0.4 })
            );
            bracket.position.set(0, 0, 0.08);
            const screen = new THREE.Mesh(
              new THREE.BoxGeometry(fw, 0.65, 0.05),
              new THREE.MeshStandardMaterial({ color: 0x0f172a, roughness: 0.18, metalness: 0.4 })
            );
            screen.position.set(0, 0, 0.115);
            group.add(bracket, screen);
          } else if (elevCm > 0) {
            // TV resting directly on top of a table, desk, or counter
            const foot = new THREE.Mesh(
              new THREE.BoxGeometry(fw * 0.38, 0.03, Math.max(0.18, fd)),
              new THREE.MeshStandardMaterial({ color: 0x334155, roughness: 0.5 })
            );
            foot.position.y = 0.015;
            const neck = new THREE.Mesh(
              new THREE.BoxGeometry(0.08, 0.12, 0.05),
              new THREE.MeshStandardMaterial({ color: 0x475569, roughness: 0.5 })
            );
            neck.position.y = 0.08;
            const screen = new THREE.Mesh(
              new THREE.BoxGeometry(fw, 0.62, 0.05),
              new THREE.MeshStandardMaterial({ color: 0x0f172a, roughness: 0.18, metalness: 0.4 })
            );
            screen.position.y = 0.42;
            group.add(foot, neck, screen);
          } else {
            const screen = new THREE.Mesh(
              new THREE.BoxGeometry(fw, 0.65, 0.06),
              new THREE.MeshStandardMaterial({ color: 0x0f172a, roughness: 0.18, metalness: 0.4 })
            );
            screen.position.y = 0.9;
            const stand = new THREE.Mesh(
              new THREE.BoxGeometry(fw * 0.4, 0.45, fd),
              new THREE.MeshStandardMaterial({ color: 0x475569, roughness: 0.6 })
            );
            stand.position.y = 0.225;
            group.add(screen, stand);
          }
        } else if (it.type === 'pc') {
          const base = new THREE.Mesh(
            new THREE.BoxGeometry(0.22, 0.02, 0.16),
            new THREE.MeshStandardMaterial({ color: 0x334155, roughness: 0.4, metalness: 0.5 })
          );
          base.position.set(0, 0.01, -0.05);
          const neck = new THREE.Mesh(
            new THREE.BoxGeometry(0.05, 0.16, 0.04),
            new THREE.MeshStandardMaterial({ color: 0x475569, roughness: 0.4, metalness: 0.5 })
          );
          neck.position.set(0, 0.09, -0.07);
          const screen = new THREE.Mesh(
            new THREE.BoxGeometry(0.56, 0.34, 0.03),
            new THREE.MeshStandardMaterial({
              color: 0x0f172a,
              emissive: new THREE.Color(0x0284c7),
              emissiveIntensity: isTripped ? 0 : 0.28,
              roughness: 0.2,
              metalness: 0.35,
            })
          );
          screen.position.set(0, 0.28, -0.05);
          const keyboard = new THREE.Mesh(
            new THREE.BoxGeometry(0.4, 0.018, 0.13),
            new THREE.MeshStandardMaterial({ color: 0x1e293b, roughness: 0.5 })
          );
          keyboard.position.set(-0.04, 0.01, 0.12);
          const mouse = new THREE.Mesh(
            new THREE.BoxGeometry(0.06, 0.018, 0.09),
            new THREE.MeshStandardMaterial({ color: 0x334155, roughness: 0.4 })
          );
          mouse.position.set(0.23, 0.01, 0.12);
          group.add(base, neck, screen, keyboard, mouse);
        } else if (it.type === 'shower' || it.type === 'bath') {
          const tray = new THREE.Mesh(
            new THREE.BoxGeometry(fw, 0.14, fd),
            new THREE.MeshStandardMaterial({ color: 0xffffff, roughness: 0.2, metalness: 0.1 })
          );
          tray.position.y = 0.07;
          const glass = new THREE.Mesh(
            new THREE.BoxGeometry(0.03, 1.9, fd),
            new THREE.MeshStandardMaterial({
              color: 0xbae6fd,
              roughness: 0.1,
              transparent: true,
              opacity: 0.35,
            })
          );
          glass.position.set(-fw / 2 + 0.02, 1.0, 0);
          group.add(tray, glass);
        } else if (it.type === 'sink' || it.type === 'wc') {
          const bowl = new THREE.Mesh(
            new THREE.BoxGeometry(fw, it.type === 'wc' ? 0.42 : 0.85, fd),
            new THREE.MeshStandardMaterial({ color: 0xf8fafc, roughness: 0.25 })
          );
          bowl.position.y = it.type === 'wc' ? 0.21 : 0.425;
          group.add(bowl);
        } else {
          const height =
            it.type === 'wardrobe' ? 2.0 : it.type === 'counter' ? 0.9 : 0.74;
          const box = new THREE.Mesh(
            new THREE.BoxGeometry(fw, height, fd),
            new THREE.MeshStandardMaterial({
              color:
                it.type === 'wardrobe'
                  ? 0x94a3b8
                  : it.type === 'counter'
                  ? 0xe2e8f0
                  : 0xb49a78,
              roughness: 0.72,
            })
          );
          box.position.y = height / 2;
          box.castShadow = true;
          box.receiveShadow = true;
          group.add(box);
        }

        worldGroup.add(group);
        registerItem(it.id, group);
        continue;
      }

      // === DOORS & WINDOWS ===
      if (it.type === 'door' || it.type === 'window') {
        const lenM = (it.len ?? T.len ?? 90) * SCALE;
        const rotY = it.side === 'left' || it.side === 'right' ? Math.PI / 2 : 0;
        const mesh = new THREE.Mesh(
          new THREE.BoxGeometry(lenM, it.type === 'door' ? 2.05 : 1.15, 0.18),
          new THREE.MeshStandardMaterial({
            color: it.type === 'door' ? 0x926c48 : 0x7dd3fc,
            roughness: it.type === 'door' ? 0.65 : 0.15,
            transparent: it.type === 'window',
            opacity: it.type === 'window' ? 0.55 : 1,
          })
        );
        mesh.position.set(ix, fy + (it.type === 'door' ? 1.02 : 1.45), iz);
        mesh.rotation.y = rotY;
        mesh.userData.roomId = it.roomId;
        mesh.userData.label = `${T.label} (${it.len ?? T.len} cm)`;
        worldGroup.add(mesh);
        registerItem(it.id, mesh);
        continue;
      }

      // === CEILING OR TABLETOP LIGHTS ===
      if (it.type === 'light' || it.type === 'spots' || it.type === 'neon') {
        const isDeskLamp = it.type === 'light' && it.mountSurface === 'furniture';
        const g = new THREE.Group();
        g.position.set(
          ix,
          isDeskLamp ? fy + 0.05 + elevM : fy + wallHeight - 0.06,
          iz
        );
        g.userData.toggleRoomId = it.roomId;
        g.userData.label = isDeskLamp
          ? `Lampe posée · ${frNum(wattsOf(it))} W (Cliquer pour allumer/éteindre)`
          : `${T.label} · ${frNum(wattsOf(it))} W (Cliquer pour allumer/éteindre)`;

        if (isDeskLamp) {
          const lampBase = new THREE.Mesh(
            new THREE.CylinderGeometry(0.11, 0.13, 0.03, 16),
            new THREE.MeshStandardMaterial({ color: 0x334155, roughness: 0.4, metalness: 0.5 })
          );
          lampBase.position.y = 0.015;
          const stem = new THREE.Mesh(
            new THREE.CylinderGeometry(0.018, 0.018, 0.28, 10),
            new THREE.MeshStandardMaterial({ color: 0x64748b, roughness: 0.35, metalness: 0.6 })
          );
          stem.position.y = 0.16;
          const shade = new THREE.Mesh(
            new THREE.CylinderGeometry(0.1, 0.16, 0.16, 16),
            new THREE.MeshStandardMaterial({
              color: isRoomLit ? 0xfef08a : 0xcbd5e1,
              emissive: isRoomLit ? new THREE.Color(0xfacc15) : new THREE.Color(0x000000),
              emissiveIntensity: isRoomLit ? (nightMode ? 1.5 : 0.8) : 0,
              roughness: 0.4,
            })
          );
          shade.position.y = 0.34;
          g.add(lampBase, stem, shade);
          if (isRoomLit) {
            const pLight = new THREE.PointLight(0xfef3c7, nightMode ? 2.6 : 1.0, 4.5, 1.5);
            pLight.position.y = 0.36;
            g.add(pLight);
          }
        } else {
          const fixture = new THREE.Mesh(
            it.type === 'neon'
              ? new THREE.BoxGeometry((it.len ?? 200) * SCALE, 0.05, 0.08)
              : new THREE.CylinderGeometry(0.18, 0.22, 0.08, 16),
            new THREE.MeshStandardMaterial({
              color: isRoomLit ? 0xfef08a : 0x94a3b8,
              emissive: isRoomLit ? new THREE.Color(0xfacc15) : new THREE.Color(0x000000),
              emissiveIntensity: isRoomLit ? (nightMode ? 1.8 : 0.9) : 0,
              roughness: 0.3,
            })
          );
          if (it.type === 'neon') {
            fixture.rotation.y = -((it.rot || 0) * Math.PI) / 180;
          }
          g.add(fixture);

          if (isRoomLit) {
            const pLight = new THREE.PointLight(0xfef3c7, nightMode ? 4.0 : 1.35, 7.5, 1.5);
            pLight.position.y = -0.2;
            g.add(pLight);
          }
        }

        worldGroup.add(g);
        registerItem(it.id, g);
        continue;
      }

      // === SURVEILLANCE CAMERA WITH FOV CONE & LIVE POV RIG ===
      if (it.type === 'camera') {
        const isDeskCam = it.mountSurface === 'furniture' && !it.side;
        const side: WallSide = it.side ?? 'top';
        const isExt = it.camPlacement === 'exterior';
        const yaw = isDeskCam
          ? -((it.rot || 0) * Math.PI) / 180 - ((it.camAngle ?? 0) * Math.PI) / 180
          : WALL_BASE_YAW[side] +
            (isExt ? Math.PI : 0) -
            ((it.camAngle ?? 0) * Math.PI) / 180;
        const fovDeg = it.camFov ?? 90;
        const rangeM = (it.camRange ?? 450) * SCALE;
        const camSelected = selectedCameraId === it.id;
        const fovColor = isExt ? 0x0284c7 : 0x0d9488;

        const camGroup = new THREE.Group();
        camGroup.position.set(
          ix,
          isDeskCam ? fy + 0.05 + elevM + 0.1 : fy + (elevCm || 222) * SCALE,
          iz
        );
        camGroup.rotation.y = yaw;
        camGroup.userData.cameraId = it.id;
        camGroup.userData.label = `${T.label}${it.name ? ` (${it.name})` : ''} · ${
          isDeskCam ? 'Sur meuble' : isExt ? 'Extérieur' : 'Intérieur'
        } · FOV ${fovDeg}°`;

        const camBody = new THREE.Mesh(
          new THREE.BoxGeometry(0.16, 0.14, 0.24),
          new THREE.MeshStandardMaterial({
            color: camSelected ? 0x2563eb : 0x0f766e,
            roughness: 0.32,
            metalness: 0.3,
          })
        );
        camBody.position.set(0, 0, isDeskCam ? 0 : 0.08);
        camGroup.add(camBody);

        const lens = new THREE.Mesh(
          new THREE.CylinderGeometry(0.045, 0.045, 0.08, 12),
          new THREE.MeshStandardMaterial({
            color: isTripped ? 0x475569 : 0x38bdf8,
            emissive: isTripped ? new THREE.Color(0x000000) : new THREE.Color(0x0ea5e9),
            emissiveIntensity: isTripped ? 0 : 0.7,
          })
        );
        lens.rotation.x = Math.PI / 2;
        lens.position.set(0, 0, isDeskCam ? 0.13 : 0.21);
        camGroup.add(lens);

        if (showCameraFov3D && !isTripped) {
          const fovGeo = createCameraFovGeometry(fovDeg, rangeM);
          const fovMat = new THREE.MeshBasicMaterial({
            color: fovColor,
            transparent: true,
            opacity: camSelected ? 0.28 : 0.14,
            side: THREE.DoubleSide,
            depthWrite: false,
          });
          const fovMesh = new THREE.Mesh(fovGeo, fovMat);
          fovMesh.position.set(0, 0, isDeskCam ? 0.14 : 0.22);
          camGroup.add(fovMesh);

          const fovEdges = new THREE.LineSegments(
            new THREE.EdgesGeometry(fovGeo),
            new THREE.LineBasicMaterial({
              color: fovColor,
              transparent: true,
              opacity: camSelected ? 0.85 : 0.45,
            })
          );
          fovEdges.position.copy(fovMesh.position);
          camGroup.add(fovEdges);
        }

        worldGroup.add(camGroup);
        registerItem(it.id, camGroup);
        refs.cameraRigs.push({
          item: it,
          worldPos: camGroup.position.clone(),
          yaw,
          group: camGroup,
          isTripped,
        });
      } else if (it.type === 'nvr_screen') {
        const onDesk = it.mountSurface === 'furniture' && !it.side;
        const side: WallSide = it.side ?? 'top';
        const yaw = onDesk ? -((it.rot || 0) * Math.PI) / 180 : WALL_BASE_YAW[side];
        const nvrGroup = new THREE.Group();
        nvrGroup.position.set(
          ix,
          onDesk ? fy + 0.05 + elevM : fy + (elevCm || 148) * SCALE,
          iz
        );
        nvrGroup.rotation.y = yaw;
        nvrGroup.userData.openMonitor = true;
        nvrGroup.userData.label = `${T.label} (Cliquer pour afficher les caméras en direct)`;

        if (onDesk) {
          const foot = new THREE.Mesh(
            new THREE.BoxGeometry(0.22, 0.02, 0.14),
            new THREE.MeshStandardMaterial({ color: 0x334155, roughness: 0.4 })
          );
          foot.position.set(0, 0.01, 0);
          const neck = new THREE.Mesh(
            new THREE.BoxGeometry(0.05, 0.14, 0.04),
            new THREE.MeshStandardMaterial({ color: 0x475569, roughness: 0.4 })
          );
          neck.position.set(0, 0.08, -0.02);
          nvrGroup.add(foot, neck);
        }

        const bezel = new THREE.Mesh(
          new THREE.BoxGeometry(0.58, 0.38, 0.05),
          new THREE.MeshStandardMaterial({ color: 0x0f172a, roughness: 0.3, metalness: 0.4 })
        );
        bezel.position.set(0, onDesk ? 0.28 : 0, onDesk ? 0 : 0.09);
        nvrGroup.add(bezel);

        const screenPlane = new THREE.Mesh(
          new THREE.PlaneGeometry(0.52, 0.32),
          new THREE.MeshBasicMaterial({
            map: isTripped ? null : nvrScreenTex,
            color: isTripped ? 0x1e293b : 0xffffff,
          })
        );
        screenPlane.position.set(0, onDesk ? 0.28 : 0, onDesk ? 0.028 : 0.118);
        nvrGroup.add(screenPlane);

        worldGroup.add(nvrGroup);
        registerItem(it.id, nvrGroup);
      } else if (it.type === 'ac_split') {
        const side: WallSide = it.side ?? 'top';
        const yaw = WALL_BASE_YAW[side];
        const acGroup = new THREE.Group();
        acGroup.position.set(ix, fy + (elevCm || 210) * SCALE, iz);
        acGroup.rotation.y = yaw;
        acGroup.userData.roomId = it.roomId;
        acGroup.userData.label = `${T.label}${it.name ? ` (${it.name})` : ''} · ${frNum(
          wattsOf(it)
        )} W`;

        const chassis = new THREE.Mesh(
          new THREE.BoxGeometry(0.86, 0.28, 0.22),
          new THREE.MeshStandardMaterial({ color: 0xf8fafc, roughness: 0.28, metalness: 0.1 })
        );
        chassis.position.set(0, 0, 0.14);
        const louver = new THREE.Mesh(
          new THREE.BoxGeometry(0.76, 0.04, 0.04),
          new THREE.MeshStandardMaterial({ color: 0x0284c7, roughness: 0.4 })
        );
        louver.position.set(0, -0.09, 0.24);
        const statusLed = new THREE.Mesh(
          new THREE.SphereGeometry(0.015, 8, 8),
          new THREE.MeshStandardMaterial({
            color: isTripped ? 0x64748b : 0x22c55e,
            emissive: isTripped ? new THREE.Color(0x000000) : new THREE.Color(0x22c55e),
            emissiveIntensity: isTripped ? 0 : 1.2,
          })
        );
        statusLed.position.set(0.36, -0.04, 0.255);
        acGroup.add(chassis, louver, statusLed);

        worldGroup.add(acGroup);
        registerItem(it.id, acGroup);
      } else if (it.type === 'ac_outdoor') {
        const side: WallSide = it.side ?? 'top';
        const yaw = WALL_BASE_YAW[side];
        const pacGroup = new THREE.Group();
        pacGroup.position.set(ix, fy + (elevCm || 55) * SCALE, iz);
        pacGroup.rotation.y = yaw;
        pacGroup.userData.roomId = it.roomId;
        pacGroup.userData.label = `${T.label}${it.name ? ` (${it.name})` : ''} · ${frNum(
          wattsOf(it)
        )} W`;

        const box = new THREE.Mesh(
          new THREE.BoxGeometry(0.82, 0.58, 0.32),
          new THREE.MeshStandardMaterial({ color: 0xe2e8f0, roughness: 0.42, metalness: 0.35 })
        );
        box.position.set(0, 0, 0.18);
        const fan = new THREE.Mesh(
          new THREE.CylinderGeometry(0.2, 0.2, 0.05, 18),
          new THREE.MeshStandardMaterial({ color: 0x1e293b, roughness: 0.5 })
        );
        fan.rotation.x = Math.PI / 2;
        fan.position.set(-0.14, 0.02, 0.34);
        pacGroup.add(box, fan);

        worldGroup.add(pacGroup);
        registerItem(it.id, pacGroup);
      } else {
        // === OTHER WALL, DESK & CEILING DEVICES ===
        const isStyleSwitchOrSocket = [
          'switch',
          'pushbutton',
          'dimmer',
          'socket',
          'socket2',
          'usb_socket',
          'rj45',
        ].includes(it.type);

        const isCommandSwitch = ['switch', 'pushbutton', 'dimmer', 'motion', 'sconce'].includes(
          it.type
        );

        const onDesk = it.mountSurface === 'furniture' && !it.side;
        const devSize: [number, number, number] =
          it.type === 'panel'
            ? [0.42, 0.58, 0.14]
            : it.type === 'heater'
            ? [0.75, 0.52, 0.12]
            : it.type === 'cooktop'
            ? [0.6, 0.08, 0.6]
            : it.type === 'irve'
            ? [0.28, 0.42, 0.16]
            : it.type === 'alarm_panel'
            ? [0.26, 0.18, 0.06]
            : it.type === 'thermostat'
            ? [0.14, 0.12, 0.05]
            : [0.14, 0.14, 0.07];

        const devGroup = new THREE.Group();
        const worldY =
          it.type === 'smoke'
            ? fy + wallHeight - 0.05
            : onDesk
            ? fy + 0.05 + elevM
            : fy + (elevCm || defaultWallElevationCm(it.type)) * SCALE;

        devGroup.position.set(ix, worldY, iz);
        if (onDesk) {
          devGroup.rotation.y = -((it.rot || 0) * Math.PI) / 180;
        } else if (it.side) {
          devGroup.rotation.y = WALL_BASE_YAW[it.side];
        }

        const devMesh = new THREE.Mesh(
          new THREE.BoxGeometry(...devSize),
          new THREE.MeshStandardMaterial({
            color:
              it.type === 'panel'
                ? 0x1e293b
                : it.type === 'siren'
                ? 0xdc2626
                : it.type === 'alarm_panel'
                ? 0x0f766e
                : it.type === 'thermostat'
                ? 0x0284c7
                : isStyleSwitchOrSocket
                ? plateColor
                : cColor,
            emissive:
              it.type === 'sconce' && isRoomLit
                ? new THREE.Color(0xfacc15)
                : new THREE.Color(0x000000),
            emissiveIntensity: it.type === 'sconce' && isRoomLit ? 1.1 : 0,
            roughness: 0.35,
            metalness:
              project.finishStyle === 'laiton' || project.finishStyle === 'alu' ? 0.45 : 0.18,
          })
        );

        if (onDesk) {
          devMesh.position.set(0, devSize[1] / 2, 0);
        } else if (it.side) {
          // Sit proud on the interior wall surface (half wall thickness 0.07m + half device depth)
          devMesh.position.set(0, 0, it.type === 'cooktop' ? devSize[2] / 2 : 0.07 + devSize[2] / 2);
        }

        devGroup.add(devMesh);

        if (it.type === 'alarm_panel') {
          devGroup.userData.openMonitor = true;
          devGroup.userData.label = `${T.label} (Cliquer pour voir l’écran des caméras)`;
        } else if (isCommandSwitch) {
          devGroup.userData.toggleRoomId = it.roomId;
          devGroup.userData.label = `${T.label} (Cliquer pour tester l'éclairage de la pièce)`;
        } else {
          devGroup.userData.roomId = it.roomId;
          devGroup.userData.label = `${T.label}${it.name ? ` (${it.name})` : ''}${
            T.power ? ` · ${frNum(wattsOf(it))} W` : ''
          }`;
        }

        worldGroup.add(devGroup);
        registerItem(it.id, devGroup);
      }

      // === X-RAY IN-WALL VERTICAL CONDUIT (GAINE ICTA) ===
      if (effectiveXray && T.place === 'wall' && it.side) {
        const devDropY = elevCm * SCALE;
        const topY = wallHeight - 0.12;
        const dropLen = Math.max(0.15, topY - devDropY);
        const conduit = new THREE.Mesh(
          new THREE.CylinderGeometry(0.014, 0.014, dropLen, 6),
          new THREE.MeshStandardMaterial({
            color: cColor,
            roughness: 0.4,
            transparent: isTripped,
            opacity: isTripped ? 0.25 : 0.92,
          })
        );
        conduit.position.set(ix, fy + devDropY + dropLen / 2, iz);
        worldGroup.add(conduit);
      }
    }

    // 3D Multi-Floor Overhead Circuit Cables
    if (showCables3D) {
      for (const c of sim.circuits) {
        const filteredPts =
          floorViewMode === 'active'
            ? c.chain.filter((pt) => (pt.floorId ?? 0) === project.activeFloorId)
            : c.chain;
        if (filteredPts.length < 2) continue;

        const pts: THREE.Vector3[] = [];
        for (let i = 0; i < filteredPts.length; i++) {
          const cur = filteredPts[i];
          const x = cur.x * SCALE;
          const z = cur.y * SCALE;
          const curY = floorYOf(cur.floorId ?? 0) + wallHeight - 0.12;
          if (i === 0) {
            pts.push(new THREE.Vector3(x, floorYOf(cur.floorId ?? 0) + 1.75, z));
            pts.push(new THREE.Vector3(x, curY, z));
          } else {
            const prev = filteredPts[i - 1];
            const prevY = floorYOf(prev.floorId ?? 0) + wallHeight - 0.12;
            pts.push(new THREE.Vector3(x, prevY, prev.y * SCALE));
            pts.push(new THREE.Vector3(x, curY, z));
          }
        }
        const curve = new THREE.CatmullRomCurve3(pts, false, 'catmullrom', 0.05);
        const tubeGeo = new THREE.TubeGeometry(
          curve,
          Math.max(18, pts.length * 4),
          0.018,
          6,
          false
        );
        const tubeMat = new THREE.MeshStandardMaterial({
          color: c.color,
          roughness: 0.45,
          transparent: trippedCircuitIds.has(c.id),
          opacity: trippedCircuitIds.has(c.id) ? 0.2 : 0.92,
        });
        const tube = new THREE.Mesh(tubeGeo, tubeMat);
        tube.userData.label = `Circuit ${c.name} · ${frNum(c.sectionMm2, 1)} mm² · ${c.breakerA} A`;
        worldGroup.add(tube);
        refs.roomClickables.push(tube);
      }
    }

    requestRender();
  }, [
    project,
    sim,
    nightMode,
    lightsOn,
    disabledRoomLights,
    showCables3D,
    showCameraFov3D,
    xrayWalls,
    enteredRoomId,
    selectedRoomId,
    selectedCameraId,
    floorViewMode,
    floorSpacing,
    floorYOf,
    trippedCircuitIds,
    activeStairStep,
  ]);

  // Fast Overlay Effect: Render 3D Selection Ring & Glowing Accrocheurs without rebuilding walls!
  useEffect(() => {
    const refs = sceneRefs.current;
    if (!refs) return;
    const { anchorsGroup, selectionRing, itemObjectsMap, requestRender } = refs;

    while (anchorsGroup.children.length > 0) {
      const child = anchorsGroup.children[0];
      anchorsGroup.remove(child);
      child.traverse((obj) => {
        if ((obj as THREE.Mesh).isMesh) {
          const m = obj as THREE.Mesh;
          m.geometry?.dispose();
          if (Array.isArray(m.material)) m.material.forEach((mat) => mat.dispose());
          else m.material?.dispose();
        }
      });
    }
    refs.anchorClickables = [];

    const selItem =
      selectedItemId !== null
        ? project.items.find((i) => i.id === selectedItemId) ?? null
        : null;

    if (!selItem) {
      selectionRing.visible = false;
      requestRender();
      return;
    }

    const obj3d = itemObjectsMap.get(selItem.id);
    if (obj3d) {
      selectionRing.visible = true;
      selectionRing.position.set(obj3d.position.x, obj3d.position.y + 0.02, obj3d.position.z);
      (selectionRing.material as THREE.MeshBasicMaterial).color.setHex(
        selItem.locked ? 0xf59e0b : 0x0ea5e9
      );
    } else {
      selectionRing.visible = false;
    }

    if (anchorsVisible && !selItem.locked) {
      const room = project.rooms.find((r) => r.id === selItem.roomId);
      if (room) {
        const fy = floorYOf(room.floorId);
        const roomItems = project.items.filter((i) => i.roomId === room.id);
        const anchors = generateRoomSnapAnchors(room, selItem, roomItems);

        const kindColor: Record<SnapAnchor['kind'], number> = {
          tabletop: 0x10b981,
          wall: 0x0ea5e9,
          ceiling: 0xf59e0b,
          floor: 0x6366f1,
        };

        for (const a of anchors) {
          const color = kindColor[a.kind];
          const g = new THREE.Group();
          g.position.set(a.markerX, fy + a.markerY, a.markerZ);
          g.userData.anchorData = a;

          const orb = new THREE.Mesh(
            new THREE.SphereGeometry(0.065, 14, 14),
            new THREE.MeshBasicMaterial({ color })
          );
          g.add(orb);

          const halo = new THREE.Mesh(
            new THREE.RingGeometry(0.085, 0.125, 20),
            new THREE.MeshBasicMaterial({
              color,
              side: THREE.DoubleSide,
              transparent: true,
              opacity: 0.78,
            })
          );
          if (a.kind === 'wall' && a.side) {
            halo.rotation.y = WALL_BASE_YAW[a.side];
          } else {
            halo.rotation.x = -Math.PI / 2;
          }
          g.add(halo);

          // Generous click target sphere
          const hit = new THREE.Mesh(
            new THREE.SphereGeometry(0.15, 10, 10),
            new THREE.MeshBasicMaterial({
              transparent: true,
              opacity: 0.001,
              depthWrite: false,
            })
          );
          hit.userData.anchorData = a;
          g.add(hit);

          anchorsGroup.add(g);
          refs.anchorClickables.push(g);
        }
      }
    }

    requestRender();
  }, [selectedItemId, anchorsVisible, project, floorYOf, floorViewMode]);

  const activeRoom =
    project.rooms.find((r) => r.id === (enteredRoomId ?? selectedRoomId)) ?? null;
  const selectedItem =
    project.items.find((i) => i.id === selectedItemId) ?? null;
  const selectedCamera =
    project.items.find((i) => i.id === selectedCameraId && i.type === 'camera') ?? null;
  const allCameras = useMemo(
    () => project.items.filter((i) => i.type === 'camera'),
    [project.items]
  );

  const roomCircuits = useMemo(() => {
    if (!activeRoom) return [];
    return sim.circuits.filter((c) => c.items.some((it) => it.roomId === activeRoom.id));
  }, [activeRoom, sim.circuits]);

  const updateRoomFinish = (patch: Partial<Room>) => {
    if (!activeRoom) return;
    onCommitProject(
      {
        ...project,
        rooms: project.rooms.map((r) => (r.id === activeRoom.id ? { ...r, ...patch } : r)),
      },
      true
    );
  };

  const updateSelectedItem = (patch: Partial<PlanItem>, recordHistory = true) => {
    if (!selectedItem) return;
    const isHost = SUPPORT_HOST_HEIGHT_CM[selectedItem.type] !== undefined;
    const dx = patch.x !== undefined ? patch.x - selectedItem.x : 0;
    const dy = patch.y !== undefined ? patch.y - selectedItem.y : 0;

    onCommitProject(
      {
        ...project,
        items: project.items.map((it) => {
          if (it.id === selectedItem.id) return { ...it, ...patch };
          if (isHost && it.mountHostId === selectedItem.id && (dx !== 0 || dy !== 0)) {
            return { ...it, x: it.x + dx, y: it.y + dy };
          }
          return it;
        }),
      },
      recordHistory
    );
  };

  const deleteSelectedItem = () => {
    if (!selectedItem) return;
    const deletedId = selectedItem.id;
    onCommitProject(
      {
        ...project,
        items: project.items
          .filter((i) => i.id !== deletedId)
          .map((i) =>
            i.mountHostId === deletedId ? { ...i, mountHostId: null, mountSurface: 'floor', elevationCm: 0 } : i
          ),
      },
      true
    );
    setSelectedItemId(null);
    setSelectedCameraId(null);
    setAnchorsVisible(false);
    setMoveMode(false);
    setSnapHint(null);
  };

  const handleAddToActiveRoom = (type: ItemType) => {
    if (!activeRoom) return;
    const T = TYPES[type];
    const roomItems = project.items.filter((i) => i.roomId === activeRoom.id);
    const itemsInRoom = roomItems.length;
    const offset = (itemsInRoom % 4) * 35;

    let nextItem: PlanItem;
    const tabletopHost = TABLETOP_COMPATIBLE_TYPES.has(type)
      ? roomItems.find((h) => SUPPORT_HOST_HEIGHT_CM[h.type] !== undefined)
      : undefined;

    if ((type === 'pc' || type === 'tv' || type === 'nvr_screen') && tabletopHost) {
      const topCm = SUPPORT_HOST_HEIGHT_CM[tabletopHost.type] ?? 74;
      nextItem = {
        id: project.nextId,
        type,
        floorId: activeRoom.floorId,
        roomId: activeRoom.id,
        x: tabletopHost.x,
        y: tabletopHost.y,
        side: null,
        rot: tabletopHost.rot || 0,
        watts: T.watts,
        ...(T.w ? { w: T.w, h: T.h } : {}),
        name: '',
        elevationCm: topCm,
        mountSurface: 'furniture',
        mountHostId: tabletopHost.id,
      };
    } else if (T.place === 'wall') {
      const sides: WallSide[] = ['top', 'right', 'bottom', 'left'];
      const side = sides[itemsInRoom % sides.length];
      const t = 0.25 + (itemsInRoom % 5) * 0.14;
      const targetPt = {
        x: activeRoom.x + activeRoom.w * t,
        y: activeRoom.y + activeRoom.h * t,
      };
      const pos = wallPos(activeRoom, side, targetPt, T.half ?? 16);
      nextItem = {
        id: project.nextId,
        type,
        floorId: activeRoom.floorId,
        roomId: activeRoom.id,
        x: pos.x,
        y: pos.y,
        side,
        rot: WALL_ROT_DEG[side],
        watts: T.watts,
        name: '',
        elevationCm: defaultWallElevationCm(type),
        mountSurface: 'wall',
        mountHostId: null,
        ...(type === 'camera'
          ? { camPlacement: 'interior', camAngle: 0, camFov: 90, camRange: 450 }
          : {}),
      };
    } else if (T.furn) {
      const w = T.w ?? 100;
      const h = T.h ?? 80;
      const rawItem: PlanItem = {
        id: project.nextId,
        type,
        floorId: activeRoom.floorId,
        roomId: activeRoom.id,
        x: activeRoom.x + activeRoom.w / 2 + (offset - 50),
        y: activeRoom.y + activeRoom.h / 2 + (offset - 50),
        side: null,
        rot: 0,
        watts: T.watts,
        w,
        h,
        name: '',
        elevationCm: 0,
        mountSurface: 'floor',
        mountHostId: null,
      };
      nextItem = fitItemInRoom(rawItem, activeRoom);
    } else {
      const rawItem: PlanItem = {
        id: project.nextId,
        type,
        floorId: activeRoom.floorId,
        roomId: activeRoom.id,
        x: activeRoom.x + activeRoom.w / 2 + (itemsInRoom % 2 === 0 ? 0 : 40),
        y: activeRoom.y + activeRoom.h / 2,
        side: null,
        rot: 0,
        watts: T.watts,
        name: '',
        elevationCm: 239,
        mountSurface: 'ceiling',
        mountHostId: null,
        ...(type === 'spots' ? { count: 4, spacing: 80 } : {}),
      };
      nextItem = fitItemInRoom(rawItem, activeRoom);
    }

    onCommitProject(
      {
        ...project,
        items: [...project.items, nextItem],
        nextId: project.nextId + 1,
      },
      true
    );

    // Immediately show Accrocheurs and clear the room view so user can place/move it anywhere!
    setSelectedItemId(nextItem.id);
    setAnchorsVisible(true);
    setMoveMode(true);
    setRoomStudioOpen(false);
    if (type === 'camera') {
      setSelectedCameraId(nextItem.id);
    } else {
      setSelectedCameraId(null);
    }
    setSnapHint('Cliquez sur un accrocheur lumineux (mur, bureau, table) ou glissez l’objet');
    setInspectedLabel(`${T.label} ajouté · Choisissez un accrocheur ou glissez en 3D`);
  };

  const updateSelectedCamera = (patch: Partial<PlanItem>, recordHistory = false) => {
    if (!selectedCamera) return;
    onCommitProject(
      {
        ...project,
        items: project.items.map((it) =>
          it.id === selectedCamera.id ? { ...it, ...patch } : it
        ),
      },
      recordHistory
    );
  };

  const hasStairs = project.items.some((i) => i.type === 'staircase');

  const selectedItemSurfaceLabel = useMemo(() => {
    if (!selectedItem) return '';
    if (selectedItem.mountSurface === 'furniture' && selectedItem.mountHostId) {
      const host = project.items.find((h) => h.id === selectedItem.mountHostId);
      if (host) return `Accroché sur ${TYPES[host.type].short}`;
    }
    if (selectedItem.side) {
      const wallName: Record<WallSide, string> = {
        top: 'Mur Nord',
        right: 'Mur Est',
        bottom: 'Mur Sud',
        left: 'Mur Ouest',
      };
      const elev = resolveItemElevationCm(selectedItem, project.items);
      return `${wallName[selectedItem.side]} · ${elev} cm`;
    }
    if (selectedItem.mountSurface === 'ceiling') return 'Fixé au plafond';
    return 'Posé au sol';
  }, [selectedItem, project.items]);

  return (
    <div className="relative h-[clamp(520px,78vh,820px)] w-full overflow-hidden rounded-xl border border-slate-200 bg-slate-100 dark:border-slate-800 dark:bg-slate-950">
      {/* Isolated Three.js Mount Container */}
      <div
        ref={mountRef}
        className={`h-full w-full ${
          selectedItem && !selectedItem.locked && (moveMode || selectedItemId !== null)
            ? 'cursor-grab active:cursor-grabbing'
            : ''
        }`}
      />

      {/* Top-Left Minimal Spec & Quick Room Selector */}
      <div className="absolute top-3 left-3 z-20 flex max-w-[490px] flex-wrap items-center gap-2 rounded-lg border border-slate-200 bg-white/95 px-3 py-2 text-xs text-slate-800 shadow-sm dark:border-slate-700 dark:bg-slate-900/95 dark:text-slate-100">
        <div className="min-w-0 flex-1">
          <div className="font-display font-semibold">
            {enteredRoomId !== null && activeRoom
              ? `Intérieur : ${activeRoom.name}`
              : `Maquette 3D · ${project.floors.length} niveau${project.floors.length > 1 ? 'x' : ''}`}
          </div>
          <div className="truncate font-mono text-[11px] tabular-nums text-slate-500 dark:text-slate-400">
            {snapHint ||
              inspectedLabel ||
              'Touchez un meuble/équipement pour le déplacer ou l’accrocher'}
          </div>
        </div>
        <select
          aria-label="Choisir une pièce pour entrer en 3D"
          value={enteredRoomId ?? selectedRoomId ?? ''}
          onChange={(e) => {
            const id = Number(e.target.value);
            const rm = project.rooms.find((r) => r.id === id);
            if (rm) enterRoomIn3D(rm);
          }}
          className="rounded-md border border-slate-200 bg-slate-50 px-2 py-1 text-[11px] font-medium text-slate-800 dark:border-slate-700 dark:bg-slate-950 dark:text-slate-200"
        >
          <option value="">Aller dans une pièce…</option>
          {project.rooms.map((r) => (
            <option key={r.id} value={r.id}>
              {r.name}
            </option>
          ))}
        </select>
        {enteredRoomId !== null && (
          <button
            type="button"
            onClick={() => setCameraPreset('iso')}
            className="inline-flex items-center gap-1 rounded-md bg-slate-900 px-2 py-1 text-[11px] font-medium text-white hover:bg-slate-800 dark:bg-slate-100 dark:text-slate-950"
          >
            <LogOut className="h-3 w-3" />
            <span>Sortir</span>
          </button>
        )}
      </div>

      {/* Top-Right Compact Pill when Room is active & Studio Drawer is closed */}
      {activeRoom && !roomStudioOpen && (
        <div className="absolute top-3 right-3 z-20 flex items-center gap-1.5 rounded-lg border border-slate-200 bg-white/95 p-1.5 shadow-sm dark:border-slate-700 dark:bg-slate-900/95">
          {enteredRoomId !== activeRoom.id && (
            <button
              type="button"
              onClick={() => enterRoomIn3D(activeRoom)}
              className="inline-flex items-center gap-1 rounded-md bg-slate-900 px-2.5 py-1.5 text-xs font-medium text-white hover:bg-slate-800 dark:bg-slate-100 dark:text-slate-950"
            >
              <DoorOpen className="h-3.5 w-3.5" />
              <span>Entrer ({activeRoom.name})</span>
            </button>
          )}
          <button
            type="button"
            onClick={() => setRoomStudioOpen(true)}
            className="inline-flex items-center gap-1.5 rounded-md border border-blue-300 bg-blue-50 px-2.5 py-1.5 text-xs font-semibold text-blue-900 hover:bg-blue-100 dark:border-sky-700 dark:bg-sky-950/60 dark:text-sky-200"
          >
            <Paintbrush className="h-3.5 w-3.5" />
            <span>Habillage & Ajout · {activeRoom.name}</span>
          </button>
          <button
            type="button"
            onClick={() =>
              setDisabledRoomLights((prev) => {
                const next = new Set(prev);
                if (next.has(activeRoom.id)) next.delete(activeRoom.id);
                else next.add(activeRoom.id);
                return next;
              })
            }
            className={`inline-flex items-center gap-1 rounded-md border px-2 py-1.5 text-xs font-medium ${
              lightsOn && !disabledRoomLights.has(activeRoom.id)
                ? 'border-amber-300 bg-amber-50 text-amber-900 dark:border-amber-700 dark:bg-amber-950/60 dark:text-amber-200'
                : 'border-slate-200 bg-slate-50 text-slate-600 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-300'
            }`}
            title="Allumer / Éteindre la pièce"
          >
            <Lightbulb className="h-3.5 w-3.5" />
          </button>
        </div>
      )}

      {/* Snap Legend when Accrocheurs are visible */}
      {anchorsVisible && selectedItem && (
        <div className="pointer-events-none absolute top-16 left-1/2 z-20 flex -translate-x-1/2 flex-wrap items-center gap-3 rounded-lg border border-sky-200 bg-white/95 px-3 py-1.5 text-[11px] font-medium text-slate-700 shadow-sm dark:border-sky-800 dark:bg-slate-900/95 dark:text-slate-200">
          <span className="inline-flex items-center gap-1.5">
            <span className="h-2.5 w-2.5 rounded-full bg-sky-500" />
            Murs
          </span>
          <span className="inline-flex items-center gap-1.5">
            <span className="h-2.5 w-2.5 rounded-full bg-emerald-500" />
            Tables & Bureaux
          </span>
          <span className="inline-flex items-center gap-1.5">
            <span className="h-2.5 w-2.5 rounded-full bg-indigo-500" />
            Sol
          </span>
          <span className="inline-flex items-center gap-1.5">
            <span className="h-2.5 w-2.5 rounded-full bg-amber-500" />
            Plafond
          </span>
          <span className="font-mono text-[10px] text-slate-500 dark:text-slate-400">
            Cliquez un point ou glissez « {TYPES[selectedItem.type].short} »
          </span>
        </div>
      )}

      {/* On-Screen Maneuver Pad (Bottom-Left) */}
      <div className="absolute bottom-20 left-3 z-20 hidden sm:flex flex-col items-center gap-1 rounded-xl border border-slate-200 bg-white/95 p-2 shadow-sm dark:border-slate-700 dark:bg-slate-900/95">
        <button
          type="button"
          onClick={() => nudgeCamera(0.6, 0)}
          title="Avancer (W / Z / ↑)"
          className="rounded border border-slate-200 bg-slate-50 p-1.5 text-slate-700 hover:bg-slate-100 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-200"
        >
          <ArrowUp className="h-3.5 w-3.5" />
        </button>
        <div className="flex items-center gap-1">
          <button
            type="button"
            onClick={() => nudgeCamera(0, -0.6)}
            title="Gauche (A / Q / ←)"
            className="rounded border border-slate-200 bg-slate-50 p-1.5 text-slate-700 hover:bg-slate-100 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-200"
          >
            <ArrowLeft className="h-3.5 w-3.5" />
          </button>
          <button
            type="button"
            onClick={() => nudgeCamera(-0.6, 0)}
            title="Reculer (S / ↓)"
            className="rounded border border-slate-200 bg-slate-50 p-1.5 text-slate-700 hover:bg-slate-100 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-200"
          >
            <ArrowDown className="h-3.5 w-3.5" />
          </button>
          <button
            type="button"
            onClick={() => nudgeCamera(0, 0.6)}
            title="Droite (D / →)"
            className="rounded border border-slate-200 bg-slate-50 p-1.5 text-slate-700 hover:bg-slate-100 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-200"
          >
            <ArrowRight className="h-3.5 w-3.5" />
          </button>
        </div>
        {enteredRoomId !== null && (
          <button
            type="button"
            onClick={() => setCameraPreset('iso')}
            className="mt-0.5 inline-flex w-full items-center justify-center gap-1 rounded bg-slate-900 px-1.5 py-1 text-[10px] font-medium text-white dark:bg-slate-100 dark:text-slate-950"
          >
            <LogOut className="h-3 w-3" />
            <span>Sortir</span>
          </button>
        )}
      </div>

      {/* SELECTED ITEM FLOATING BAR (Lock/Unlock, Move, Snap Accrocheurs, Rotate, Height, Delete) */}
      {selectedItem && selectedItem.type !== 'camera' && !monitorOpen && (
        <div
          className={`absolute z-20 w-[285px] rounded-xl border bg-white/95 p-3 shadow-md dark:bg-slate-900/95 ${
            selectedItem.locked
              ? 'border-amber-400 dark:border-amber-600'
              : 'border-sky-300 dark:border-sky-700'
          } ${roomStudioOpen ? 'top-16 left-3' : 'bottom-20 right-3'}`}
        >
          <div className="flex items-start justify-between gap-2">
            <div className="min-w-0">
              <div className="flex items-center gap-1.5 text-xs font-semibold text-slate-950 dark:text-white">
                {selectedItem.locked ? (
                  <Lock className="h-3.5 w-3.5 shrink-0 text-amber-600 dark:text-amber-400" />
                ) : (
                  <Anchor className="h-3.5 w-3.5 shrink-0 text-sky-600 dark:text-sky-400" />
                )}
                <span className="truncate">
                  {TYPES[selectedItem.type].label}
                  {selectedItem.name ? ` (${selectedItem.name})` : ''}
                </span>
              </div>
              <div className="mt-0.5 font-mono text-[10px] text-slate-500 dark:text-slate-400">
                {selectedItemSurfaceLabel}
                {selectedItem.locked ? ' · Verrouillé' : ''}
              </div>
            </div>
            <button
              type="button"
              onClick={() => {
                setSelectedItemId(null);
                setAnchorsVisible(false);
                setMoveMode(false);
                setSnapHint(null);
              }}
              aria-label="Terminer le placement"
              className="rounded p-0.5 text-slate-400 hover:bg-slate-100 hover:text-slate-700 dark:hover:bg-slate-800"
            >
              <X className="h-4 w-4" />
            </button>
          </div>

          <button
            type="button"
            onClick={() => {
              const nextLocked = !selectedItem.locked;
              updateSelectedItem({ locked: nextLocked }, true);
              if (nextLocked) {
                setAnchorsVisible(false);
                setMoveMode(false);
                setSnapHint(null);
                setInspectedLabel(
                  `${TYPES[selectedItem.type].label} verrouillé (navigation libre protégée)`
                );
              } else {
                setInspectedLabel(
                  `${TYPES[selectedItem.type].label} déverrouillé · Glissez ou utilisez les accrocheurs`
                );
              }
            }}
            className={`mt-2.5 inline-flex w-full items-center justify-center gap-1.5 rounded-md border px-2.5 py-1.5 text-[11px] font-semibold ${
              selectedItem.locked
                ? 'border-amber-500 bg-amber-500 text-white hover:bg-amber-600'
                : 'border-slate-200 bg-slate-50 text-slate-800 hover:bg-slate-100 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-100'
            }`}
          >
            {selectedItem.locked ? (
              <>
                <Unlock className="h-3.5 w-3.5" />
                <span>Déverrouiller pour déplacer</span>
              </>
            ) : (
              <>
                <Lock className="h-3.5 w-3.5" />
                <span>Verrouiller la position</span>
              </>
            )}
          </button>

          {selectedItem.locked ? (
            <p className="mt-2 rounded-md bg-amber-50 px-2.5 py-1.5 text-[10px] leading-snug text-amber-900 dark:bg-amber-950/60 dark:text-amber-200">
              Position verrouillée : vous pouvez pivoter et naviguer dans la pièce librement sans risque de le déplacer.
            </p>
          ) : (
            <>
              <div className="mt-2 grid grid-cols-2 gap-1.5">
                <button
                  type="button"
                  onClick={() => {
                    setAnchorsVisible((p) => !p);
                    setMoveMode(true);
                  }}
                  className={`inline-flex items-center justify-center gap-1.5 rounded-md border px-2 py-1.5 text-[11px] font-semibold ${
                    anchorsVisible
                      ? 'border-sky-600 bg-sky-600 text-white'
                      : 'border-slate-200 bg-slate-50 text-slate-800 hover:bg-slate-100 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-100'
                  }`}
                >
                  <Anchor className="h-3.5 w-3.5" />
                  <span>Accrocheurs</span>
                </button>

                <button
                  type="button"
                  onClick={() => updateSelectedItem({ rot: ((selectedItem.rot || 0) + 90) % 360 }, true)}
                  className="inline-flex items-center justify-center gap-1.5 rounded-md border border-slate-200 bg-slate-50 px-2 py-1.5 text-[11px] font-semibold text-slate-800 hover:bg-slate-100 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-100"
                >
                  <RotateCw className="h-3.5 w-3.5" />
                  <span>Pivoter 90°</span>
                </button>
              </div>

              {(selectedItem.side !== null || selectedItem.mountSurface === 'wall' || selectedItem.type === 'tv') && (
                <div className="mt-2 flex items-center justify-between gap-2 rounded-lg border border-slate-200 bg-slate-50 px-2.5 py-1.5 text-[11px] dark:border-slate-700 dark:bg-slate-950/60">
                  <span className="text-slate-600 dark:text-slate-300">Hauteur murale</span>
                  <div className="flex items-center gap-1.5">
                    <button
                      type="button"
                      onClick={() => {
                        const cur = resolveItemElevationCm(selectedItem, project.items);
                        updateSelectedItem({ elevationCm: Math.max(15, cur - 15) }, true);
                      }}
                      className="rounded border border-slate-300 bg-white px-1.5 py-0.5 font-mono font-semibold text-slate-800 hover:bg-slate-100 dark:border-slate-600 dark:bg-slate-800 dark:text-white"
                    >
                      −
                    </button>
                    <span className="w-12 text-center font-mono font-semibold text-slate-900 dark:text-white">
                      {resolveItemElevationCm(selectedItem, project.items)} cm
                    </span>
                    <button
                      type="button"
                      onClick={() => {
                        const cur = resolveItemElevationCm(selectedItem, project.items);
                        updateSelectedItem({ elevationCm: Math.min(230, cur + 15) }, true);
                      }}
                      className="rounded border border-slate-300 bg-white px-1.5 py-0.5 font-mono font-semibold text-slate-800 hover:bg-slate-100 dark:border-slate-600 dark:bg-slate-800 dark:text-white"
                    >
                      +
                    </button>
                  </div>
                </div>
              )}

              <div className="mt-2 flex items-center justify-between gap-2">
                <button
                  type="button"
                  onClick={() => {
                    updateSelectedItem({ locked: true }, true);
                    setAnchorsVisible(false);
                    setMoveMode(false);
                    setSnapHint(null);
                    setSelectedItemId(null);
                  }}
                  className="inline-flex flex-1 items-center justify-center gap-1 rounded-md bg-emerald-600 px-2.5 py-1.5 text-[11px] font-semibold text-white hover:bg-emerald-700"
                >
                  <Check className="h-3.5 w-3.5" />
                  <span>Valider & Verrouiller</span>
                </button>
                <button
                  type="button"
                  onClick={deleteSelectedItem}
                  title="Supprimer cet élément"
                  className="inline-flex items-center justify-center gap-1 rounded-md border border-red-200 bg-red-50 px-2 py-1.5 text-[11px] font-semibold text-red-700 hover:bg-red-100 dark:border-red-900/60 dark:bg-red-950/50 dark:text-red-300"
                >
                  <Trash2 className="h-3.5 w-3.5" />
                </button>
              </div>
            </>
          )}

          {selectedItem.type === 'nvr_screen' && (
            <button
              type="button"
              onClick={() => {
                setMonitorOpen(true);
                setMonitorTick((t) => t + 1);
              }}
              className="mt-2 inline-flex w-full items-center justify-center gap-1.5 rounded-md bg-slate-900 px-2.5 py-1.5 text-[11px] font-semibold text-white hover:bg-slate-800 dark:bg-sky-600"
            >
              <Monitor className="h-3.5 w-3.5" />
              <span>Ouvrir le moniteur caméras</span>
            </button>
          )}
        </div>
      )}

      {/* RIGHT STUDIO DRAWER: Only shown when explicitly opened; closing X does NOT exit the room */}
      {activeRoom && roomStudioOpen && (
        <aside className="absolute top-3 right-3 z-20 w-[305px] max-h-[calc(100%-88px)] overflow-y-auto rounded-xl border border-slate-200 bg-white/95 p-3 shadow-md dark:border-slate-700 dark:bg-slate-900/95">
          <div className="flex items-start justify-between gap-2">
            <div className="min-w-0">
              <div className="font-display text-sm font-semibold text-slate-950 dark:text-white">
                Atelier : {activeRoom.name}
              </div>
              <div className="font-mono text-[11px] text-slate-500 dark:text-slate-400">
                {frNum((activeRoom.w * activeRoom.h) / 10000, 1)} m² ·{' '}
                {enteredRoomId === activeRoom.id ? 'Caméra à l’intérieur' : 'Pièce sélectionnée'}
              </div>
            </div>
            <button
              type="button"
              onClick={() => setRoomStudioOpen(false)}
              title="Masquer l’atelier (rester dans la pièce)"
              aria-label="Masquer l’atelier pièce"
              className="rounded p-1 text-slate-500 hover:bg-slate-100 hover:text-slate-800 dark:hover:bg-slate-800"
            >
              <X className="h-4 w-4" />
            </button>
          </div>

          <div className="mt-2.5 flex gap-2">
            {enteredRoomId === activeRoom.id ? (
              <button
                type="button"
                onClick={() => setCameraPreset('iso')}
                className="inline-flex flex-1 items-center justify-center gap-1.5 rounded-lg border border-slate-200 bg-slate-50 px-2.5 py-1.5 text-xs font-medium text-slate-800 hover:bg-slate-100 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-100"
              >
                <LogOut className="h-3.5 w-3.5" />
                <span>Sortir de la pièce</span>
              </button>
            ) : (
              <button
                type="button"
                onClick={() => enterRoomIn3D(activeRoom)}
                className="inline-flex flex-1 items-center justify-center gap-1.5 rounded-lg bg-slate-900 px-2.5 py-1.5 text-xs font-medium text-white hover:bg-slate-800 dark:bg-slate-100 dark:text-slate-950"
              >
                <DoorOpen className="h-3.5 w-3.5" />
                <span>Entrer à l’intérieur</span>
              </button>
            )}
            <button
              type="button"
              onClick={() =>
                setDisabledRoomLights((prev) => {
                  const next = new Set(prev);
                  if (next.has(activeRoom.id)) next.delete(activeRoom.id);
                  else next.add(activeRoom.id);
                  return next;
                })
              }
              className={`inline-flex items-center gap-1 rounded-lg border px-2.5 py-1.5 text-xs font-medium ${
                lightsOn && !disabledRoomLights.has(activeRoom.id)
                  ? 'border-amber-300 bg-amber-50 text-amber-900 dark:border-amber-700 dark:bg-amber-950/60 dark:text-amber-200'
                  : 'border-slate-200 bg-slate-50 text-slate-600 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-300'
              }`}
              title="Tester l’interrupteur de la pièce"
            >
              <Lightbulb className="h-3.5 w-3.5" />
              <span>{lightsOn && !disabledRoomLights.has(activeRoom.id) ? 'ON' : 'OFF'}</span>
            </button>
          </div>

          {/* 4 Studio Tabs: Habillage / Circuits / + Mobilier / + Élec. */}
          <div className="mt-3 grid grid-cols-4 gap-1 rounded-lg bg-slate-100 p-1 text-[10px] font-semibold dark:bg-slate-800">
            <button
              type="button"
              onClick={() => setStudioTab('habillage')}
              className={`rounded-md py-1 ${
                studioTab === 'habillage'
                  ? 'bg-white text-slate-950 shadow-sm dark:bg-slate-900 dark:text-white'
                  : 'text-slate-600 dark:text-slate-300'
              }`}
            >
              Habillage
            </button>
            <button
              type="button"
              onClick={() => setStudioTab('circuits')}
              className={`rounded-md py-1 ${
                studioTab === 'circuits'
                  ? 'bg-white text-slate-950 shadow-sm dark:bg-slate-900 dark:text-white'
                  : 'text-slate-600 dark:text-slate-300'
              }`}
            >
              Circuits
            </button>
            <button
              type="button"
              onClick={() => setStudioTab('furn')}
              className={`rounded-md py-1 ${
                studioTab === 'furn'
                  ? 'bg-white text-slate-950 shadow-sm dark:bg-slate-900 dark:text-white'
                  : 'text-slate-600 dark:text-slate-300'
              }`}
            >
              + Mobilier
            </button>
            <button
              type="button"
              onClick={() => setStudioTab('elec')}
              className={`rounded-md py-1 ${
                studioTab === 'elec'
                  ? 'bg-white text-slate-950 shadow-sm dark:bg-slate-900 dark:text-white'
                  : 'text-slate-600 dark:text-slate-300'
              }`}
            >
              + Élec.
            </button>
          </div>

          {studioTab === 'habillage' && (
            <div className="mt-2.5 space-y-3">
              <div>
                <div className="mb-1.5 text-[11px] font-semibold text-slate-600 dark:text-slate-300">
                  Murs (Peinture & Carrelage)
                </div>
                <div className="grid grid-cols-3 gap-1.5">
                  {WALL_FINISHES.map((wf) => {
                    const active = (activeRoom.wallFinish ?? 'peinture_blanche') === wf.id;
                    return (
                      <button
                        key={wf.id}
                        type="button"
                        onClick={() => updateRoomFinish({ wallFinish: wf.id })}
                        title={wf.label}
                        className={`flex flex-col items-center gap-1 rounded-md border p-1.5 text-[10px] font-medium ${
                          active
                            ? 'border-blue-600 bg-blue-50 text-blue-900 dark:border-sky-400 dark:bg-sky-950/60 dark:text-sky-200'
                            : 'border-slate-200 bg-white text-slate-700 hover:bg-slate-50 dark:border-slate-700 dark:bg-slate-950 dark:text-slate-300'
                        }`}
                      >
                        <span
                          className="h-5 w-full rounded border border-slate-300 dark:border-slate-600"
                          style={{
                            backgroundColor: wf.hex,
                            backgroundImage: wf.groutHex
                              ? `linear-gradient(to right, ${wf.groutHex} 1px, transparent 1px), linear-gradient(to bottom, ${wf.groutHex} 1px, transparent 1px)`
                              : undefined,
                            backgroundSize: wf.groutHex ? '7px 7px' : undefined,
                          }}
                        />
                        <span className="w-full truncate text-center">
                          {wf.label.replace(/^(Peinture|Carrelage|Parement)\s+/i, '')}
                        </span>
                      </button>
                    );
                  })}
                </div>
              </div>

              <div>
                <div className="mb-1.5 text-[11px] font-semibold text-slate-600 dark:text-slate-300">
                  Revêtement de sol
                </div>
                <div className="grid grid-cols-2 gap-1.5">
                  {FLOOR_FINISHES.map((ff) => {
                    const active = (activeRoom.floorFinish ?? 'auto') === ff.id;
                    return (
                      <button
                        key={ff.id}
                        type="button"
                        onClick={() => updateRoomFinish({ floorFinish: ff.id })}
                        className={`flex items-center gap-1.5 rounded-md border px-2 py-1.5 text-left text-[10px] font-medium ${
                          active
                            ? 'border-blue-600 bg-blue-50 text-blue-900 dark:border-sky-400 dark:bg-sky-950/60 dark:text-sky-200'
                            : 'border-slate-200 bg-white text-slate-700 hover:bg-slate-50 dark:border-slate-700 dark:bg-slate-950 dark:text-slate-300'
                        }`}
                      >
                        <span
                          className="h-3.5 w-3.5 shrink-0 rounded-sm border border-slate-300"
                          style={{ backgroundColor: ff.hex }}
                        />
                        <span className="truncate">{ff.label.replace(/\s*\(.*\)/, '')}</span>
                      </button>
                    );
                  })}
                </div>
              </div>
            </div>
          )}

          {studioTab === 'circuits' && (
            <div className="mt-2.5 space-y-1.5">
              {roomCircuits.length === 0 ? (
                <p className="text-[11px] text-slate-500 dark:text-slate-400">
                  Aucun circuit raccordé dans cette pièce. Ajoutez un éclairage, une clim ou une prise.
                </p>
              ) : (
                roomCircuits.map((c) => {
                  const cut = trippedCircuitIds.has(c.id);
                  return (
                    <div
                      key={c.id}
                      className="flex items-center justify-between gap-2 rounded-lg border border-slate-200 px-2.5 py-1.5 text-xs dark:border-slate-700"
                    >
                      <div className="min-w-0">
                        <div className="flex items-center gap-1.5">
                          <span
                            className="h-2.5 w-2.5 shrink-0 rounded-full"
                            style={{ backgroundColor: c.color }}
                          />
                          <span className="truncate font-medium text-slate-900 dark:text-white">
                            {c.name}
                          </span>
                        </div>
                        <div className="font-mono text-[10px] text-slate-500 dark:text-slate-400">
                          C{c.breakerA} · {frNum(c.watts)} W
                        </div>
                      </div>
                      <button
                        type="button"
                        onClick={() => onToggleCircuitTrip(c.id)}
                        className={`inline-flex items-center gap-1 rounded px-2 py-1 text-[10px] font-semibold ${
                          cut
                            ? 'bg-red-100 text-red-700 dark:bg-red-950 dark:text-red-300'
                            : 'bg-emerald-100 text-emerald-700 dark:bg-emerald-950 dark:text-emerald-300'
                        }`}
                      >
                        {cut ? <Power className="h-3 w-3" /> : <Zap className="h-3 w-3" />}
                        <span>{cut ? 'Coupé' : 'Actif'}</span>
                      </button>
                    </div>
                  );
                })
              )}
            </div>
          )}

          {(studioTab === 'furn' || studioTab === 'elec') && (
            <div className="mt-2.5 space-y-2">
              <p className="rounded-md bg-sky-50 px-2 py-1.5 text-[10px] text-sky-900 dark:bg-sky-950/60 dark:text-sky-200">
                Après ajout, les <strong>accrocheurs</strong> (murs, tables, bureaux, sol) s’affichent automatiquement pour fixer l’élément où vous voulez.
              </p>
              <div className="grid grid-cols-2 gap-1.5">
                {QUICK_ADD_ITEMS.filter((q) => q.group === studioTab).map((q) => (
                  <button
                    key={q.type}
                    type="button"
                    onClick={() => handleAddToActiveRoom(q.type)}
                    className="inline-flex items-center gap-1 rounded-md border border-slate-200 bg-slate-50 px-2 py-1.5 text-left text-[11px] font-medium text-slate-800 hover:border-blue-400 hover:bg-blue-50 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-200 dark:hover:bg-slate-700"
                  >
                    <Plus className="h-3 w-3 shrink-0 text-blue-600 dark:text-sky-400" />
                    <span className="truncate">{q.label}</span>
                  </button>
                ))}
              </div>
            </div>
          )}
        </aside>
      )}

      {/* LIVE CAMERA MONITOR / NVR FEED PANEL (Shows real 3D camera POVs!) */}
      {monitorOpen && (
        <div className="absolute bottom-20 right-3 z-30 w-[340px] sm:w-[440px] max-h-[calc(100%-100px)] overflow-y-auto rounded-xl border border-slate-700 bg-slate-950/95 p-3 text-slate-100 shadow-lg">
          <div className="flex items-center justify-between gap-2 border-b border-slate-800 pb-2">
            <div className="flex items-center gap-2 text-xs font-semibold">
              <Monitor className="h-4 w-4 text-sky-400" />
              <span>Moniteur Vidéosurveillance NVR (Vue Caméras)</span>
            </div>
            <div className="flex items-center gap-1.5">
              <button
                type="button"
                onClick={() => setMonitorTick((t) => t + 1)}
                title="Rafraîchir les flux vidéo"
                className="rounded p-1 text-slate-300 hover:bg-slate-800 hover:text-white"
              >
                <RefreshCw className="h-3.5 w-3.5" />
              </button>
              <button
                type="button"
                onClick={() => setMonitorOpen(false)}
                aria-label="Fermer le moniteur caméras"
                className="rounded p-1 text-slate-400 hover:bg-slate-800 hover:text-white"
              >
                <X className="h-4 w-4" />
              </button>
            </div>
          </div>

          {allCameras.length === 0 ? (
            <p className="py-6 text-center text-xs text-slate-400">
              Aucune caméra installée. Ajoutez une Caméra IP sur le plan ou dans une pièce.
            </p>
          ) : (
            <>
              <div className="mt-2 flex flex-wrap items-center gap-1.5">
                <button
                  type="button"
                  onClick={() => setMonitorCamId('all')}
                  className={`rounded px-2 py-1 text-[11px] font-medium ${
                    monitorCamId === 'all'
                      ? 'bg-sky-600 text-white'
                      : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
                  }`}
                >
                  Toutes ({allCameras.length})
                </button>
                {allCameras.map((cam, idx) => (
                  <button
                    key={cam.id}
                    type="button"
                    onClick={() => {
                      setMonitorCamId(cam.id);
                      setSelectedCameraId(cam.id);
                    }}
                    className={`rounded px-2 py-1 text-[11px] font-medium ${
                      monitorCamId === cam.id
                        ? 'bg-teal-600 text-white'
                        : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
                    }`}
                  >
                    {cam.name || `Cam ${idx + 1}`}
                  </button>
                ))}
              </div>

              <div
                className={`mt-2.5 grid gap-2 ${
                  monitorCamId === 'all' && allCameras.length > 1
                    ? 'grid-cols-1 sm:grid-cols-2'
                    : 'grid-cols-1'
                }`}
              >
                {allCameras
                  .filter((c) => monitorCamId === 'all' || c.id === monitorCamId)
                  .map((cam, idx) => {
                    const isExt = cam.camPlacement === 'exterior';
                    return (
                      <div
                        key={cam.id}
                        className="relative overflow-hidden rounded-lg border border-slate-800 bg-black"
                      >
                        <canvas
                          width={POV_W}
                          height={POV_H}
                          ref={(el) => {
                            if (el) monitorCanvasRefs.current.set(cam.id, el);
                            else monitorCanvasRefs.current.delete(cam.id);
                          }}
                          className="aspect-[16/10] w-full block"
                        />
                        <div className="flex items-center justify-between bg-slate-900 px-2 py-1 text-[10px] font-mono">
                          <span className="truncate font-semibold text-white">
                            ● REC · {cam.name || `CAM ${idx + 1}`}
                          </span>
                          <span className={isExt ? 'text-sky-400' : 'text-teal-400'}>
                            {isExt ? 'EXT' : 'INT'} · {cam.camFov ?? 90}° ({cam.camAngle ?? 0}°)
                          </span>
                        </div>
                      </div>
                    );
                  })}
              </div>
            </>
          )}
        </div>
      )}

      {/* FLOATING CAMERA ORIENTATION CARD (When a 3D camera is clicked) */}
      {selectedCamera && (
        <div
          className={`absolute z-20 w-[265px] rounded-xl border border-teal-300 bg-white/95 p-3 shadow-md dark:border-teal-700 dark:bg-slate-900/95 ${
            roomStudioOpen || monitorOpen ? 'top-16 left-3' : 'bottom-20 right-3'
          }`}
        >
          <div className="flex items-center justify-between gap-2">
            <div className="flex items-center gap-1.5 text-xs font-semibold text-teal-800 dark:text-teal-300">
              <Camera className="h-3.5 w-3.5" />
              <span className="truncate">{selectedCamera.name || 'Caméra IP'}</span>
            </div>
            <button
              type="button"
              onClick={() => {
                setSelectedCameraId(null);
                setSelectedItemId(null);
                setAnchorsVisible(false);
              }}
              className="rounded p-0.5 text-slate-400 hover:text-slate-700"
              aria-label="Fermer réglage caméra"
            >
              <X className="h-3.5 w-3.5" />
            </button>
          </div>

          <div className="mt-2 grid grid-cols-2 gap-1.5">
            <button
              type="button"
              onClick={() => updateSelectedCamera({ camPlacement: 'interior' }, true)}
              className={`rounded-md border px-2 py-1 text-[11px] font-semibold ${
                selectedCamera.camPlacement !== 'exterior'
                  ? 'border-teal-600 bg-teal-600 text-white'
                  : 'border-slate-200 bg-slate-50 text-slate-700 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-200'
              }`}
            >
              Intérieur
            </button>
            <button
              type="button"
              onClick={() => updateSelectedCamera({ camPlacement: 'exterior' }, true)}
              className={`rounded-md border px-2 py-1 text-[11px] font-semibold ${
                selectedCamera.camPlacement === 'exterior'
                  ? 'border-sky-600 bg-sky-600 text-white'
                  : 'border-slate-200 bg-slate-50 text-slate-700 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-200'
              }`}
            >
              Extérieur
            </button>
          </div>

          <div className="mt-2.5 space-y-2 text-[11px]">
            <label className="block">
              <div className="flex justify-between text-slate-600 dark:text-slate-300">
                <span>Direction</span>
                <span className="font-mono font-semibold">{selectedCamera.camAngle ?? 0}°</span>
              </div>
              <input
                type="range"
                min={-75}
                max={75}
                step={5}
                value={selectedCamera.camAngle ?? 0}
                onChange={(e) =>
                  updateSelectedCamera({ camAngle: Number(e.target.value) }, false)
                }
                className="w-full accent-teal-600"
              />
            </label>
            <label className="block">
              <div className="flex justify-between text-slate-600 dark:text-slate-300">
                <span>Champ (FOV)</span>
                <span className="font-mono font-semibold">{selectedCamera.camFov ?? 90}°</span>
              </div>
              <input
                type="range"
                min={45}
                max={140}
                step={5}
                value={selectedCamera.camFov ?? 90}
                onChange={(e) =>
                  updateSelectedCamera({ camFov: Number(e.target.value) }, false)
                }
                className="w-full accent-teal-600"
              />
            </label>
            <label className="block">
              <div className="flex justify-between text-slate-600 dark:text-slate-300">
                <span>Portée</span>
                <span className="font-mono font-semibold">
                  {frNum((selectedCamera.camRange ?? 450) / 100, 1)} m
                </span>
              </div>
              <input
                type="range"
                min={200}
                max={1000}
                step={50}
                value={selectedCamera.camRange ?? 450}
                onChange={(e) =>
                  updateSelectedCamera({ camRange: Number(e.target.value) }, false)
                }
                className="w-full accent-teal-600"
              />
            </label>
            <div className="grid grid-cols-2 gap-1.5 pt-1">
              <button
                type="button"
                disabled={Boolean(selectedCamera.locked)}
                onClick={() => {
                  setSelectedItemId(selectedCamera.id);
                  setAnchorsVisible((p) => !p);
                  setMoveMode(true);
                }}
                className={`inline-flex items-center justify-center gap-1 rounded-md border px-2 py-1.5 text-[11px] font-semibold ${
                  selectedCamera.locked
                    ? 'cursor-not-allowed border-slate-200 bg-slate-100 text-slate-400 dark:border-slate-800 dark:bg-slate-900'
                    : anchorsVisible && selectedItemId === selectedCamera.id
                    ? 'border-sky-600 bg-sky-600 text-white'
                    : 'border-slate-200 bg-slate-50 text-slate-700 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-200'
                }`}
              >
                <Anchor className="h-3.5 w-3.5" />
                <span>Accrocheurs</span>
              </button>
              <button
                type="button"
                onClick={() => {
                  setMonitorCamId(selectedCamera.id);
                  setMonitorOpen(true);
                }}
                className="inline-flex items-center justify-center gap-1 rounded-md bg-slate-900 px-2 py-1.5 text-[11px] font-semibold text-white hover:bg-slate-800 dark:bg-sky-600"
              >
                <Monitor className="h-3.5 w-3.5" />
                <span>Écran NVR</span>
              </button>
            </div>
            <button
              type="button"
              onClick={() => {
                const nextLocked = !selectedCamera.locked;
                updateSelectedCamera({ locked: nextLocked }, true);
                if (nextLocked) {
                  setAnchorsVisible(false);
                  setMoveMode(false);
                }
              }}
              className={`mt-1 inline-flex w-full items-center justify-center gap-1.5 rounded-md border px-2 py-1.5 text-[11px] font-semibold ${
                selectedCamera.locked
                  ? 'border-amber-500 bg-amber-500 text-white hover:bg-amber-600'
                  : 'border-slate-200 bg-slate-50 text-slate-700 hover:bg-slate-100 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-200'
              }`}
            >
              {selectedCamera.locked ? (
                <>
                  <Unlock className="h-3.5 w-3.5" />
                  <span>Déverrouiller caméra</span>
                </>
              ) : (
                <>
                  <Lock className="h-3.5 w-3.5" />
                  <span>Verrouiller caméra</span>
                </>
              )}
            </button>
          </div>
        </div>
      )}

      {/* Collapsible Bottom Control Dock */}
      <div
        className={`absolute bottom-3 left-1/2 z-20 -translate-x-1/2 transition-transform duration-200 ${
          dockCollapsed ? 'translate-y-[calc(100%-28px)]' : 'translate-y-0'
        }`}
      >
        <div className="flex justify-center">
          <button
            type="button"
            onClick={() => setDockCollapsed((p) => !p)}
            className="inline-flex items-center gap-1 rounded-t-lg border border-b-0 border-slate-200 bg-white px-3 py-1 text-[11px] font-medium text-slate-600 hover:text-slate-900 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-300 dark:hover:text-white"
          >
            {dockCollapsed ? (
              <>
                <ChevronUp className="h-3.5 w-3.5" />
                <span>Afficher les contrôles</span>
              </>
            ) : (
              <>
                <ChevronDown className="h-3.5 w-3.5" />
                <span>Masquer</span>
              </>
            )}
          </button>
        </div>

        <div className="flex flex-wrap items-center justify-center gap-1.5 rounded-xl border border-slate-200 bg-white px-3 py-2 shadow-sm dark:border-slate-700 dark:bg-slate-900">
          <button
            type="button"
            onClick={() => {
              const nextMove = !moveMode;
              setMoveMode(nextMove);
              if (nextMove && selectedItemId !== null) {
                setAnchorsVisible(true);
              } else if (!nextMove) {
                setAnchorsVisible(false);
                setSnapHint(null);
              }
            }}
            className={`inline-flex items-center gap-1 rounded-md border px-2.5 py-1.5 text-xs font-semibold whitespace-nowrap ${
              moveMode
                ? 'border-sky-600 bg-sky-600 text-white'
                : 'border-slate-200 text-slate-700 hover:bg-slate-50 dark:border-slate-700 dark:text-slate-200 dark:hover:bg-slate-800'
            }`}
            title="Activer le déplacement & les points d’accroche 3D sur murs, tables et bureaux"
          >
            <Move className="h-3.5 w-3.5" />
            <span>Déplacer / Accrocher</span>
          </button>

          <button
            type="button"
            onClick={() => setCameraPreset('iso')}
            className="inline-flex items-center gap-1 rounded-md border border-slate-200 px-2.5 py-1.5 text-xs font-medium text-slate-700 hover:bg-slate-50 whitespace-nowrap dark:border-slate-700 dark:text-slate-200 dark:hover:bg-slate-800"
          >
            <RotateCw className="h-3.5 w-3.5" />
            <span>Isométrique</span>
          </button>
          <button
            type="button"
            onClick={() => setCameraPreset('top')}
            className="rounded-md border border-slate-200 px-2.5 py-1.5 text-xs font-medium text-slate-700 hover:bg-slate-50 whitespace-nowrap dark:border-slate-700 dark:text-slate-200 dark:hover:bg-slate-800"
          >
            Zénith
          </button>

          {project.floors.length > 1 && (
            <button
              type="button"
              onClick={() =>
                setFloorViewMode((m) =>
                  m === 'all' ? 'exploded' : m === 'exploded' ? 'active' : 'all'
                )
              }
              className="inline-flex items-center gap-1.5 rounded-md border border-slate-200 px-2.5 py-1.5 text-xs font-medium text-slate-700 hover:bg-slate-50 whitespace-nowrap dark:border-slate-700 dark:text-slate-200 dark:hover:bg-slate-800"
            >
              <Layers className="h-3.5 w-3.5" />
              <span>
                {floorViewMode === 'all'
                  ? 'Tous niveaux'
                  : floorViewMode === 'exploded'
                  ? 'Vue éclatée'
                  : 'Niveau actif'}
              </span>
            </button>
          )}

          {hasStairs && (
            <button
              type="button"
              onClick={() => onSetStairWalkMode(stairWalkMode === 'up' ? null : 'up')}
              className={`inline-flex items-center gap-1.5 rounded-md border px-2.5 py-1.5 text-xs font-medium whitespace-nowrap ${
                stairWalkMode || activeStairStep !== null
                  ? 'border-amber-400 bg-amber-50 text-amber-900 dark:border-amber-700 dark:bg-amber-950/60 dark:text-amber-200'
                  : 'border-slate-200 text-slate-700 dark:border-slate-700 dark:text-slate-200'
              }`}
            >
              <Footprints className="h-3.5 w-3.5" />
              <span>
                {stairWalkMode ? `Marche ${activeStairStep ?? 1}` : 'Escalier LED'}
              </span>
            </button>
          )}

          <div className="h-5 w-px bg-slate-200 dark:bg-slate-700" />

          <button
            type="button"
            onClick={() => setLightsOn((p) => !p)}
            className={`inline-flex items-center gap-1 rounded-md border px-2.5 py-1.5 text-xs font-medium whitespace-nowrap ${
              lightsOn
                ? 'border-amber-300 bg-amber-50 text-amber-800 dark:border-amber-700 dark:bg-amber-950/60 dark:text-amber-300'
                : 'border-slate-200 text-slate-600 dark:border-slate-700 dark:text-slate-300'
            }`}
          >
            <Lightbulb className="h-3.5 w-3.5" />
            <span>{lightsOn ? 'Lumières ON' : 'Lumières OFF'}</span>
          </button>

          <button
            type="button"
            onClick={() => setNightMode((p) => !p)}
            className="inline-flex items-center gap-1 rounded-md border border-slate-200 px-2.5 py-1.5 text-xs font-medium text-slate-700 hover:bg-slate-50 whitespace-nowrap dark:border-slate-700 dark:text-slate-200 dark:hover:bg-slate-800"
          >
            {nightMode ? <Sun className="h-3.5 w-3.5" /> : <Moon className="h-3.5 w-3.5" />}
            <span>{nightMode ? 'Jour' : 'Nuit'}</span>
          </button>

          <button
            type="button"
            onClick={() => setShowCables3D((p) => !p)}
            className={`inline-flex items-center gap-1 rounded-md border px-2.5 py-1.5 text-xs font-medium whitespace-nowrap ${
              showCables3D
                ? 'border-blue-300 bg-blue-50 text-blue-800 dark:border-sky-700 dark:bg-sky-950/60 dark:text-sky-300'
                : 'border-slate-200 text-slate-600 dark:border-slate-700 dark:text-slate-300'
            }`}
          >
            <Cable className="h-3.5 w-3.5" />
            <span>Câbles</span>
          </button>

          <button
            type="button"
            onClick={() => setShowCameraFov3D((p) => !p)}
            className={`inline-flex items-center gap-1 rounded-md border px-2.5 py-1.5 text-xs font-medium whitespace-nowrap ${
              showCameraFov3D
                ? 'border-teal-300 bg-teal-50 text-teal-800 dark:border-teal-700 dark:bg-teal-950/60 dark:text-teal-300'
                : 'border-slate-200 text-slate-600 dark:border-slate-700 dark:text-slate-300'
            }`}
          >
            <Camera className="h-3.5 w-3.5" />
            <span>Champs cam.</span>
          </button>

          <button
            type="button"
            onClick={() => {
              setMonitorOpen((p) => !p);
              setMonitorTick((t) => t + 1);
            }}
            className={`inline-flex items-center gap-1 rounded-md border px-2.5 py-1.5 text-xs font-medium whitespace-nowrap ${
              monitorOpen
                ? 'border-sky-600 bg-sky-600 text-white'
                : 'border-slate-200 text-slate-700 hover:bg-slate-50 dark:border-slate-700 dark:text-slate-200 dark:hover:bg-slate-800'
            }`}
            title="Voir en direct ce que filment les caméras sur l’écran NVR"
          >
            <Monitor className="h-3.5 w-3.5" />
            <span>Écran Caméras</span>
          </button>

          <button
            type="button"
            onClick={() => setXrayWalls((p) => !p)}
            className={`inline-flex items-center gap-1 rounded-md border px-2.5 py-1.5 text-xs font-medium whitespace-nowrap ${
              xrayWalls
                ? 'border-slate-900 bg-slate-900 text-white dark:border-slate-100 dark:bg-slate-100 dark:text-slate-950'
                : 'border-slate-200 text-slate-700 dark:border-slate-700 dark:text-slate-200'
            }`}
            title="Voir les gaines ICTA et l’installation électrique à travers les murs"
          >
            <Eye className="h-3.5 w-3.5" />
            <span>Rayon X Murs</span>
          </button>
        </div>
      </div>
    </div>
  );
}
