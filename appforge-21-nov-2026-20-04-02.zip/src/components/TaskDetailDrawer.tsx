import { useState } from 'react';
import { X, Plus, Trash2, Check } from 'lucide-react';
import {
  Task,
  TaskCategory,
  TaskPriority,
  TaskStatus,
  TeamMember,
} from '../types/project';
import { CATEGORIES, PRIORITY_CONFIG, STATUS_CONFIG } from '../data/seedData';

interface TaskDetailDrawerProps {
  task: Task;
  members: TeamMember[];
  onClose: () => void;
  onUpdateTask: (updated: Task) => void;
  onDeleteTask: (taskId: string) => void;
}

export function TaskDetailDrawer({
  task,
  members,
  onClose,
  onUpdateTask,
  onDeleteTask,
}: TaskDetailDrawerProps) {
  const [newSubtaskTitle, setNewSubtaskTitle] = useState('');
  const [confirmDelete, setConfirmDelete] = useState(false);

  const handleFieldChange = <K extends keyof Task>(key: K, value: Task[K]) => {
    onUpdateTask({ ...task, [key]: value });
  };

  const handleAddSubtask = (e: React.FormEvent) => {
    e.preventDefault();
    const trimmed = newSubtaskTitle.trim();
    if (!trimmed) return;
    onUpdateTask({
      ...task,
      sousTaches: [
        ...task.sousTaches,
        { id: `st-${Date.now()}`, titre: trimmed, terminee: false },
      ],
    });
    setNewSubtaskTitle('');
  };

  const toggleSubtask = (subId: string) => {
    onUpdateTask({
      ...task,
      sousTaches: task.sousTaches.map((st) =>
        st.id === subId ? { ...st, terminee: !st.terminee } : st
      ),
    });
  };

  const removeSubtask = (subId: string) => {
    onUpdateTask({
      ...task,
      sousTaches: task.sousTaches.filter((st) => st.id !== subId),
    });
  };

  return (
    <div className="fixed inset-0 z-50 flex justify-end">
      <div
        className="fixed inset-0 bg-slate-950/40"
        onClick={onClose}
        aria-hidden="true"
      />

      <aside
        aria-label={`Détails de ${task.code}`}
        className="relative z-10 flex h-full w-full max-w-xl flex-col border-l border-slate-200 bg-white dark:border-slate-800 dark:bg-slate-900"
      >
        <div className="flex items-center justify-between border-b border-slate-200 px-6 py-4 dark:border-slate-800">
          <div className="font-mono text-xs font-semibold tabular-nums text-slate-500 dark:text-slate-400">
            {task.code} · {task.categorie}
          </div>
          <div className="flex items-center gap-2">
            {!confirmDelete ? (
              <button
                type="button"
                onClick={() => setConfirmDelete(true)}
                aria-label="Supprimer cette tâche"
                className="rounded-md p-1.5 text-slate-400 hover:bg-red-50 hover:text-red-600 dark:hover:bg-red-950/40 dark:hover:text-red-400"
              >
                <Trash2 className="h-4 w-4" />
              </button>
            ) : (
              <div className="flex items-center gap-1.5">
                <button
                  type="button"
                  onClick={() => onDeleteTask(task.id)}
                  className="rounded-md bg-red-600 px-2.5 py-1 text-xs font-medium text-white hover:bg-red-700 whitespace-nowrap"
                >
                  Confirmer la suppression
                </button>
                <button
                  type="button"
                  onClick={() => setConfirmDelete(false)}
                  className="rounded-md px-2 py-1 text-xs font-medium text-slate-600 hover:bg-slate-100 dark:text-slate-300 dark:hover:bg-slate-800"
                >
                  Annuler
                </button>
              </div>
            )}

            <button
              type="button"
              onClick={onClose}
              aria-label="Fermer le panneau"
              className="rounded-md p-1.5 text-slate-500 hover:bg-slate-100 hover:text-slate-900 dark:text-slate-400 dark:hover:bg-slate-800 dark:hover:text-white"
            >
              <X className="h-4 w-4" />
            </button>
          </div>
        </div>

        <div className="flex-1 space-y-6 overflow-y-auto px-6 py-5">
          <div>
            <label htmlFor="task-title" className="sr-only">
              Titre de la tâche
            </label>
            <input
              id="task-title"
              type="text"
              value={task.titre}
              onChange={(e) => handleFieldChange('titre', e.target.value)}
              className="w-full rounded-lg border border-transparent bg-transparent px-1 py-1 font-display text-lg font-semibold text-slate-950 hover:border-slate-200 focus:border-indigo-600 focus:bg-white focus:outline-none dark:text-white dark:hover:border-slate-700 dark:focus:bg-slate-950"
            />
          </div>

          <div>
            <label
              htmlFor="task-description"
              className="block text-xs font-medium text-slate-500 dark:text-slate-400"
            >
              Description et notes techniques
            </label>
            <textarea
              id="task-description"
              rows={3}
              value={task.description}
              onChange={(e) => handleFieldChange('description', e.target.value)}
              placeholder="Ajoutez les spécifications, liens ou critères d’acceptation..."
              className="mt-1.5 w-full rounded-lg border border-slate-200 bg-slate-50 px-3 py-2 text-sm text-slate-900 focus:border-indigo-600 focus:bg-white focus:outline-none dark:border-slate-700 dark:bg-slate-950 dark:text-slate-100"
            />
          </div>

          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
            <div>
              <label
                htmlFor="task-status"
                className="block text-xs font-medium text-slate-500 dark:text-slate-400"
              >
                Statut
              </label>
              <select
                id="task-status"
                value={task.statut}
                onChange={(e) =>
                  handleFieldChange('statut', e.target.value as TaskStatus)
                }
                className="mt-1 w-full rounded-lg border border-slate-200 bg-white px-3 py-2 text-sm text-slate-900 focus:border-indigo-600 focus:outline-none dark:border-slate-700 dark:bg-slate-950 dark:text-slate-100"
              >
                {(Object.keys(STATUS_CONFIG) as TaskStatus[]).map((key) => (
                  <option key={key} value={key}>
                    {STATUS_CONFIG[key].label}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label
                htmlFor="task-priority"
                className="block text-xs font-medium text-slate-500 dark:text-slate-400"
              >
                Priorité
              </label>
              <select
                id="task-priority"
                value={task.priorite}
                onChange={(e) =>
                  handleFieldChange('priorite', e.target.value as TaskPriority)
                }
                className="mt-1 w-full rounded-lg border border-slate-200 bg-white px-3 py-2 text-sm text-slate-900 focus:border-indigo-600 focus:outline-none dark:border-slate-700 dark:bg-slate-950 dark:text-slate-100"
              >
                {(Object.keys(PRIORITY_CONFIG) as TaskPriority[]).map((key) => (
                  <option key={key} value={key}>
                    {PRIORITY_CONFIG[key].label}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label
                htmlFor="task-assignee"
                className="block text-xs font-medium text-slate-500 dark:text-slate-400"
              >
                Responsable
              </label>
              <select
                id="task-assignee"
                value={task.assigneeId}
                onChange={(e) => handleFieldChange('assigneeId', e.target.value)}
                className="mt-1 w-full rounded-lg border border-slate-200 bg-white px-3 py-2 text-sm text-slate-900 focus:border-indigo-600 focus:outline-none dark:border-slate-700 dark:bg-slate-950 dark:text-slate-100"
              >
                {members.map((m) => (
                  <option key={m.id} value={m.id}>
                    {m.nom} ({m.role})
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label
                htmlFor="task-category"
                className="block text-xs font-medium text-slate-500 dark:text-slate-400"
              >
                Domaine
              </label>
              <select
                id="task-category"
                value={task.categorie}
                onChange={(e) =>
                  handleFieldChange('categorie', e.target.value as TaskCategory)
                }
                className="mt-1 w-full rounded-lg border border-slate-200 bg-white px-3 py-2 text-sm text-slate-900 focus:border-indigo-600 focus:outline-none dark:border-slate-700 dark:bg-slate-950 dark:text-slate-100"
              >
                {CATEGORIES.map((cat) => (
                  <option key={cat} value={cat}>
                    {cat}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label
                htmlFor="task-start"
                className="block text-xs font-medium text-slate-500 dark:text-slate-400"
              >
                Date de début
              </label>
              <input
                id="task-start"
                type="date"
                value={task.dateDebut}
                onChange={(e) => handleFieldChange('dateDebut', e.target.value)}
                className="mt-1 w-full rounded-lg border border-slate-200 bg-white px-3 py-2 font-mono text-sm text-slate-900 focus:border-indigo-600 focus:outline-none dark:border-slate-700 dark:bg-slate-950 dark:text-slate-100"
              />
            </div>

            <div>
              <label
                htmlFor="task-due"
                className="block text-xs font-medium text-slate-500 dark:text-slate-400"
              >
                Échéance
              </label>
              <input
                id="task-due"
                type="date"
                value={task.echeance}
                onChange={(e) => handleFieldChange('echeance', e.target.value)}
                className="mt-1 w-full rounded-lg border border-slate-200 bg-white px-3 py-2 font-mono text-sm text-slate-900 focus:border-indigo-600 focus:outline-none dark:border-slate-700 dark:bg-slate-950 dark:text-slate-100"
              />
            </div>

            <div>
              <label
                htmlFor="task-est"
                className="block text-xs font-medium text-slate-500 dark:text-slate-400"
              >
                Charge estimée (heures)
              </label>
              <input
                id="task-est"
                type="number"
                min={0}
                max={500}
                value={task.heuresEstimees}
                onChange={(e) =>
                  handleFieldChange('heuresEstimees', Math.max(0, Number(e.target.value)))
                }
                className="mt-1 w-full rounded-lg border border-slate-200 bg-white px-3 py-2 font-mono text-sm tabular-nums text-slate-900 focus:border-indigo-600 focus:outline-none dark:border-slate-700 dark:bg-slate-950 dark:text-slate-100"
              />
            </div>

            <div>
              <label
                htmlFor="task-logged"
                className="block text-xs font-medium text-slate-500 dark:text-slate-400"
              >
                Temps passé (heures)
              </label>
              <input
                id="task-logged"
                type="number"
                min={0}
                max={500}
                value={task.heuresPassees}
                onChange={(e) =>
                  handleFieldChange('heuresPassees', Math.max(0, Number(e.target.value)))
                }
                className="mt-1 w-full rounded-lg border border-slate-200 bg-white px-3 py-2 font-mono text-sm tabular-nums text-slate-900 focus:border-indigo-600 focus:outline-none dark:border-slate-700 dark:bg-slate-950 dark:text-slate-100"
              />
            </div>
          </div>

          <div className="border-t border-slate-200 pt-5 dark:border-slate-800">
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-semibold text-slate-900 dark:text-slate-100">
                Liste de contrôle
              </h3>
              <span className="font-mono text-xs tabular-nums text-slate-500 dark:text-slate-400">
                {task.sousTaches.filter((s) => s.terminee).length}/{task.sousTaches.length}
              </span>
            </div>

            <div className="mt-3 space-y-2">
              {task.sousTaches.map((st) => (
                <div
                  key={st.id}
                  className="flex items-center justify-between gap-2 rounded-lg border border-slate-200 px-3 py-2 dark:border-slate-800"
                >
                  <button
                    type="button"
                    onClick={() => toggleSubtask(st.id)}
                    className="flex min-w-0 flex-1 items-center gap-2.5 text-left"
                  >
                    <span
                      className={`flex h-4 w-4 shrink-0 items-center justify-center rounded border ${
                        st.terminee
                          ? 'border-slate-900 bg-slate-900 text-white dark:border-slate-100 dark:bg-slate-100 dark:text-slate-950'
                          : 'border-slate-300 dark:border-slate-600'
                      }`}
                    >
                      {st.terminee && <Check className="h-3 w-3" />}
                    </span>
                    <span
                      className={`truncate text-sm ${
                        st.terminee
                          ? 'text-slate-400 line-through dark:text-slate-500'
                          : 'text-slate-800 dark:text-slate-200'
                      }`}
                    >
                      {st.titre}
                    </span>
                  </button>
                  <button
                    type="button"
                    onClick={() => removeSubtask(st.id)}
                    aria-label="Retirer la sous-tâche"
                    className="rounded p-1 text-slate-400 hover:bg-slate-100 hover:text-slate-700 dark:hover:bg-slate-800 dark:hover:text-slate-200"
                  >
                    <X className="h-3.5 w-3.5" />
                  </button>
                </div>
              ))}
            </div>

            <form onSubmit={handleAddSubtask} className="mt-3 flex gap-2">
              <input
                type="text"
                value={newSubtaskTitle}
                onChange={(e) => setNewSubtaskTitle(e.target.value)}
                placeholder="Ajouter une étape..."
                className="flex-1 rounded-lg border border-slate-200 bg-white px-3 py-2 text-sm text-slate-900 focus:border-indigo-600 focus:outline-none dark:border-slate-700 dark:bg-slate-950 dark:text-slate-100"
              />
              <button
                type="submit"
                className="inline-flex items-center gap-1.5 rounded-lg bg-slate-900 px-3.5 py-2 text-sm font-medium text-white hover:bg-slate-800 whitespace-nowrap shrink-0 dark:bg-slate-100 dark:text-slate-950 dark:hover:bg-white"
              >
                <Plus className="h-4 w-4" aria-hidden="true" />
                <span>Ajouter</span>
              </button>
            </form>
          </div>
        </div>
      </aside>
    </div>
  );
}
