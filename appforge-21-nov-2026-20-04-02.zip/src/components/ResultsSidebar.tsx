import { AlertTriangle, Check, Info } from 'lucide-react';
import { PlanProjectData } from '../types/planelec';
import { TYPES } from '../data/catalog';
import { frNum, plural, SimulationOutput } from '../utils/electricalEngine';

interface ResultsSidebarProps {
  project: PlanProjectData;
  sim: SimulationOutput;
  highlightedCircuitId: string | null;
  trippedCircuitIds: Set<string>;
  onHighlightCircuit: (circuitId: string | null) => void;
  onSelectRoom: (roomId: number) => void;
}

const KIND_UNITS: Record<string, [string, string]> = {
  light: ['point lumineux', 'points lumineux'],
  spot: ['spot', 'spots'],
  neon: ['bande', 'bandes'],
  stair_led: ['marche LED', 'marches LED'],
  socket: ['socle', 'socles'],
  heat: ['radiateur', 'radiateurs'],
  hvac: ['appareil clim', 'appareils clim'],
  surveillance: ['équipement', 'équipements'],
};

export function ResultsSidebar({
  project,
  sim,
  highlightedCircuitId,
  trippedCircuitIds,
  onHighlightCircuit,
  onSelectRoom,
}: ResultsSidebarProps) {
  const { rooms, items, k } = project;
  const habArea = rooms
    .filter((r) => r.type !== 'terrasse')
    .reduce((sum, r) => sum + (r.w * r.h) / 10000, 0);

  const hasPanel = items.some((i) => i.type === 'panel');
  const daafCount = items.filter((i) => i.type === 'smoke').length;
  const totalRoomWarnings = sim.roomReports.reduce((s, r) => s + r.warnCount, 0);

  const renderBadge = (level: 'ok' | 'warn' | 'info') => {
    if (level === 'ok') {
      return (
        <span className="mt-0.5 inline-flex h-4 w-4 shrink-0 items-center justify-center rounded-full bg-emerald-600 text-white">
          <Check className="h-2.5 w-2.5" />
        </span>
      );
    }
    if (level === 'warn') {
      return (
        <span className="mt-0.5 inline-flex h-4 w-4 shrink-0 items-center justify-center rounded-full bg-amber-600 text-white">
          <AlertTriangle className="h-2.5 w-2.5" />
        </span>
      );
    }
    return (
      <span className="mt-0.5 inline-flex h-4 w-4 shrink-0 items-center justify-center rounded-full bg-slate-500 text-white">
        <Info className="h-2.5 w-2.5" />
      </span>
    );
  };

  return (
    <aside aria-label="Résultats de simulation" className="space-y-4">
      {/* Power Balance */}
      <section className="rounded-xl border border-slate-200 bg-white p-4 dark:border-slate-800 dark:bg-slate-900">
        <h2 className="font-display text-sm font-semibold text-slate-950 dark:text-white">
          Bilan de puissance
        </h2>
        <dl className="mt-3 grid grid-cols-2 gap-3">
          <div>
            <dt className="text-[11px] text-slate-500 dark:text-slate-400">
              Pièces · surface habitable
            </dt>
            <dd className="font-mono text-base font-semibold tabular-nums text-slate-950 dark:text-white">
              {rooms.length} · {frNum(habArea, 1)} m²
            </dd>
          </div>
          <div>
            <dt className="text-[11px] text-slate-500 dark:text-slate-400">
              Puissance installée
            </dt>
            <dd className="font-mono text-base font-semibold tabular-nums text-slate-950 dark:text-white">
              {frNum(sim.totalInstalledW)} W
            </dd>
          </div>
          <div>
            <dt className="text-[11px] text-slate-500 dark:text-slate-400">
              En service (× {frNum(k, 2)})
            </dt>
            <dd className="font-mono text-base font-semibold tabular-nums text-slate-950 dark:text-white">
              {frNum(sim.totalActiveW)} W
            </dd>
          </div>
          <div>
            <dt className="text-[11px] text-slate-500 dark:text-slate-400">
              Courant estimé (230 V)
            </dt>
            <dd className="font-mono text-base font-semibold tabular-nums text-slate-950 dark:text-white">
              {frNum(sim.totalCurrentA, 1)} A
            </dd>
          </div>
        </dl>

        <div
          className="mt-3 flex h-2.5 overflow-hidden rounded-full bg-slate-100 dark:bg-slate-800"
          aria-hidden="true"
        >
          {sim.totalInstalledW > 0 &&
            sim.circuits
              .filter((c) => c.watts > 0)
              .map((c) => (
                <span
                  key={c.id}
                  style={{
                    width: `${(c.watts / sim.totalInstalledW) * 100}%`,
                    backgroundColor: c.color,
                    opacity: trippedCircuitIds.has(c.id) ? 0.3 : 1,
                  }}
                  title={`${c.name} (${frNum(c.watts)} W)`}
                />
              ))}
        </div>
      </section>

      {/* Circuits List */}
      <section className="rounded-xl border border-slate-200 bg-white p-4 dark:border-slate-800 dark:bg-slate-900">
        <div className="flex items-center justify-between">
          <h2 className="font-display text-sm font-semibold text-slate-950 dark:text-white">
            Circuits ({sim.circuits.length})
          </h2>
          <span className="font-mono text-[11px] text-slate-500 dark:text-slate-400">
            Survoler pour isoler
          </span>
        </div>

        {sim.circuits.length === 0 ? (
          <p className="mt-2 text-xs text-slate-500 dark:text-slate-400">
            Posez un éclairage, une prise ou un appareil pour générer les circuits.
          </p>
        ) : (
          <ul className="mt-3 max-h-[290px] space-y-2.5 overflow-y-auto pr-1">
            {sim.circuits.map((c) => {
              const u = KIND_UNITS[c.kind];
              const countStr = u
                ? `${c.points} ${plural(c.points, u[0], u[1])} · `
                : '';
              const isHighlighted = highlightedCircuitId === c.id;
              const isTripped = trippedCircuitIds.has(c.id);

              return (
                <li
                  key={c.id}
                  onMouseEnter={() => onHighlightCircuit(c.id)}
                  onMouseLeave={() => onHighlightCircuit(null)}
                  className={`grid grid-cols-[8px_1fr] gap-2.5 rounded-lg p-1.5 transition-colors ${
                    isHighlighted ? 'bg-slate-100 dark:bg-slate-800/80' : ''
                  } ${isTripped ? 'opacity-50' : ''}`}
                >
                  <span
                    className="rounded-sm"
                    style={{ backgroundColor: c.color }}
                  />
                  <div className="min-w-0 text-xs">
                    <div className="flex items-center justify-between gap-2">
                      <strong className="truncate font-semibold text-slate-900 dark:text-slate-100">
                        {c.name}
                      </strong>
                      <span className="font-mono text-[11px] tabular-nums text-slate-500 dark:text-slate-400 shrink-0">
                        Diff. {c.diffType}
                      </span>
                    </div>
                    <div className="font-mono text-[11px] tabular-nums text-slate-600 dark:text-slate-300">
                      {countStr}
                      {frNum(c.watts)} W · {frNum(c.sectionMm2, 1)} mm² · {c.breakerA} A
                    </div>
                    <div className="font-mono text-[11px] tabular-nums text-slate-500 dark:text-slate-400">
                      {c.lengthM === null
                        ? 'Placez le tableau électrique pour estimer le câble.'
                        : `Câble ≈ ${frNum(c.lengthM)} m · chute ${frNum(c.dropPct ?? 0, 1)} %`}
                    </div>
                    {c.extras.length > 0 && (
                      <div className="text-[11px] text-slate-500 dark:text-slate-400">
                        dont :{' '}
                        {c.extras
                          .map(
                            (ex) =>
                              `${ex.item.name || TYPES[ex.item.type].short} ${frNum(ex.watts)} W`
                          )
                          .join(', ')}
                      </div>
                    )}
                    {c.warnings.map((w, idx) => (
                      <div
                        key={idx}
                        className="mt-1 font-medium text-amber-700 dark:text-amber-400"
                      >
                        {w}
                      </div>
                    ))}
                  </div>
                </li>
              );
            })}
          </ul>
        )}
      </section>

      {/* NF C 15-100 Checks */}
      <section className="rounded-xl border border-slate-200 bg-white p-4 dark:border-slate-800 dark:bg-slate-900">
        <h2 className="font-display text-sm font-semibold text-slate-950 dark:text-white">
          Contrôle NF C 15-100
        </h2>

        <ul className="mt-3 space-y-2 text-xs text-slate-700 dark:text-slate-300">
          <li className="flex items-start gap-2">
            {renderBadge(hasPanel ? 'ok' : 'warn')}
            <span>
              {hasPanel
                ? 'Tableau électrique placé : longueurs de câbles et chutes de tension calculées.'
                : 'Placez le tableau électrique sur un mur pour calculer les câbles.'}
            </span>
          </li>
          <li className="flex items-start gap-2">
            {renderBadge(daafCount > 0 ? 'ok' : 'warn')}
            <span>
              {daafCount > 0
                ? `Détecteur de fumée : ${daafCount} posé${plural(daafCount, '', 's')}.`
                : 'Détecteur de fumée (DAAF) : au moins un obligatoire par logement.'}
            </span>
          </li>
        </ul>

        <p className="mt-3 border-t border-slate-100 pt-2.5 text-xs text-slate-500 dark:border-slate-800 dark:text-slate-400">
          {totalRoomWarnings > 0
            ? `${totalRoomWarnings} point${plural(totalRoomWarnings, '', 's')} de vigilance détecté${plural(totalRoomWarnings, '', 's')} dans les pièces.`
            : 'Tous les contrôles automatiques des pièces sont conformes.'}
        </p>

        <div className="mt-2 divide-y divide-slate-100 dark:divide-slate-800">
          {sim.roomReports.map((rep) => (
            <details key={rep.room.id} className="group py-2">
              <summary className="flex cursor-pointer list-none items-center gap-2.5 text-xs">
                <span
                  className={`inline-flex h-5 w-5 shrink-0 items-center justify-center rounded-full font-mono text-[10px] font-bold text-white ${
                    rep.warnCount > 0 ? 'bg-amber-600' : 'bg-emerald-600'
                  }`}
                >
                  {rep.warnCount || '✓'}
                </span>
                <div className="min-w-0 flex-1">
                  <div className="truncate font-semibold text-slate-900 dark:text-slate-100">
                    {rep.room.name}
                  </div>
                  <div className="font-mono text-[11px] tabular-nums text-slate-500 dark:text-slate-400">
                    {rep.floorName} · {frNum(rep.areaM2, 1)} m² · {frNum(rep.powerW)} W
                  </div>
                </div>
                <button
                  type="button"
                  onClick={(e) => {
                    e.preventDefault();
                    onSelectRoom(rep.room.id);
                  }}
                  className="rounded px-1.5 py-0.5 text-[11px] text-slate-500 hover:bg-slate-100 hover:text-slate-900 dark:text-slate-400 dark:hover:bg-slate-800 dark:hover:text-white"
                >
                  Cibler
                </button>
              </summary>
              <ul className="mt-2 space-y-1.5 pl-7 text-xs text-slate-600 dark:text-slate-300">
                {rep.checks.map((c, idx) => (
                  <li key={idx} className="flex items-start gap-2">
                    {renderBadge(c.level)}
                    <span>{c.text}</span>
                  </li>
                ))}
              </ul>
            </details>
          ))}
        </div>
      </section>
    </aside>
  );
}
