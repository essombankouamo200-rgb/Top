import { useEffect, useMemo, useRef, useState } from 'react';
import {
  Clock,
  Cpu,
  Layers,
  Plus,
  Search,
  Shield,
  Sparkles,
  Trash2,
  Zap,
} from 'lucide-react';
import {
  FinishStyle,
  ItemType,
  LibraryCategory,
  LibraryComponentDef,
  ManualNode,
  ManualWire,
  WireType,
} from '../types/planelec';
import {
  ELECTRICAL_LIBRARY,
  FINISH_STYLES,
  LIBRARY_CATEGORIES,
  WIRING_TEMPLATES,
} from '../data/catalog';
import { LibraryPreviewIcon } from './LibraryPreviewIcon';

interface ManualWiringLabProps {
  finishStyle: FinishStyle;
  onChangeFinishStyle: (style: FinishStyle) => void;
  onPlaceOnPlan: (toolType: ItemType) => void;
}

const WIRE_META: Record<
  WireType,
  { label: string; color: string; dash?: string }
> = {
  phase: { label: 'Phase (L)', color: '#dc2626' },
  neutral: { label: 'Neutre (N)', color: '#2563eb' },
  earth: { label: 'Terre (PE)', color: '#16a34a', dash: '6 3' },
  command: { label: 'Commande / Retour', color: '#ea580c' },
  signal: { label: 'Signal / Bus', color: '#0891b2', dash: '4 3' },
};

const DEF_MAP = new Map<string, LibraryComponentDef>(
  ELECTRICAL_LIBRARY.map((d) => [d.typeId, d])
);

function terminalKey(nodeId: string, terminalId: string) {
  return `${nodeId}::${terminalId}`;
}

interface EvalResult {
  energizedTerminals: Set<string>;
  energizedWires: Set<string>;
  energizedNodes: Set<string>;
  activeAlarmNodes: Set<string>;
  stairActiveDirection: 'up' | 'down' | null;
}

function evaluateManualCircuit(
  nodes: ManualNode[],
  wires: ManualWire[],
  isOffPeakHour: boolean,
  activePulses: Set<string>
): EvalResult {
  const nodeMap = new Map(nodes.map((n) => [n.id, n]));
  const adj = new Map<string, { target: string; wireId: string }[]>();

  const addAdj = (a: string, b: string, wireId: string) => {
    const list = adj.get(a) ?? [];
    list.push({ target: b, wireId });
    adj.set(a, list);
  };

  for (const w of wires) {
    const a = terminalKey(w.fromNodeId, w.fromTerminalId);
    const b = terminalKey(w.toNodeId, w.toTerminalId);
    addAdj(a, b, w.id);
    addAdj(b, a, w.id);
  }

  const hasIncomingWire = (nodeId: string, termId: string) => {
    const k = terminalKey(nodeId, termId);
    return (adj.get(k)?.length ?? 0) > 0;
  };

  const energizedTerminals = new Set<string>();
  const activeAlarmNodes = new Set<string>();
  let stairActiveDirection: 'up' | 'down' | null = null;

  // Seed base grid power & time-of-day signals
  for (const n of nodes) {
    if (n.typeId === 'compteur_linky') {
      energizedTerminals.add(terminalKey(n.id, 'in_l'));
      energizedTerminals.add(terminalKey(n.id, 'in_n'));
      if (isOffPeakHour) energizedTerminals.add(terminalKey(n.id, 'c1'));
    } else if (n.typeId === 'agcp' && n.stateOn) {
      energizedTerminals.add(terminalKey(n.id, 'l_out'));
      energizedTerminals.add(terminalKey(n.id, 'n_out'));
    } else if (n.typeId === 'onduleur' && n.stateOn) {
      energizedTerminals.add(terminalKey(n.id, 'l_out'));
    } else if (n.typeId === 'terre_piquet') {
      energizedTerminals.add(terminalKey(n.id, 'pe1'));
      energizedTerminals.add(terminalKey(n.id, 'pe2'));
    } else if (n.typeId === 'compteur_horaire') {
      if (!hasIncomingWire(n.id, 'l_in')) {
        energizedTerminals.add(terminalKey(n.id, 'l_in'));
      }
      if (!hasIncomingWire(n.id, 'n_in')) {
        energizedTerminals.add(terminalKey(n.id, 'n_in'));
      }
    } else if (
      [
        'diff_a',
        'diff_ac',
        'disj_2a',
        'disj_16a',
        'disj_20a',
        'disj_32a',
        'disj_courbe_d',
      ].includes(n.typeId)
    ) {
      // Allow standalone sub-circuits to act as busbar-fed when their top inputs are left unwired
      if (!hasIncomingWire(n.id, 'l_in')) {
        energizedTerminals.add(terminalKey(n.id, 'l_in'));
      }
      if (!hasIncomingWire(n.id, 'n_in')) {
        energizedTerminals.add(terminalKey(n.id, 'n_in'));
      }
    }
  }

  // Iterative fixed-point propagation across wires & internal component logic
  let changed = true;
  let guard = 0;
  while (changed && guard < 24) {
    changed = false;
    guard++;

    // 1. Propagate along external wires
    for (const w of wires) {
      const a = terminalKey(w.fromNodeId, w.fromTerminalId);
      const b = terminalKey(w.toNodeId, w.toTerminalId);
      const aOn = energizedTerminals.has(a);
      const bOn = energizedTerminals.has(b);
      if (aOn && !bOn) {
        energizedTerminals.add(b);
        changed = true;
      } else if (bOn && !aOn) {
        energizedTerminals.add(a);
        changed = true;
      }
    }

    // 2. Propagate internal device switching / relay logic
    for (const n of nodes) {
      const has = (t: string) => energizedTerminals.has(terminalKey(n.id, t));
      const set = (t: string) => {
        const k = terminalKey(n.id, t);
        if (!energizedTerminals.has(k)) {
          energizedTerminals.add(k);
          changed = true;
        }
      };

      switch (n.typeId) {
        case 'bornier_l':
          if (has('l_in')) {
            set('l_out1');
            set('l_out2');
          }
          break;
        case 'bornier_n':
          if (has('n_in')) {
            set('n_out1');
            set('n_out2');
          }
          break;
        case 'compteur_horaire':
          if (has('l_in') && isOffPeakHour) {
            set('hc_out');
          }
          break;
        case 'horloge_prog':
          if (has('l_in') && (isOffPeakHour || n.stateOn)) {
            set('out');
          }
          break;
        case 'diff_a':
        case 'diff_ac':
        case 'disj_2a':
        case 'disj_16a':
        case 'disj_20a':
        case 'disj_32a':
        case 'disj_courbe_d':
        case 'sectionneur_clim':
          if (n.stateOn) {
            if (has('l_in')) set('l_out');
            if (has('n_in')) set('n_out');
          }
          break;
        case 'thermostat_clim':
          if (n.stateOn && (has('l_in') || !hasIncomingWire(n.id, 'l_in'))) {
            set('bus_out');
          }
          break;
        case 'clim_groupe_ext':
          if (has('l_in') && has('n_in')) {
            set('l_split');
            set('n_split');
            set('com_split');
          }
          break;
        case 'telerupteur':
          if (n.stateOn && has('l_in')) {
            set('lamp_out');
          }
          break;
        case 'minuterie':
          if (n.stateOn && has('l_in')) {
            set('out');
          }
          break;
        case 'contacteur_jn': {
          const coilActive = has('a1') || n.stateOn;
          if (coilActive && has('l_in')) set('l_out');
          if (coilActive && has('n_in')) set('n_out');
          break;
        }
        case 'ctrl_escalier': {
          const powered = has('l_in') && has('n_in');
          const pirBas = has('pir_bas');
          const pirHaut = has('pir_haut');
          if (powered && (pirBas || pirHaut)) {
            set('led_bus');
            stairActiveDirection = pirHaut && !pirBas ? 'down' : 'up';
          }
          break;
        }
        case 'delesteur':
          if (has('l_in')) set('v1');
          break;
        case 'bouton_poussoir':
          if ((activePulses.has(n.id) || n.stateOn) && has('l_in')) {
            set('ret');
          }
          break;
        case 'inter_va_et_vient':
          if (n.stateOn && has('l_in')) {
            set('ret');
          }
          break;
        case 'detecteur_mvt':
          if (n.stateOn && (has('l_in') || !hasIncomingWire(n.id, 'l_in'))) {
            set('sig_out');
          }
          break;
        case 'camera_ip':
          if (n.stateOn) set('rj');
          break;
        case 'daaf':
          if (n.stateOn) set('bus');
          break;
        case 'centrale_alarme': {
          const powered = has('l_in') || !hasIncomingWire(n.id, 'l_in');
          if (powered && n.stateOn && has('zone1')) {
            set('siren_out');
            activeAlarmNodes.add(n.id);
          }
          break;
        }
        default:
          break;
      }
    }
  }

  const energizedWires = new Set<string>();
  for (const w of wires) {
    if (
      energizedTerminals.has(terminalKey(w.fromNodeId, w.fromTerminalId)) &&
      energizedTerminals.has(terminalKey(w.toNodeId, w.toTerminalId))
    ) {
      energizedWires.add(w.id);
    }
  }

  const energizedNodes = new Set<string>();
  for (const n of nodes) {
    const def = DEF_MAP.get(n.typeId);
    if (!def) continue;
    const has = (t: string) => energizedTerminals.has(terminalKey(n.id, t));
    if (n.typeId === 'lampe_dcl') {
      if (has('cmd_in')) energizedNodes.add(n.id);
    } else if (n.typeId === 'escalier_led') {
      if (has('bus_in')) energizedNodes.add(n.id);
    } else if (
      n.typeId === 'chauffe_eau' ||
      n.typeId === 'radiateur_elec' ||
      n.typeId === 'prise_16a' ||
      n.typeId === 'prise_usb' ||
      n.typeId === 'borne_ve' ||
      n.typeId === 'clim_groupe_ext' ||
      n.typeId === 'clim_split'
    ) {
      if (has('l_in')) energizedNodes.add(n.id);
    } else if (n.typeId === 'ecran_nvr') {
      if (has('cam_in') || has('l_in')) energizedNodes.add(n.id);
    } else if (n.typeId === 'sirene') {
      if (has('cmd')) energizedNodes.add(n.id);
    } else if (def.terminals.some((t) => has(t.id))) {
      energizedNodes.add(n.id);
    }
  }

  // Keep nodeMap referenced cleanly
  void nodeMap;

  return {
    energizedTerminals,
    energizedWires,
    energizedNodes,
    activeAlarmNodes,
    stairActiveDirection,
  };
}

export function ManualWiringLab({
  finishStyle,
  onChangeFinishStyle,
  onPlaceOnPlan,
}: ManualWiringLabProps) {
  const [search, setSearch] = useState('');
  const [activeCat, setActiveCat] = useState<LibraryCategory | 'all'>('all');
  const [nodes, setNodes] = useState<ManualNode[]>(() => WIRING_TEMPLATES[0].nodes);
  const [wires, setWires] = useState<ManualWire[]>(() => WIRING_TEMPLATES[0].wires);
  const [activeTemplateId, setActiveTemplateId] = useState<string>(WIRING_TEMPLATES[0].id);

  const [activeWireType, setActiveWireType] = useState<WireType>('phase');
  const [isOffPeakHour, setIsOffPeakHour] = useState<boolean>(true);
  const [activePulses, setActivePulses] = useState<Set<string>>(() => new Set());
  const [benchStairStep, setBenchStairStep] = useState<number>(1);

  const [pendingTerm, setPendingTerm] = useState<{
    nodeId: string;
    terminalId: string;
    x: number;
    y: number;
  } | null>(null);
  const [mousePos, setMousePos] = useState<{ x: number; y: number } | null>(null);
  const [selectedWireId, setSelectedWireId] = useState<string | null>(null);
  const [selectedNodeId, setSelectedNodeId] = useState<string | null>(null);

  const svgRef = useRef<SVGSVGElement | null>(null);
  const dragNodeRef = useRef<{
    nodeId: string;
    dx: number;
    dy: number;
  } | null>(null);

  const evalRes = useMemo(
    () => evaluateManualCircuit(nodes, wires, isOffPeakHour, activePulses),
    [nodes, wires, isOffPeakHour, activePulses]
  );

  // Animate sequential stair step preview inside the bench when escalier_led is energized
  const isStairEnergized = nodes.some(
    (n) => n.typeId === 'escalier_led' && evalRes.energizedNodes.has(n.id)
  );
  useEffect(() => {
    if (!isStairEnergized) return;
    const dir = evalRes.stairActiveDirection ?? 'up';
    const id = window.setInterval(() => {
      setBenchStairStep((prev) => {
        if (dir === 'up') return prev >= 8 ? 1 : prev + 1;
        return prev <= 1 ? 8 : prev - 1;
      });
    }, 240);
    return () => window.clearInterval(id);
  }, [isStairEnergized, evalRes.stairActiveDirection]);

  const filteredLibrary = useMemo(() => {
    const q = search.trim().toLowerCase();
    return ELECTRICAL_LIBRARY.filter((d) => {
      if (activeCat !== 'all' && d.category !== activeCat) return false;
      if (!q) return true;
      return (
        d.name.toLowerCase().includes(q) ||
        d.shortName.toLowerCase().includes(q) ||
        d.spec.toLowerCase().includes(q) ||
        d.description.toLowerCase().includes(q)
      );
    });
  }, [search, activeCat]);

  const getSvgCoords = (clientX: number, clientY: number) => {
    const svg = svgRef.current;
    if (!svg) return { x: 0, y: 0 };
    const pt = svg.createSVGPoint();
    pt.x = clientX;
    pt.y = clientY;
    const ctm = svg.getScreenCTM();
    if (!ctm) return { x: 0, y: 0 };
    const tr = pt.matrixTransform(ctm.inverse());
    return { x: tr.x, y: tr.y };
  };

  const addComponentToBench = (def: LibraryComponentDef) => {
    const idx = nodes.length;
    const col = idx % 4;
    const row = Math.floor(idx / 4) % 3;
    const newNode: ManualNode = {
      id: `node-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
      typeId: def.typeId,
      label: def.shortName,
      x: 56 + col * 195,
      y: 44 + row * 145,
      stateOn: def.category === 'protection' || def.typeId === 'agcp' || def.typeId === 'onduleur' || def.typeId === 'centrale_alarme',
    };
    setNodes((prev) => [...prev, newNode]);
    setSelectedNodeId(newNode.id);
    setSelectedWireId(null);
  };

  const loadTemplate = (templateId: string) => {
    const tpl = WIRING_TEMPLATES.find((t) => t.id === templateId);
    if (!tpl) return;
    setNodes(tpl.nodes.map((n) => ({ ...n })));
    setWires(tpl.wires.map((w) => ({ ...w })));
    setActiveTemplateId(tpl.id);
    setPendingTerm(null);
    setSelectedNodeId(null);
    setSelectedWireId(null);
  };

  const handleTerminalClick = (
    e: React.MouseEvent,
    node: ManualNode,
    def: LibraryComponentDef,
    termId: string,
    wireType: WireType,
    rx: number,
    ry: number
  ) => {
    e.stopPropagation();
    const tx = node.x + rx;
    const ty = node.y + ry;

    if (!pendingTerm) {
      setActiveWireType(wireType);
      setPendingTerm({ nodeId: node.id, terminalId: termId, x: tx, y: ty });
      setMousePos({ x: tx, y: ty });
      return;
    }

    if (pendingTerm.nodeId === node.id && pendingTerm.terminalId === termId) {
      setPendingTerm(null);
      return;
    }

    const exists = wires.some(
      (w) =>
        (w.fromNodeId === pendingTerm.nodeId &&
          w.fromTerminalId === pendingTerm.terminalId &&
          w.toNodeId === node.id &&
          w.toTerminalId === termId) ||
        (w.toNodeId === pendingTerm.nodeId &&
          w.toTerminalId === pendingTerm.terminalId &&
          w.fromNodeId === node.id &&
          w.fromTerminalId === termId)
    );

    if (!exists) {
      const newWire: ManualWire = {
        id: `wire-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
        fromNodeId: pendingTerm.nodeId,
        fromTerminalId: pendingTerm.terminalId,
        toNodeId: node.id,
        toTerminalId: termId,
        wireType: activeWireType,
      };
      setWires((prev) => [...prev, newWire]);
      setSelectedWireId(newWire.id);
    }
    setPendingTerm(null);
    void def;
  };

  // Momentary pulse on bouton_poussoir toggles connected telerupteur / minuterie!
  const handleNodeInteract = (e: React.MouseEvent, node: ManualNode) => {
    e.stopPropagation();
    const def = DEF_MAP.get(node.typeId);
    if (!def) return;

    if (def.typeId === 'bouton_poussoir') {
      // Visual pulse
      setActivePulses((prev) => new Set(prev).add(node.id));
      window.setTimeout(() => {
        setActivePulses((prev) => {
          const next = new Set(prev);
          next.delete(node.id);
          return next;
        });
      }, 320);

      // Find reachable telerupteur or minuterie connected to this pushbutton's 'ret' terminal
      const visited = new Set<string>();
      const queue = [terminalKey(node.id, 'ret')];
      const targetRelayIds = new Set<string>();

      while (queue.length > 0) {
        const cur = queue.shift()!;
        if (visited.has(cur)) continue;
        visited.add(cur);
        for (const w of wires) {
          const a = terminalKey(w.fromNodeId, w.fromTerminalId);
          const b = terminalKey(w.toNodeId, w.toTerminalId);
          let nextKey: string | null = null;
          if (a === cur) nextKey = b;
          else if (b === cur) nextKey = a;
          if (nextKey) {
            const [nid, tid] = nextKey.split('::');
            const targetNode = nodes.find((x) => x.id === nid);
            if (targetNode && targetNode.typeId === 'telerupteur' && tid === 'a1') {
              targetRelayIds.add(targetNode.id);
            } else if (targetNode && targetNode.typeId === 'minuterie' && tid === 'bp') {
              targetRelayIds.add(targetNode.id);
            }
            if (!visited.has(nextKey)) queue.push(nextKey);
          }
        }
      }

      if (targetRelayIds.size > 0) {
        setNodes((prev) =>
          prev.map((n) =>
            targetRelayIds.has(n.id) ? { ...n, stateOn: !n.stateOn } : n
          )
        );
      }
      return;
    }

    if (def.interactive === 'clock') {
      setIsOffPeakHour((p) => !p);
      return;
    }

    if (def.interactive === 'toggle' || def.interactive === 'sensor') {
      setNodes((prev) =>
        prev.map((n) => (n.id === node.id ? { ...n, stateOn: !n.stateOn } : n))
      );
    }
  };

  const deleteSelection = () => {
    if (selectedWireId) {
      setWires((prev) => prev.filter((w) => w.id !== selectedWireId));
      setSelectedWireId(null);
    } else if (selectedNodeId) {
      setNodes((prev) => prev.filter((n) => n.id !== selectedNodeId));
      setWires((prev) =>
        prev.filter(
          (w) => w.fromNodeId !== selectedNodeId && w.toNodeId !== selectedNodeId
        )
      );
      setSelectedNodeId(null);
    }
  };

  const styleCfg = FINISH_STYLES[finishStyle];

  return (
    <div className="grid grid-cols-1 items-start gap-5 lg:grid-cols-[340px_minmax(0,1fr)]">
      {/* LEFT: Complete Equipment Library */}
      <aside className="rounded-xl border border-slate-200 bg-white p-4 dark:border-slate-800 dark:bg-slate-900">
        <div className="flex items-center justify-between gap-2">
          <h2 className="font-display text-sm font-semibold text-slate-950 dark:text-white">
            Bibliothèque électrique complète
          </h2>
          <span className="font-mono text-[11px] tabular-nums text-slate-500 dark:text-slate-400">
            {ELECTRICAL_LIBRARY.length} équipements
          </span>
        </div>

        {/* Search */}
        <label className="relative mt-3 block">
          <Search className="pointer-events-none absolute top-2.5 left-2.5 h-3.5 w-3.5 text-slate-400" />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Télérupteur, compteur horaire, caméra..."
            className="w-full rounded-lg border border-slate-200 bg-slate-50 py-1.5 pr-3 pl-8 text-xs text-slate-900 placeholder:text-slate-400 focus:border-blue-500 focus:outline-none dark:border-slate-700 dark:bg-slate-950 dark:text-white"
          />
        </label>

        {/* Architectural Style Switcher */}
        <div className="mt-3 rounded-lg border border-slate-100 bg-slate-50 p-2.5 dark:border-slate-800 dark:bg-slate-950/60">
          <div className="mb-1.5 flex items-center gap-1.5 text-[11px] font-medium text-slate-600 dark:text-slate-300">
            <Sparkles className="h-3 w-3" />
            <span>Style d’appareillage (Plan + 3D + Banc)</span>
          </div>
          <div className="grid grid-cols-2 gap-1.5">
            {(Object.keys(FINISH_STYLES) as FinishStyle[]).map((st) => {
              const cfg = FINISH_STYLES[st];
              const active = finishStyle === st;
              return (
                <button
                  key={st}
                  type="button"
                  onClick={() => onChangeFinishStyle(st)}
                  className={`flex items-center gap-2 rounded-md border px-2 py-1 text-left text-[11px] font-medium transition-colors ${
                    active
                      ? 'border-slate-900 bg-white text-slate-950 dark:border-white dark:bg-slate-800 dark:text-white'
                      : 'border-slate-200 bg-white/60 text-slate-600 hover:bg-white dark:border-slate-800 dark:bg-slate-900 dark:text-slate-400'
                  }`}
                >
                  <span
                    className="h-3 w-3 shrink-0 rounded-sm border border-slate-400"
                    style={{ backgroundColor: cfg.frameHex }}
                  />
                  <span className="truncate">{cfg.label.split(' ')[0]}</span>
                </button>
              );
            })}
          </div>
        </div>

        {/* Categories */}
        <div className="mt-3 flex flex-wrap gap-1">
          <button
            type="button"
            onClick={() => setActiveCat('all')}
            className={`rounded-md border px-2 py-1 text-[11px] font-medium ${
              activeCat === 'all'
                ? 'border-slate-900 bg-slate-900 text-white dark:border-slate-100 dark:bg-slate-100 dark:text-slate-950'
                : 'border-slate-200 text-slate-600 hover:bg-slate-50 dark:border-slate-800 dark:text-slate-300'
            }`}
          >
            Tout
          </button>
          {LIBRARY_CATEGORIES.map((cat) => (
            <button
              key={cat.id}
              type="button"
              onClick={() => setActiveCat(cat.id)}
              className={`rounded-md border px-2 py-1 text-[11px] font-medium ${
                activeCat === cat.id
                  ? 'border-slate-900 bg-slate-900 text-white dark:border-slate-100 dark:bg-slate-100 dark:text-slate-950'
                  : 'border-slate-200 text-slate-600 hover:bg-slate-50 dark:border-slate-800 dark:text-slate-300'
              }`}
            >
              {cat.label}
            </button>
          ))}
        </div>

        {/* Component Cards */}
        <div className="mt-3 max-h-[510px] space-y-2.5 overflow-y-auto pr-1">
          {filteredLibrary.map((def) => (
            <div
              key={def.typeId}
              className="rounded-lg border border-slate-200 bg-slate-50/70 p-2.5 dark:border-slate-800 dark:bg-slate-950/60"
            >
              <div className="flex items-start gap-2.5">
                <div className="rounded-lg border border-slate-200 bg-white p-1 dark:border-slate-800 dark:bg-slate-900">
                  <LibraryPreviewIcon typeId={def.typeId} finishStyle={finishStyle} />
                </div>
                <div className="min-w-0 flex-1">
                  <div className="text-xs font-semibold text-slate-900 dark:text-white">
                    {def.name}
                  </div>
                  <div className="font-mono text-[10px] text-slate-500 dark:text-slate-400">
                    {def.spec}
                    {def.modulesDin ? ` · ${def.modulesDin} mod.` : ''}
                  </div>
                  <p className="mt-1 text-[11px] leading-snug text-slate-600 dark:text-slate-300">
                    {def.description}
                  </p>
                </div>
              </div>
              <div className="mt-2 flex flex-wrap items-center gap-1.5 pl-[60px]">
                <button
                  type="button"
                  onClick={() => addComponentToBench(def)}
                  className="inline-flex items-center gap-1 rounded-md bg-slate-900 px-2.5 py-1 text-[11px] font-medium text-white hover:bg-slate-800 dark:bg-slate-100 dark:text-slate-950 dark:hover:bg-white"
                >
                  <Plus className="h-3 w-3" />
                  <span>Câbler sur le banc</span>
                </button>
                {def.planToolType && (
                  <button
                    type="button"
                    onClick={() => onPlaceOnPlan(def.planToolType!)}
                    className="inline-flex items-center gap-1 rounded-md border border-slate-200 bg-white px-2 py-1 text-[11px] font-medium text-slate-700 hover:bg-slate-100 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-200 dark:hover:bg-slate-800"
                  >
                    <Layers className="h-3 w-3" />
                    <span>Poser en 2D</span>
                  </button>
                )}
              </div>
            </div>
          ))}
        </div>
      </aside>

      {/* RIGHT: Interactive Manual Wiring Zone */}
      <div className="space-y-3">
        {/* Workbench Controls */}
        <div className="flex flex-wrap items-center justify-between gap-3 rounded-xl border border-slate-200 bg-white px-4 py-3 dark:border-slate-800 dark:bg-slate-900">
          <div className="flex flex-wrap items-center gap-3">
            <label className="flex items-center gap-2 text-xs font-medium text-slate-700 dark:text-slate-300">
              <span>Montage type</span>
              <select
                value={activeTemplateId}
                onChange={(e) => loadTemplate(e.target.value)}
                className="rounded-md border border-slate-200 bg-slate-50 px-2.5 py-1.5 text-xs font-medium text-slate-900 dark:border-slate-700 dark:bg-slate-950 dark:text-white"
              >
                {WIRING_TEMPLATES.map((tpl) => (
                  <option key={tpl.id} value={tpl.id}>
                    {tpl.name}
                  </option>
                ))}
              </select>
            </label>

            <button
              type="button"
              onClick={() => setIsOffPeakHour((p) => !p)}
              className={`inline-flex items-center gap-1.5 rounded-md border px-2.5 py-1.5 text-xs font-medium transition-colors ${
                isOffPeakHour
                  ? 'border-indigo-300 bg-indigo-50 text-indigo-900 dark:border-indigo-700 dark:bg-indigo-950/60 dark:text-indigo-200'
                  : 'border-amber-300 bg-amber-50 text-amber-900 dark:border-amber-700 dark:bg-amber-950/60 dark:text-amber-200'
              }`}
            >
              <Clock className="h-3.5 w-3.5" />
              <span>
                {isOffPeakHour
                  ? 'Tarif Heures Creuses (23h30)'
                  : 'Tarif Heures Pleines (14h00)'}
              </span>
            </button>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            {(selectedWireId || selectedNodeId) && (
              <button
                type="button"
                onClick={deleteSelection}
                className="inline-flex items-center gap-1 rounded-md border border-red-200 bg-red-50 px-2.5 py-1.5 text-xs font-medium text-red-700 hover:bg-red-100 dark:border-red-900/60 dark:bg-red-950/40 dark:text-red-300"
              >
                <Trash2 className="h-3.5 w-3.5" />
                <span>Supprimer sélection</span>
              </button>
            )}
            <button
              type="button"
              onClick={() => {
                setNodes([]);
                setWires([]);
                setPendingTerm(null);
                setSelectedNodeId(null);
                setSelectedWireId(null);
              }}
              className="rounded-md border border-slate-200 px-2.5 py-1.5 text-xs font-medium text-slate-600 hover:bg-slate-50 dark:border-slate-700 dark:text-slate-300 dark:hover:bg-slate-800"
            >
              Banc vierge
            </button>
          </div>
        </div>

        {/* Wire Type Selector Strip */}
        <div className="flex flex-wrap items-center justify-between gap-3 rounded-xl border border-slate-200 bg-white px-4 py-2.5 dark:border-slate-800 dark:bg-slate-900">
          <div className="flex flex-wrap items-center gap-1.5">
            <span className="mr-1 text-xs font-medium text-slate-500 dark:text-slate-400">
              Fil actif :
            </span>
            {(Object.keys(WIRE_META) as WireType[]).map((wt) => {
              const m = WIRE_META[wt];
              const active = activeWireType === wt;
              return (
                <button
                  key={wt}
                  type="button"
                  onClick={() => setActiveWireType(wt)}
                  className={`inline-flex items-center gap-1.5 rounded-md border px-2.5 py-1 text-[11px] font-medium transition-colors ${
                    active
                      ? 'border-slate-900 bg-slate-900 text-white dark:border-white dark:bg-white dark:text-slate-950'
                      : 'border-slate-200 bg-slate-50 text-slate-700 hover:bg-slate-100 dark:border-slate-800 dark:bg-slate-950 dark:text-slate-300'
                  }`}
                >
                  <span
                    className="h-2.5 w-2.5 rounded-full"
                    style={{ backgroundColor: m.color }}
                  />
                  <span>{m.label}</span>
                </button>
              );
            })}
          </div>
          <span className="text-[11px] text-slate-500 dark:text-slate-400">
            {pendingTerm
              ? 'Cliquez sur une deuxième borne pour raccorder le fil.'
              : 'Cliquez sur 2 bornes pour câbler · Glissez les modules pour réorganiser.'}
          </span>
        </div>

        {/* Interactive SVG Wiring Bench */}
        <div className="relative overflow-hidden rounded-xl border border-slate-200 bg-[var(--pe-paper)] dark:border-slate-800">
          <svg
            ref={svgRef}
            viewBox="0 0 880 480"
            className="block h-[500px] w-full select-none touch-none"
            onPointerMove={(e) => {
              const p = getSvgCoords(e.clientX, e.clientY);
              if (pendingTerm) {
                setMousePos(p);
              }
              const drag = dragNodeRef.current;
              if (drag) {
                setNodes((prev) =>
                  prev.map((n) =>
                    n.id === drag.nodeId
                      ? {
                          ...n,
                          x: Math.max(10, Math.min(720, Math.round((p.x - drag.dx) / 10) * 10)),
                          y: Math.max(10, Math.min(360, Math.round((p.y - drag.dy) / 10) * 10)),
                        }
                      : n
                  )
                );
              }
            }}
            onPointerUp={() => {
              dragNodeRef.current = null;
            }}
            onClick={() => {
              setPendingTerm(null);
              setSelectedWireId(null);
              setSelectedNodeId(null);
            }}
          >
            <defs>
              <pattern id="bench-grid" width="20" height="20" patternUnits="userSpaceOnUse">
                <path
                  d="M 20 0 L 0 0 0 20"
                  fill="none"
                  stroke="var(--pe-grid)"
                  strokeWidth="0.8"
                />
              </pattern>
            </defs>

            <rect width="880" height="480" fill="url(#bench-grid)" />

            {/* Subtle DIN Rail Guides */}
            <rect
              x="24"
              y="72"
              width="832"
              height="16"
              rx="3"
              fill="var(--pe-panel)"
              stroke="var(--pe-line)"
              strokeWidth="1"
              opacity="0.7"
            />
            <rect
              x="24"
              y="272"
              width="832"
              height="16"
              rx="3"
              fill="var(--pe-panel)"
              stroke="var(--pe-line)"
              strokeWidth="1"
              opacity="0.5"
            />

            {/* Wires */}
            {wires.map((w) => {
              const nA = nodes.find((n) => n.id === w.fromNodeId);
              const nB = nodes.find((n) => n.id === w.toNodeId);
              const dA = nA ? DEF_MAP.get(nA.typeId) : null;
              const dB = nB ? DEF_MAP.get(nB.typeId) : null;
              const tA = dA?.terminals.find((t) => t.id === w.fromTerminalId);
              const tB = dB?.terminals.find((t) => t.id === w.toTerminalId);
              if (!nA || !nB || !tA || !tB) return null;

              const x1 = nA.x + tA.rx;
              const y1 = nA.y + tA.ry;
              const x2 = nB.x + tB.rx;
              const y2 = nB.y + tB.ry;
              const dy = Math.max(36, Math.abs(y2 - y1) * 0.55);
              const c1y = tA.ry === 0 ? y1 - dy : y1 + dy;
              const c2y = tB.ry === 0 ? y2 - dy : y2 + dy;
              const pathD = `M${x1} ${y1} C${x1} ${c1y}, ${x2} ${c2y}, ${x2} ${y2}`;

              const meta = WIRE_META[w.wireType];
              const energized = evalRes.energizedWires.has(w.id);
              const isSel = selectedWireId === w.id;

              return (
                <g
                  key={w.id}
                  onClick={(e) => {
                    e.stopPropagation();
                    setSelectedWireId(w.id);
                    setSelectedNodeId(null);
                  }}
                  className="cursor-pointer"
                >
                  {/* Wide hit target */}
                  <path d={pathD} fill="none" stroke="transparent" strokeWidth="14" />
                  {energized && (
                    <path
                      d={pathD}
                      fill="none"
                      stroke={meta.color}
                      strokeWidth="7"
                      opacity="0.22"
                    />
                  )}
                  <path
                    d={pathD}
                    fill="none"
                    stroke={isSel ? '#0f172a' : meta.color}
                    strokeWidth={isSel ? 4.2 : energized ? 3.2 : 2.2}
                    strokeDasharray={meta.dash}
                    strokeLinecap="round"
                    opacity={energized ? 1 : 0.6}
                  />
                </g>
              );
            })}

            {/* Pending wire preview */}
            {pendingTerm && mousePos && (
              <line
                x1={pendingTerm.x}
                y1={pendingTerm.y}
                x2={mousePos.x}
                y2={mousePos.y}
                stroke={WIRE_META[activeWireType].color}
                strokeWidth="2.5"
                strokeDasharray="6 4"
                pointerEvents="none"
              />
            )}

            {/* Component Nodes */}
            {nodes.map((node) => {
              const def = DEF_MAP.get(node.typeId);
              if (!def) return null;
              const isSel = selectedNodeId === node.id;
              const isEnergized = evalRes.energizedNodes.has(node.id);
              const isAlarmActive =
                (node.typeId === 'centrale_alarme' && evalRes.activeAlarmNodes.has(node.id)) ||
                (node.typeId === 'sirene' && isEnergized);

              const cardBg =
                def.category === 'style'
                  ? styleCfg.frameHex
                  : 'var(--pe-panel)';
              const cardText =
                def.category === 'style' && finishStyle === 'anthracite'
                  ? '#f8fafc'
                  : 'var(--pe-ink)';

              return (
                <g
                  key={node.id}
                  transform={`translate(${node.x} ${node.y})`}
                  onPointerDown={(e) => {
                    e.stopPropagation();
                    const p = getSvgCoords(e.clientX, e.clientY);
                    dragNodeRef.current = {
                      nodeId: node.id,
                      dx: p.x - node.x,
                      dy: p.y - node.y,
                    };
                    setSelectedNodeId(node.id);
                    setSelectedWireId(null);
                  }}
                  className="cursor-grab active:cursor-grabbing"
                >
                  {/* Node Body */}
                  <rect
                    x="0"
                    y="0"
                    width={def.width}
                    height={def.height}
                    rx="8"
                    fill={cardBg}
                    stroke={
                      isAlarmActive
                        ? '#dc2626'
                        : isSel
                        ? '#2563eb'
                        : isEnergized
                        ? '#10b981'
                        : 'var(--pe-line)'
                    }
                    strokeWidth={isSel || isAlarmActive ? 2.5 : 1.6}
                  />

                  {/* Top status header bar */}
                  <rect
                    x="0"
                    y="0"
                    width={def.width}
                    height="22"
                    rx="8"
                    fill={
                      def.category === 'comptage'
                        ? '#0f172a'
                        : def.category === 'protection'
                        ? '#1e293b'
                        : def.category === 'automatisme'
                        ? '#4c1d95'
                        : def.category === 'surveillance'
                        ? '#0f766e'
                        : '#334155'
                    }
                  />
                  <rect
                    x="0"
                    y="12"
                    width={def.width}
                    height="10"
                    fill={
                      def.category === 'comptage'
                        ? '#0f172a'
                        : def.category === 'protection'
                        ? '#1e293b'
                        : def.category === 'automatisme'
                        ? '#4c1d95'
                        : def.category === 'surveillance'
                        ? '#0f766e'
                        : '#334155'
                    }
                  />
                  <text
                    x="10"
                    y="15"
                    fontSize="10"
                    fontWeight="700"
                    fill="#ffffff"
                  >
                    {node.label}
                  </text>
                  <circle
                    cx={def.width - 12}
                    cy="11"
                    r="4"
                    fill={
                      isAlarmActive
                        ? '#ef4444'
                        : isEnergized
                        ? '#22c55e'
                        : '#64748b'
                    }
                  />

                  {/* Component-specific live internals */}
                  {node.typeId === 'compteur_horaire' || node.typeId === 'horloge_prog' ? (
                    <g
                      onClick={(e) => handleNodeInteract(e, node)}
                      className="cursor-pointer"
                    >
                      <rect
                        x="14"
                        y="32"
                        width={def.width - 28}
                        height="36"
                        rx="4"
                        fill="#ecfdf5"
                        stroke="#047857"
                        strokeWidth="1"
                      />
                      <text
                        x={def.width / 2}
                        y="47"
                        textAnchor="middle"
                        fontSize="10"
                        fontFamily="JetBrains Mono, monospace"
                        fontWeight="700"
                        fill="#065f46"
                      >
                        {isOffPeakHour ? '23:30 · HC' : '14:00 · HP'}
                      </text>
                      <text
                        x={def.width / 2}
                        y="61"
                        textAnchor="middle"
                        fontSize="8.5"
                        fill="#047857"
                      >
                        {isOffPeakHour ? 'Contact HC fermé' : 'Tarif Plein'}
                      </text>
                    </g>
                  ) : node.typeId === 'escalier_led' ? (
                    <g>
                      {Array.from({ length: 8 }, (_, idx) => {
                        const stepNum = idx + 1;
                        const active =
                          isEnergized && Math.abs(stepNum - benchStairStep) <= 1;
                        return (
                          <rect
                            key={idx}
                            x={16 + idx * 14}
                            y={66 - idx * 4.5}
                            width="12"
                            height="6"
                            rx="1.5"
                            fill={active ? '#fde047' : '#cbd5e1'}
                            stroke={active ? '#ca8a04' : '#94a3b8'}
                            strokeWidth="0.8"
                          />
                        );
                      })}
                      <text
                        x={def.width / 2}
                        y="86"
                        textAnchor="middle"
                        fontSize="9"
                        fontWeight="600"
                        fill={cardText}
                      >
                        {isEnergized
                          ? `Marche ${benchStairStep}/8 allumée`
                          : 'En attente capteur'}
                      </text>
                    </g>
                  ) : node.typeId === 'lampe_dcl' ? (
                    <g>
                      {isEnergized && (
                        <circle
                          cx={def.width / 2}
                          cy="54"
                          r="24"
                          fill="#fde047"
                          opacity="0.45"
                        />
                      )}
                      <circle
                        cx={def.width / 2}
                        cy="54"
                        r="14"
                        fill={isEnergized ? '#fef08a' : '#e2e8f0'}
                        stroke="#334155"
                        strokeWidth="1.8"
                      />
                      <text
                        x={def.width / 2}
                        y="84"
                        textAnchor="middle"
                        fontSize="9"
                        fontWeight="600"
                        fill={cardText}
                      >
                        {isEnergized ? 'ALLUMÉ' : 'ÉTEINT'}
                      </text>
                    </g>
                  ) : node.typeId === 'chauffe_eau' ? (
                    <g>
                      <rect
                        x="22"
                        y="32"
                        width={def.width - 44}
                        height="40"
                        rx="6"
                        fill={isEnergized ? '#fee2e2' : '#f1f5f9'}
                        stroke={isEnergized ? '#dc2626' : '#94a3b8'}
                      />
                      <text
                        x={def.width / 2}
                        y="56"
                        textAnchor="middle"
                        fontSize="10"
                        fontWeight="700"
                        fill={isEnergized ? '#b91c1c' : '#475569'}
                      >
                        {isEnergized ? 'CHAUFFE 2000 W' : 'VEILLE'}
                      </text>
                    </g>
                  ) : node.typeId === 'sirene' ? (
                    <g>
                      <circle
                        cx={def.width / 2}
                        cy="50"
                        r="16"
                        fill={isEnergized ? '#ef4444' : '#e2e8f0'}
                      />
                      <text
                        x={def.width / 2}
                        y="80"
                        textAnchor="middle"
                        fontSize="9"
                        fontWeight="700"
                        fill={isEnergized ? '#dc2626' : cardText}
                      >
                        {isEnergized ? 'ALARME 105 dB !' : 'Veille'}
                      </text>
                    </g>
                  ) : node.typeId === 'clim_split' ? (
                    <g>
                      <rect
                        x="14"
                        y="32"
                        width={def.width - 28}
                        height="26"
                        rx="4"
                        fill={isEnergized ? '#e0f2fe' : '#f1f5f9'}
                        stroke={isEnergized ? '#0284c7' : '#94a3b8'}
                      />
                      <line
                        x1="20"
                        y1="52"
                        x2={def.width - 20}
                        y2="52"
                        stroke={isEnergized ? '#0284c7' : '#64748b'}
                        strokeWidth="2"
                      />
                      <text
                        x={def.width / 2}
                        y="47"
                        textAnchor="middle"
                        fontSize="9.5"
                        fontFamily="JetBrains Mono, monospace"
                        fontWeight="700"
                        fill={isEnergized ? '#0369a1' : '#475569'}
                      >
                        {isEnergized ? '21°C · FROID ON' : 'VEILLE'}
                      </text>
                      <text
                        x={def.width / 2}
                        y="76"
                        textAnchor="middle"
                        fontSize="8.5"
                        fill={cardText}
                      >
                        {isEnergized ? 'Turbine + Volet actifs' : 'Hors tension'}
                      </text>
                    </g>
                  ) : node.typeId === 'clim_groupe_ext' ? (
                    <g>
                      <rect
                        x="14"
                        y="30"
                        width={def.width - 28}
                        height="42"
                        rx="5"
                        fill={isEnergized ? '#ecfeff' : '#f1f5f9'}
                        stroke={isEnergized ? '#0891b2' : '#94a3b8'}
                      />
                      <circle
                        cx="42"
                        cy="51"
                        r="14"
                        fill={isEnergized ? '#bae6fd' : '#e2e8f0'}
                        stroke={isEnergized ? '#0284c7' : '#64748b'}
                      />
                      <text
                        x="98"
                        y="48"
                        textAnchor="middle"
                        fontSize="9"
                        fontWeight="700"
                        fill={isEnergized ? '#0e7490' : '#475569'}
                      >
                        {isEnergized ? 'PAC ACTIF' : 'ARRÊT'}
                      </text>
                      <text
                        x="98"
                        y="61"
                        textAnchor="middle"
                        fontSize="8"
                        fontFamily="JetBrains Mono, monospace"
                        fill="#64748b"
                      >
                        Inverter R32
                      </text>
                    </g>
                  ) : node.typeId === 'ecran_nvr' ? (
                    <g>
                      <rect
                        x="14"
                        y="30"
                        width={def.width - 28}
                        height="44"
                        rx="4"
                        fill={isEnergized ? '#0f172a' : '#1e293b'}
                        stroke={isEnergized ? '#22c55e' : '#475569'}
                        strokeWidth="1.4"
                      />
                      <line
                        x1={def.width / 2}
                        y1="30"
                        x2={def.width / 2}
                        y2="74"
                        stroke="#334155"
                        strokeWidth="1"
                      />
                      <line
                        x1="14"
                        y1="52"
                        x2={def.width - 14}
                        y2="52"
                        stroke="#334155"
                        strokeWidth="1"
                      />
                      <text
                        x={def.width / 2}
                        y="86"
                        textAnchor="middle"
                        fontSize="8.5"
                        fontWeight="700"
                        fill={isEnergized ? '#15803d' : cardText}
                      >
                        {isEnergized ? 'FLUX CAMÉRAS LIVE' : 'Moniteur éteint'}
                      </text>
                    </g>
                  ) : def.interactive ? (
                    <g
                      onClick={(e) => handleNodeInteract(e, node)}
                      className="cursor-pointer"
                    >
                      <rect
                        x="18"
                        y="36"
                        width={def.width - 36}
                        height="30"
                        rx="5"
                        fill={
                          def.interactive === 'pushbutton'
                            ? activePulses.has(node.id)
                              ? '#ea580c'
                              : '#fff7ed'
                            : node.stateOn
                            ? '#16a34a'
                            : '#dc2626'
                        }
                        stroke={
                          def.interactive === 'pushbutton'
                            ? '#ea580c'
                            : '#0f172a'
                        }
                        strokeWidth="1.2"
                      />
                      <text
                        x={def.width / 2}
                        y="55"
                        textAnchor="middle"
                        fontSize="10"
                        fontWeight="700"
                        fill={
                          def.interactive === 'pushbutton'
                            ? activePulses.has(node.id)
                              ? '#ffffff'
                              : '#c2410c'
                            : '#ffffff'
                        }
                      >
                        {def.interactive === 'pushbutton'
                          ? 'POUSSER'
                          : def.interactive === 'sensor'
                          ? node.stateOn
                            ? 'DÉTECTÉ'
                            : 'TESTER'
                          : node.stateOn
                          ? 'ON / FERMÉ'
                          : 'OFF / COUPÉ'}
                      </text>
                      <text
                        x={def.width / 2}
                        y="82"
                        textAnchor="middle"
                        fontSize="8.5"
                        fill={cardText}
                        opacity="0.78"
                      >
                        {node.typeId === 'telerupteur'
                          ? node.stateOn
                            ? 'Relais enclenché'
                            : 'Relais ouvert'
                          : def.shortName}
                      </text>
                    </g>
                  ) : (
                    <text
                      x={def.width / 2}
                      y={def.height / 2 + 12}
                      textAnchor="middle"
                      fontSize="9.5"
                      fontWeight="600"
                      fill={cardText}
                    >
                      {node.typeId === 'telerupteur'
                        ? node.stateOn
                          ? 'Contact 1-2 FERMÉ'
                          : 'Contact 1-2 OUVERT'
                        : def.spec.split('·')[0]}
                    </text>
                  )}

                  {/* Terminal Pins */}
                  {def.terminals.map((term) => {
                    const meta = WIRE_META[term.wireType];
                    const isPending =
                      pendingTerm?.nodeId === node.id &&
                      pendingTerm.terminalId === term.id;
                    const isTermHot = evalRes.energizedTerminals.has(
                      terminalKey(node.id, term.id)
                    );
                    const labelY = term.ry === 0 ? -9 : term.ry + 16;

                    return (
                      <g
                        key={term.id}
                        onClick={(e) =>
                          handleTerminalClick(
                            e,
                            node,
                            def,
                            term.id,
                            term.wireType,
                            term.rx,
                            term.ry
                          )
                        }
                        className="cursor-crosshair"
                      >
                        <circle
                          cx={term.rx}
                          cy={term.ry}
                          r={isPending ? 8 : 6}
                          fill={isTermHot ? meta.color : '#ffffff'}
                          stroke={meta.color}
                          strokeWidth="2.5"
                        />
                        <text
                          x={term.rx}
                          y={labelY}
                          textAnchor="middle"
                          fontSize="8.5"
                          fontFamily="JetBrains Mono, monospace"
                          fontWeight="600"
                          fill="var(--pe-muted)"
                        >
                          {term.label}
                        </text>
                      </g>
                    );
                  })}
                </g>
              );
            })}
          </svg>
        </div>

        {/* Live Telemetry Strip below bench */}
        <div className="grid grid-cols-1 gap-3 sm:grid-cols-3">
          <div className="flex items-center gap-2.5 rounded-xl border border-slate-200 bg-white px-3.5 py-2.5 text-xs dark:border-slate-800 dark:bg-slate-900">
            <Zap className="h-4 w-4 shrink-0 text-amber-600" />
            <div>
              <div className="font-semibold text-slate-900 dark:text-white">
                {evalRes.energizedWires.size} / {wires.length} conducteurs sous tension
              </div>
              <div className="text-[11px] text-slate-500 dark:text-slate-400">
                Cliquez sur Pousser, ON/OFF ou Heures Creuses pour tester.
              </div>
            </div>
          </div>

          <div className="flex items-center gap-2.5 rounded-xl border border-slate-200 bg-white px-3.5 py-2.5 text-xs dark:border-slate-800 dark:bg-slate-900">
            <Cpu className="h-4 w-4 shrink-0 text-violet-600" />
            <div>
              <div className="font-semibold text-slate-900 dark:text-white">
                {nodes.filter((n) => n.typeId === 'telerupteur' && n.stateOn).length > 0
                  ? 'Télérupteur actif'
                  : isStairEnergized
                  ? `Escalier actif (marche ${benchStairStep}/8)`
                  : 'Automatismes en veille'}
              </div>
              <div className="text-[11px] text-slate-500 dark:text-slate-400">
                Télérupteur, contacteur J/N, contrôleur séquentiel.
              </div>
            </div>
          </div>

          <div className="flex items-center gap-2.5 rounded-xl border border-slate-200 bg-white px-3.5 py-2.5 text-xs dark:border-slate-800 dark:bg-slate-900">
            <Shield className="h-4 w-4 shrink-0 text-emerald-600" />
            <div>
              <div className="font-semibold text-slate-900 dark:text-white">
                {evalRes.activeAlarmNodes.size > 0
                  ? 'Alerte intrusion / fumée active !'
                  : 'Supervision & sécurité nominales'}
              </div>
              <div className="text-[11px] text-slate-500 dark:text-slate-400">
                Finition active : {styleCfg.label}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
