import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import {
  Download,
  Moon,
  Redo2,
  Sun,
  Undo2,
  Upload,
  X,
} from 'lucide-react';
import {
  AppViewMode,
  FloorLevel,
  ItemType,
  PlanItem,
  PlanProjectData,
  Room,
  SelectionTarget,
} from './types/planelec';
import {
  createExampleT3Project,
  createMultiStoryHouseProject,
  createStudioProject,
  DEFAULT_UNIT_PRICES,
} from './data/catalog';
import { frNum, runElectricalSimulation } from './utils/electricalEngine';
import { Plan2DEditor } from './components/Plan2DEditor';
import { ManualWiringLab } from './components/ManualWiringLab';
import { PanelSchematicView } from './components/PanelSchematicView';
import { Building3DView } from './components/Building3DView';
import { ResultsSidebar } from './components/ResultsSidebar';
import { BudgetReportView } from './components/BudgetReportView';

const STORAGE_KEY = 'planelec.studio.v2';
const PRICES_KEY = 'planelec.prices.v1';
const THEME_KEY = 'planelec.theme.v1';

function normalizeProject(parsed: Partial<PlanProjectData>): PlanProjectData {
  const floors: FloorLevel[] =
    Array.isArray(parsed.floors) && parsed.floors.length > 0
      ? parsed.floors
      : [{ id: 0, name: 'Rez-de-chaussée', elevationIndex: 0 }];
  const defaultFloorId = floors[0].id;
  const rooms: Room[] = Array.isArray(parsed.rooms)
    ? parsed.rooms.map((r) => ({ ...r, floorId: r.floorId ?? defaultFloorId }))
    : [];
  const items: PlanItem[] = Array.isArray(parsed.items)
    ? parsed.items.map((i) => ({ ...i, floorId: i.floorId ?? defaultFloorId }))
    : [];

  return {
    floors,
    activeFloorId:
      typeof parsed.activeFloorId === 'number' &&
      floors.some((f) => f.id === parsed.activeFloorId)
        ? parsed.activeFloorId
        : defaultFloorId,
    finishStyle: parsed.finishStyle ?? 'blanc_mat',
    rooms,
    items,
    nextId:
      parsed.nextId ||
      Math.max(
        1,
        ...floors.map((f) => f.id),
        ...rooms.map((r) => r.id),
        ...items.map((i) => i.id)
      ) + 1,
    k: typeof parsed.k === 'number' ? parsed.k : 0.6,
    sockMode: parsed.sockMode === 12 ? 12 : 8,
    includeSurgeProtector:
      typeof parsed.includeSurgeProtector === 'boolean'
        ? parsed.includeSurgeProtector
        : true,
    subscriptionKva:
      parsed.subscriptionKva && [6, 9, 12, 15].includes(parsed.subscriptionKva)
        ? parsed.subscriptionKva
        : 12,
  };
}

function loadInitialProject(): PlanProjectData {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (parsed && Array.isArray(parsed.rooms) && Array.isArray(parsed.items)) {
        return normalizeProject(parsed);
      }
    }
  } catch {
    // Ignore parse errors
  }
  return createMultiStoryHouseProject();
}

function loadInitialPrices(): Record<string, number> {
  try {
    const raw = localStorage.getItem(PRICES_KEY);
    if (raw) {
      return { ...DEFAULT_UNIT_PRICES, ...JSON.parse(raw) };
    }
  } catch {
    // Ignore parse errors
  }
  return { ...DEFAULT_UNIT_PRICES };
}

function loadInitialTheme(): boolean {
  try {
    return localStorage.getItem(THEME_KEY) === 'dark';
  } catch {
    return false;
  }
}

export default function App() {
  const [project, setProject] = useState<PlanProjectData>(loadInitialProject);
  const [past, setPast] = useState<PlanProjectData[]>([]);
  const [future, setFuture] = useState<PlanProjectData[]>([]);
  const [unitPrices, setUnitPrices] = useState<Record<string, number>>(loadInitialPrices);
  const [isDark, setIsDark] = useState<boolean>(loadInitialTheme);

  const [viewMode, setViewMode] = useState<AppViewMode>('plan2d');
  const [selected, setSelected] = useState<SelectionTarget | null>(null);
  const [highlightedCircuitId, setHighlightedCircuitId] = useState<string | null>(null);
  const [trippedCircuitIds, setTrippedCircuitIds] = useState<Set<string>>(() => new Set());
  const [requestedTool, setRequestedTool] = useState<ItemType | null>(null);

  // Display layer flags
  const [showCables, setShowCables] = useState(true);
  const [showFurn, setShowFurn] = useState(true);
  const [showNames, setShowNames] = useState(true);
  const [showDimensions, setShowDimensions] = useState(true);
  const [showSafetyZones, setShowSafetyZones] = useState(true);
  const [simulateLighting, setSimulateLighting] = useState(false);

  // Sequential Luminous Staircase live state (shared across 2D & 3D)
  const [activeStairStep, setActiveStairStep] = useState<number | null>(5);
  const [stairWalkMode, setStairWalkMode] = useState<'up' | 'down' | null>(null);

  const [notice, setNotice] = useState<string | null>(null);

  const fileInputRef = useRef<HTMLInputElement>(null);
  const planSvgRef = useRef<SVGSVGElement | null>(null);
  const lastCommittedRef = useRef<PlanProjectData>(project);

  // Persist project
  useEffect(() => {
    const timer = window.setTimeout(() => {
      try {
        localStorage.setItem(STORAGE_KEY, JSON.stringify(project));
      } catch {
        // Ignore storage errors
      }
    }, 300);
    return () => window.clearTimeout(timer);
  }, [project]);

  useEffect(() => {
    try {
      localStorage.setItem(PRICES_KEY, JSON.stringify(unitPrices));
    } catch {
      // Ignore
    }
  }, [unitPrices]);

  useEffect(() => {
    const root = document.documentElement;
    if (isDark) {
      root.classList.add('dark');
      localStorage.setItem(THEME_KEY, 'dark');
    } else {
      root.classList.remove('dark');
      localStorage.setItem(THEME_KEY, 'light');
    }
  }, [isDark]);

  useEffect(() => {
    if (!notice) return;
    const t = window.setTimeout(() => setNotice(null), 3200);
    return () => window.clearTimeout(t);
  }, [notice]);

  // Progressive step-by-step staircase animation
  const maxStairSteps = useMemo(() => {
    const stairs = project.items.filter((i) => i.type === 'staircase');
    return Math.max(14, ...stairs.map((s) => s.stepCount ?? 14));
  }, [project.items]);

  useEffect(() => {
    if (!stairWalkMode) return;
    const id = window.setInterval(() => {
      setActiveStairStep((prev) => {
        if (stairWalkMode === 'up') {
          if (prev === null || prev >= maxStairSteps) return 1;
          return prev + 1;
        }
        if (prev === null || prev <= 1) return maxStairSteps;
        return prev - 1;
      });
    }, 280);
    return () => window.clearInterval(id);
  }, [stairWalkMode, maxStairSteps]);

  const commitProject = useCallback(
    (next: PlanProjectData, recordHistory = true) => {
      if (recordHistory) {
        setPast((prev) => [...prev.slice(-29), lastCommittedRef.current]);
        setFuture([]);
        lastCommittedRef.current = next;
      }
      setProject(next);
    },
    []
  );

  const undo = useCallback(() => {
    setPast((prev) => {
      if (prev.length === 0) return prev;
      const previous = prev[prev.length - 1];
      setFuture((f) => [lastCommittedRef.current, ...f.slice(0, 29)]);
      lastCommittedRef.current = previous;
      setProject(previous);
      setSelected(null);
      return prev.slice(0, -1);
    });
  }, []);

  const redo = useCallback(() => {
    setFuture((prev) => {
      if (prev.length === 0) return prev;
      const next = prev[0];
      setPast((p) => [...p.slice(-29), lastCommittedRef.current]);
      lastCommittedRef.current = next;
      setProject(next);
      setSelected(null);
      return prev.slice(1);
    });
  }, []);

  // Keyboard shortcuts
  useEffect(() => {
    const onKeyDown = (e: KeyboardEvent) => {
      const tag = (e.target as HTMLElement | null)?.tagName;
      const isInput = tag === 'INPUT' || tag === 'SELECT' || tag === 'TEXTAREA';
      if (isInput) return;

      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === 'z') {
        e.preventDefault();
        if (e.shiftKey) redo();
        else undo();
        return;
      }
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === 'y') {
        e.preventDefault();
        redo();
        return;
      }

      if ((e.key === 'Delete' || e.key === 'Backspace') && selected) {
        e.preventDefault();
        if (selected.kind === 'item') {
          commitProject(
            {
              ...project,
              items: project.items.filter((i) => i.id !== selected.id),
            },
            true
          );
        } else {
          commitProject(
            {
              ...project,
              rooms: project.rooms.filter((r) => r.id !== selected.id),
              items: project.items.filter((i) => i.roomId !== selected.id),
            },
            true
          );
        }
        setSelected(null);
      } else if (e.key === 'Escape') {
        setSelected(null);
      }
    };
    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, [selected, project, commitProject, undo, redo]);

  const { sim, materials } = useMemo(
    () => runElectricalSimulation(project, unitPrices),
    [project, unitPrices]
  );

  const toggleCircuitTrip = (circuitId: string) => {
    setTrippedCircuitIds((prev) => {
      const next = new Set(prev);
      if (next.has(circuitId)) next.delete(circuitId);
      else next.add(circuitId);
      return next;
    });
  };

  const applyTemplate = (templateId: string) => {
    if (!templateId) return;
    let next: PlanProjectData;
    if (templateId === 'multistory') next = createMultiStoryHouseProject();
    else if (templateId === 't3') next = createExampleT3Project();
    else if (templateId === 'studio') next = createStudioProject();
    else {
      next = {
        floors: [{ id: 0, name: 'Rez-de-chaussée', elevationIndex: 0 }],
        activeFloorId: 0,
        finishStyle: 'blanc_mat',
        rooms: [],
        items: [],
        nextId: 1,
        k: 0.6,
        sockMode: 8,
        includeSurgeProtector: true,
        subscriptionKva: 9,
      };
    }
    commitProject(next, true);
    setSelected(null);
    setTrippedCircuitIds(new Set());
    setNotice(
      templateId === 'empty'
        ? 'Nouveau plan vierge créé.'
        : 'Modèle de bâtiment chargé.'
    );
  };

  const downloadFile = (filename: string, mime: string, content: string) => {
    const blob = new Blob([content], { type: mime });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    a.click();
    URL.revokeObjectURL(url);
  };

  const handleExportJson = () => {
    const payload = {
      v: 4,
      ...project,
    };
    downloadFile(
      'plan-electrique.json',
      'application/json',
      JSON.stringify(payload, null, 2)
    );
    setNotice('Projet enregistré au format JSON.');
  };

  const handleImportJson = async (file: File) => {
    try {
      const text = await file.text();
      const parsed = JSON.parse(text);
      if (!parsed || !Array.isArray(parsed.rooms) || !Array.isArray(parsed.items)) {
        setNotice('Fichier JSON non reconnu.');
        return;
      }
      const next = normalizeProject(parsed);
      commitProject(next, true);
      setSelected(null);
      setNotice('Projet importé avec succès.');
    } catch {
      setNotice('Impossible de lire ce fichier JSON.');
    }
  };

  const handleExportCsv = () => {
    const rows = materials.map(
      (m) =>
        `${m.category};${m.label};${m.quantity} ${m.unit};${frNum(m.unitPriceEur, 2)};${frNum(m.totalEur, 2)}`
    );
    const csv =
      '\uFEFFLot;Désignation;Quantité;Prix Unitaire HT (€);Total HT (€)\n' +
      rows.join('\n');
    downloadFile('liste-materiel-devis.csv', 'text/csv;charset=utf-8', csv);
    setNotice('Liste de matériel CSV exportée.');
  };

  const handleExportPlanSvg = () => {
    const svgEl = planSvgRef.current;
    if (!svgEl) {
      setNotice('Passez sur la vue Plan 2D pour exporter le SVG.');
      return;
    }
    const clone = svgEl.cloneNode(true) as SVGSVGElement;
    clone.setAttribute('xmlns', 'http://www.w3.org/2000/svg');
    const cs = getComputedStyle(document.documentElement);
    let str = new XMLSerializer().serializeToString(clone);
    str = str.replace(
      /var\((--[\w-]+)\)/g,
      (_, v) => cs.getPropertyValue(v).trim() || '#0f172a'
    );
    downloadFile('plan-electrique-2d.svg', 'image/svg+xml', str);
    setNotice('Plan 2D exporté au format SVG.');
  };

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 dark:bg-slate-950 dark:text-slate-100">
      {/* Top Bar Contract: Brand — Navigation Views — 1 Primary Action */}
      <header className="no-print sticky top-0 z-30 border-b border-slate-200 bg-white px-4 py-3 sm:px-6 dark:border-slate-800 dark:bg-slate-900">
        <div className="mx-auto flex max-w-[1440px] items-center justify-between gap-6">
          <a
            href="#top"
            onClick={(e) => {
              e.preventDefault();
              setViewMode('plan2d');
            }}
            className="font-display text-lg font-bold tracking-tight text-slate-950 whitespace-nowrap shrink-0 dark:text-white"
          >
            PlanÉlec
          </a>

          <nav aria-label="Vues principales" className="flex items-center gap-5 overflow-x-auto">
            {(
              [
                ['plan2d', 'Plan 2D'],
                ['cablage', 'Câblage & Bibliothèque'],
                ['tableau', 'Tableau & Schéma'],
                ['vue3d', 'Vue 3D'],
                ['devis', 'Matériel & Devis'],
              ] as [AppViewMode, string][]
            ).map(([mode, label]) => {
              const active = viewMode === mode;
              return (
                <button
                  key={mode}
                  type="button"
                  onClick={() => setViewMode(mode)}
                  className={`border-b-2 py-1 text-sm font-medium transition-colors whitespace-nowrap shrink-0 ${
                    active
                      ? 'border-slate-950 text-slate-950 dark:border-white dark:text-white'
                      : 'border-transparent text-slate-600 hover:text-slate-950 dark:text-slate-400 dark:hover:text-white'
                  }`}
                >
                  {label}
                </button>
              );
            })}
          </nav>

          <div className="shrink-0">
            <button
              type="button"
              onClick={handleExportJson}
              className="inline-flex items-center gap-1.5 rounded-lg bg-slate-900 px-4 py-2 text-xs font-medium text-white hover:bg-slate-800 whitespace-nowrap shrink-0 dark:bg-slate-100 dark:text-slate-950 dark:hover:bg-white"
            >
              <Download className="h-3.5 w-3.5" aria-hidden="true" />
              <span>Enregistrer</span>
            </button>
          </div>
        </div>
      </header>

      <div className="mx-auto max-w-[1440px] px-4 py-5 sm:px-6">
        {/* Engineering Settings & Project Toolbar */}
        <section
          aria-label="Paramètres du projet"
          className="no-print mb-5 flex flex-wrap items-center justify-between gap-4 rounded-xl border border-slate-200 bg-white px-4 py-3 dark:border-slate-800 dark:bg-slate-900"
        >
          <div className="flex flex-wrap items-center gap-4">
            <label className="flex items-center gap-2 text-xs font-medium text-slate-600 dark:text-slate-300">
              <span>Modèle</span>
              <select
                aria-label="Charger un modèle de bâtiment"
                value=""
                onChange={(e) => applyTemplate(e.target.value)}
                className="rounded-md border border-slate-200 bg-slate-50 px-2.5 py-1.5 text-xs font-medium text-slate-900 dark:border-slate-700 dark:bg-slate-950 dark:text-white"
              >
                <option value="" disabled>
                  Charger un modèle…
                </option>
                <option value="multistory">Maison R+1 + Escalier LED + Borne VE</option>
                <option value="t3">Appartement plain-pied + Terrasse</option>
                <option value="studio">Studio optimisé 28 m²</option>
                <option value="empty">Nouveau plan vierge</option>
              </select>
            </label>

            <label className="flex items-center gap-2 text-xs font-medium text-slate-600 dark:text-slate-300">
              <span>Prises / circuit</span>
              <select
                value={project.sockMode}
                onChange={(e) =>
                  commitProject(
                    { ...project, sockMode: Number(e.target.value) === 12 ? 12 : 8 },
                    true
                  )
                }
                className="rounded-md border border-slate-200 bg-slate-50 px-2.5 py-1.5 font-mono text-xs text-slate-900 dark:border-slate-700 dark:bg-slate-950 dark:text-white"
              >
                <option value={8}>8 max (1,5 mm², 16 A)</option>
                <option value={12}>12 max (2,5 mm², 20 A)</option>
              </select>
            </label>

            <label className="flex items-center gap-2.5 text-xs font-medium text-slate-600 dark:text-slate-300">
              <span className="whitespace-nowrap">
                Simultanéité k :{' '}
                <strong className="font-mono tabular-nums text-slate-950 dark:text-white">
                  {frNum(project.k, 2)}
                </strong>
              </span>
              <input
                type="range"
                min={0.3}
                max={1}
                step={0.05}
                value={project.k}
                onChange={(e) =>
                  commitProject({ ...project, k: parseFloat(e.target.value) }, false)
                }
                className="w-24 accent-blue-700 dark:accent-sky-400"
              />
            </label>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <button
              type="button"
              onClick={undo}
              disabled={past.length === 0}
              title="Annuler (Ctrl+Z)"
              className="inline-flex items-center gap-1 rounded-md border border-slate-200 px-2.5 py-1.5 text-xs font-medium text-slate-700 hover:bg-slate-50 disabled:opacity-40 whitespace-nowrap dark:border-slate-700 dark:text-slate-200 dark:hover:bg-slate-800"
            >
              <Undo2 className="h-3.5 w-3.5" />
              <span>Annuler</span>
            </button>
            <button
              type="button"
              onClick={redo}
              disabled={future.length === 0}
              title="Rétablir (Ctrl+Y)"
              className="inline-flex items-center gap-1 rounded-md border border-slate-200 px-2.5 py-1.5 text-xs font-medium text-slate-700 hover:bg-slate-50 disabled:opacity-40 whitespace-nowrap dark:border-slate-700 dark:text-slate-200 dark:hover:bg-slate-800"
            >
              <Redo2 className="h-3.5 w-3.5" />
              <span>Rétablir</span>
            </button>

            <div className="h-5 w-px bg-slate-200 dark:bg-slate-700" />

            <button
              type="button"
              onClick={() => fileInputRef.current?.click()}
              className="inline-flex items-center gap-1 rounded-md border border-slate-200 px-2.5 py-1.5 text-xs font-medium text-slate-700 hover:bg-slate-50 whitespace-nowrap dark:border-slate-700 dark:text-slate-200 dark:hover:bg-slate-800"
            >
              <Upload className="h-3.5 w-3.5" />
              <span>Ouvrir (.json)</span>
            </button>
            <input
              ref={fileInputRef}
              type="file"
              accept=".json,application/json"
              className="hidden"
              onChange={(e) => {
                const file = e.target.files?.[0];
                if (file) {
                  handleImportJson(file);
                  e.target.value = '';
                }
              }}
            />

            {viewMode === 'plan2d' && (
              <button
                type="button"
                onClick={handleExportPlanSvg}
                className="inline-flex items-center gap-1 rounded-md border border-slate-200 px-2.5 py-1.5 text-xs font-medium text-slate-700 hover:bg-slate-50 whitespace-nowrap dark:border-slate-700 dark:text-slate-200 dark:hover:bg-slate-800"
              >
                <Download className="h-3.5 w-3.5" />
                <span>Plan (.svg)</span>
              </button>
            )}

            <button
              type="button"
              onClick={() => setIsDark((p) => !p)}
              aria-label={isDark ? 'Passer en mode clair' : 'Passer en mode sombre'}
              title={isDark ? 'Mode clair' : 'Mode sombre'}
              className="inline-flex items-center gap-1 rounded-md border border-slate-200 px-2.5 py-1.5 text-xs font-medium text-slate-700 hover:bg-slate-50 whitespace-nowrap dark:border-slate-700 dark:text-slate-200 dark:hover:bg-slate-800"
            >
              {isDark ? <Sun className="h-3.5 w-3.5" /> : <Moon className="h-3.5 w-3.5" />}
              <span>{isDark ? 'Clair' : 'Sombre'}</span>
            </button>
          </div>
        </section>

        {/* Active View Layout */}
        {viewMode === 'plan2d' && (
          <div className="grid grid-cols-1 items-start gap-6 lg:grid-cols-[minmax(0,1fr)_360px]">
            <Plan2DEditor
              project={project}
              sim={sim}
              selected={selected}
              highlightedCircuitId={highlightedCircuitId}
              trippedCircuitIds={trippedCircuitIds}
              showCables={showCables}
              showFurn={showFurn}
              showNames={showNames}
              showDimensions={showDimensions}
              showSafetyZones={showSafetyZones}
              simulateLighting={simulateLighting}
              activeStairStep={activeStairStep}
              stairWalkMode={stairWalkMode}
              requestedTool={requestedTool}
              onClearRequestedTool={() => setRequestedTool(null)}
              onToggleCables={setShowCables}
              onToggleFurn={setShowFurn}
              onToggleNames={setShowNames}
              onToggleDimensions={setShowDimensions}
              onToggleSafetyZones={setShowSafetyZones}
              onToggleSimulateLighting={setSimulateLighting}
              onChangeStairStep={setActiveStairStep}
              onSetStairWalkMode={setStairWalkMode}
              onSelect={setSelected}
              onCommitProject={commitProject}
              svgRefExternal={planSvgRef}
            />

            <ResultsSidebar
              project={project}
              sim={sim}
              highlightedCircuitId={highlightedCircuitId}
              trippedCircuitIds={trippedCircuitIds}
              onHighlightCircuit={setHighlightedCircuitId}
              onSelectRoom={(roomId) => {
                const rm = project.rooms.find((r) => r.id === roomId);
                if (rm && rm.floorId !== project.activeFloorId) {
                  commitProject({ ...project, activeFloorId: rm.floorId }, false);
                }
                setSelected({ kind: 'room', id: roomId });
              }}
            />
          </div>
        )}

        {viewMode === 'cablage' && (
          <ManualWiringLab
            finishStyle={project.finishStyle}
            onChangeFinishStyle={(style) =>
              commitProject({ ...project, finishStyle: style }, true)
            }
            onPlaceOnPlan={(toolType) => {
              setRequestedTool(toolType);
              setViewMode('plan2d');
              setNotice('Sélectionnez une pièce ou un mur sur le plan pour poser cet appareil.');
            }}
          />
        )}

        {viewMode === 'tableau' && (
          <PanelSchematicView
            sim={sim}
            subscriptionKva={project.subscriptionKva}
            includeSurgeProtector={project.includeSurgeProtector}
            trippedCircuitIds={trippedCircuitIds}
            highlightedCircuitId={highlightedCircuitId}
            onToggleCircuitTrip={toggleCircuitTrip}
            onHighlightCircuit={setHighlightedCircuitId}
            onToggleSurgeProtector={(enabled) =>
              commitProject({ ...project, includeSurgeProtector: enabled }, true)
            }
            onChangeSubscriptionKva={(kva) =>
              commitProject({ ...project, subscriptionKva: kva }, true)
            }
          />
        )}

        {viewMode === 'vue3d' && (
          <Building3DView
            project={project}
            sim={sim}
            trippedCircuitIds={trippedCircuitIds}
            activeStairStep={activeStairStep}
            stairWalkMode={stairWalkMode}
            onSetStairWalkMode={setStairWalkMode}
            onCommitProject={commitProject}
            onToggleCircuitTrip={toggleCircuitTrip}
          />
        )}

        {viewMode === 'devis' && (
          <BudgetReportView
            sim={sim}
            materials={materials}
            unitPrices={unitPrices}
            onChangeUnitPrice={(key, val) =>
              setUnitPrices((prev) => ({ ...prev, [key]: val }))
            }
            onResetPrices={() => {
              setUnitPrices({ ...DEFAULT_UNIT_PRICES });
              setNotice('Tarifs unitaires par défaut restaurés.');
            }}
            onExportCsv={handleExportCsv}
            onExportJson={handleExportJson}
            onExportPlanSvg={handleExportPlanSvg}
          />
        )}

        <footer className="mt-8 border-t border-slate-200 pt-4 text-xs text-slate-500 dark:border-slate-800 dark:text-slate-400">
          Outil de modélisation et de pré-dimensionnement électrique selon la norme NF C 15-100 (bâtiment multi-niveaux, câblage manuel, escalier séquentiel, contrôle des volumes 60 cm en salle d’eau). Pour toute mise en œuvre réelle, faites valider votre dossier par un électricien qualifié ou un bureau de contrôle Consuel.
        </footer>
      </div>

      {notice && (
        <div
          role="status"
          aria-live="polite"
          className="no-print fixed right-5 bottom-5 z-50 flex items-center gap-3 rounded-lg border border-slate-200 bg-slate-900 px-4 py-2.5 text-sm font-medium text-white shadow-sm dark:border-slate-700 dark:bg-slate-100 dark:text-slate-950"
        >
          <span>{notice}</span>
          <button
            type="button"
            onClick={() => setNotice(null)}
            aria-label="Fermer la notification"
            className="rounded p-0.5 opacity-75 hover:opacity-100"
          >
            <X className="h-3.5 w-3.5" />
          </button>
        </div>
      )}
    </div>
  );
}
